SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*                
=============================================                  
Author: Naresh Naspoori                         
Create Date: 01-MARCH-2021                  
Description: OTC Refund insert refund or reship order details.       
    
Update History:    
Author: Naresh Naspoori    
Date: 21-JUNE-2021    
Description: OTC Refund, reship multiple requests  allowed.    
=============================================                  
exec  [otc].[InsertRefundReshipOrderDetails]                  
DECLARE @OrderId bigint =190009011                  
DECLARE @RequestData varchar(4000) ='{"Reason":"Other","AdditionalComments":"abc"}'                  
DECLARE @NHMemberId nvarchar(100)='OTC201901964101'                  
DECLARE @SubmitUserProfileId bigint=11924                  
DECLARE @CreateUser nvarchar(100) ='GailFran'                  
DECLARE @OrderChangeRequestItems NVARCHAR(max)  = N'[{"OrderId" : 190009011,  "OrderItemId": 78964, "ItemCode": "97958116426", "Quantity": 1,   "ItemData": "25" ,"Comments":"test"  } ]'                  
DECLARE @IsRefund bit=0                  
 ===============================================*/                  
 ALTER PROCEDURE [otc].[InsertRefundReshipOrderDetails] (                  
 @OrderId BIGINT                  
 ,@RequestData VARCHAR(4000)                  
 ,@NHMemberId NVARCHAR(100) = NULL                  
 ,@SubmitUserProfileId BIGINT                  
 ,@CreateUser NVARCHAR(100)                  
 ,@OrderChangeRequestItems NVARCHAR(MAX)                  
 ,@IsRefund bit=0                  
 )                  
AS                  
BEGIN TRY                  
--TESTING ONLY                  
   SET @SubmitUserProfileId = (select TOP 1 UserProfileId from auth.UserProfiles where UserName = @CreateUser AND IsActive = 1)--11924                  
 --SET @CreateUser ='GailFran'                  
                  
 DECLARE @SCOPE_IDENTITY BIGINT                  
 DECLARE @status VARCHAR(200) = 'PENDING'                  
 DECLARE @orderType VARCHAR(20) ='OTC'                  
 DECLARE @changeType VARCHAR(20) = CASE @IsRefund WHEN 1 THEN 'REFUND' WHEN 0 THEN 'RESHIP' END                  
 --DECLARE @orderStatusCode NVARCHAR(6) = CASE @IsRefund WHEN 1 THEN 'REF_P' WHEN 0 THEN 'RES_P' END  --REF_P  RES_P                  
 DECLARE @orderStatus VARCHAR(100) = CASE @IsRefund WHEN 1 THEN 'REFUND_PENDING' WHEN 0 THEN 'RESHIP_PENDING' END                  
 DECLARE @orderItemData VARCHAR(100) = CASE @IsRefund WHEN 1 THEN 'Refund applied.' WHEN 0 THEN 'Reship requested.' END                  
                  
 DECLARE @errorMsg VARCHAR(200)                  
 DECLARE @errorSeverity VARCHAR(200)                  
 DECLARE @orderPreviousStatus VARCHAR(20) = (                  
   SELECT orderStatusCode                  
   FROM orders.orders                  
   WHERE orderId = @OrderId                  
   )                  
                  
                  
  DECLARE @isRequestAllowed BIT=1                  
  DECLARE @hasPendingRequest int = (SELECT COUNT(*) FROM Orders.OrderChangeRequests WHERE OrderId=@OrderId AND IsActive=1 AND Status='PENDING'  AND orderType='OTC')                  
  -- START removed for multiple refund requests  allowed
  --DECLARE @hasRefundRequest int = (SELECT COUNT(*) FROM Orders.OrderChangeRequests WHERE OrderId=@OrderId AND IsActive=1 AND ChangeType='Refund'  AND orderType='OTC')                  
  --SET @isRequestAllowed= CASE                   
                         
    --   WHEN @IsRefund = 1 AND @hasPeningRequest = 0  THEN 1                  
     --  WHEN @IsRefund = 0 AND @hasPeningRequest =0 THEN 1                  
      -- ELSE 0                  
       --END                  
   -- END removed for multiple refund requests  allowed                 
                   
  IF(@hasPendingRequest = 0)                  
  BEGIN                  
 BEGIN TRANSACTION                  
                  
 INSERT INTO [Orders].[OrderChangeRequests] (                  
  [OrderId] ,[ChangeType] ,[Status] ,[OrderType] ,[PreviousStatus] ,[RequestData] ,[NHMemberId] ,[SubmitUserProfileId],[IsActive] ,[CreateDate],[SubmitDate],[CreateUser],ModifyDate ,ModifyUser)                  
 VALUES (                  
  @OrderId                  
  ,@changeType             
  ,@status                  
  ,@orderType                  
  ,@orderPreviousStatus                  
  ,@RequestData                  
  ,@NHMemberId                  
  ,@SubmitUserProfileId                  
  ,1                  
  ,getdate()                  
  ,getdate()                  
  ,@CreateUser                  
  ,getdate()                
  ,@CreateUser                
  )                  
                  
 SET @SCOPE_IDENTITY = SCOPE_IDENTITY()                  
                  
 INSERT INTO [Orders].[OrderChangeRequestItems] (                  
  OrderChangeRequestId ,OrderId ,OrderItemId ,ItemCode ,Quantity ,ItemData ,Comments ,STATUS ,PreviousStatus ,CreateDate ,CreateUser ,IsActive  ,ModifyDate ,ModifyUser          
  )                  
 SELECT @SCOPE_IDENTITY OrderChangeRequestId                  
  ,@OrderId                  
  ,*                  
  ,@status status                  
  ,(                  
   SELECT TOP 1 STATUS                  
   FROM orders.orderitems                  
   WHERE orderItemid = t.OrderItemId                  
   ) PreviousStatus                  
  ,getdate() CreateDate                  
  ,@CreateUser CreateUser                  
  ,1 IsActive                  
  ,getdate() ModifyDate                  
  ,@CreateUser ModifyUser                  
 FROM (                  
  SELECT *                  
  FROM OPENJSON(@OrderChangeRequestItems) WITH (                  
    --OrderId bigint '$.OrderId'                   
    OrderItemId BIGINT '$.OrderItemId'                  
    ,ItemCode NVARCHAR(200) '$.ItemCode'                  
    ,Quantity BIGINT '$.Quantity'                  
    ,ItemData VARCHAR(4000) '$.ItemData'                  
    ,Comments VARCHAR(4000) '$.Comments'                  
    )                  
  ) t                  
                  
 UPDATE orders.orderitems                  
 SET           
   ItemData = Json_modify(ItemData, '$.Remarks', @orderItemData)                  
  ,ModifyDate = getdate()                  
  ,ModifyUser = @CreateUser                  
 WHERE OrderId = @OrderId                  
  AND orderitemId IN (                  
   SELECT orderItemId                  
   FROM OPENJSON(@OrderChangeRequestItems) WITH (                  
     OrderItemId BIGINT '$.OrderItemId'                  
     ,ItemCode NVARCHAR(200) '$.ItemCode'                  
     ,Quantity BIT '$.Quantity'                  
     ,ItemData VARCHAR(4000) '$.ItemData'                  
     )                  
   )                  
                  
 COMMIT;                  
 END                  
END TRY                  
                  
BEGIN CATCH                  
 DECLARE @ErrorMessage NVARCHAR(4000);                  
 DECLARE @Severity INT;                  
 DECLARE @ErrorState INT;                  
                  
 SELECT @ErrorMessage = ERROR_MESSAGE()                  
  ,@Severity = ERROR_SEVERITY()                  
  ,@ErrorState = ERROR_STATE()                  
                  
 RAISERROR (                  
   @ErrorMessage                  
   ,@Severity                  
   ,@ErrorState                  
   )                  
                  
 PRINT (@ErrorMessage)                  
 PRINT (@Severity)                  
 PRINT (@ErrorState)                  
                  
 ROLLBACK                  
END CATCH 