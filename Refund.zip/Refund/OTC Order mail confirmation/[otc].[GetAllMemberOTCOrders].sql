SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO   
/* =============================================                  
                         
  Updated Date: 05-MARCH-2021                  
  Description: OTC get all member orders details.               
                
 Update History:              
              
 Author: Naresh Naspoori    
 Udate Date: 21-JUNE-2021  
 orc table  updated for refund and reship        
 refundComplete added,isRefAllowed spoc ([otc].[getIsRefAllowedOrders] ) created.    
  =============================================                  
   exec  [otc].[GetAllMemberOTCOrders] 'NH202106672275'                  
*/                
ALTER PROC [otc].[GetAllMemberOTCOrders] @NHMemberId NVARCHAR(max)    
AS    
BEGIN    
 SET NOCOUNT ON;    
    
 --DECLARE @NHMemberId NVARCHAR(max) = 'NH202106672275'    
    
 DROP TABLE    
    
 IF EXISTS #PartialTempTbl    
  CREATE TABLE #PartialTempTbl (    
   isFullRequest BIT    
   ,orderId BIGINT    
   )    
    
 INSERT INTO #PartialTempTbl    
 EXEC [Orders].[GetRequestPartialOrderStatus] @NHMemberId    
   
 DROP TABLE    
 
  -- START get orders refund status is allowed or not 
  
 IF EXISTS #isRefAllowendOrdersTempTbl    
  CREATE TABLE #isRefAllowendOrdersTempTbl (    
   isRefAllowed BIT    
   ,orderId BIGINT    
   )    
   
 INSERT INTO #IsRefAllowendOrdersTempTbl    
 EXEC [otc].[getIsRefAllowedOrders] @NHMemberId    

 -- END get orders refund status is allowed or not
    
 -- START get isComplete status from orderTransactionDetails for refun/reship flow      
 DROP TABLE    
    
 IF EXISTS #orderTransDataDetails    
  SELECT *    
  INTO #orderTransDataDetails    
  FROM (    
   SELECT DISTINCT orderid    
    ,r.*    
    ,isComplete    
   FROM [Orders].OrderTransactionDetails otd    
   OUTER APPLY OPENJSON(otd.OrderTransactionData) WITH (orderChangeRequestId BIGINT '$.orderChangeRequestId') AS r    
   WHERE orderid IN (    
     SELECT orderid    
     FROM orders.orders oo    
     WHERE oo.NHMemberId = @NHMemberId    
      AND oo.OrderType = 'OTC'    
      AND oo.IsActive = 1    
     )    
    AND OrderStatusCode = 'REF'    
   ) AS tbl    
    
--- END get isComplete status from orderTransactionDetails for refun/reship flow ---- 

 SELECT DISTINCT oo.OrderID AS 'OrderID'    
  ,oo.CreateDate AS 'OrderDate'    
  ,JSON_VALUE(oo.OrderAmountData, '$.price') AS 'TotalPrice'    
  ,JSON_QUERY(oo.OrderAmountData, '$.benefitTransactions') AS 'benefitTransactions'    
  ,CAST(JSON_VALUE(oo.OrderAmountData, '$.outOfPocket') AS DECIMAL(7, 2)) AS 'MemberResponsibility'    
  ,CASE     
   WHEN oo.OrderStatusCode IN ('INI')    
    THEN CAST(1 AS BIT)    
   ELSE CAST(0 AS BIT)    
   END AS 'IsEditable'    
  ,CASE     
   WHEN oo.OrderStatusCode IN (    
     'INI'    
     ,'ACK'    
     ,'EMI'    
     )    
    THEN 'ACTIVE'    
   WHEN (    
     SELECT Count(*)    
     FROM Orders.OrderChangeRequests    
     WHERE OrderId = oo.orderId    
      AND IsActive = 1    
      AND STATUS = 'Pending'    
     ) > 0    
    THEN 'ACTIVE'    
   ELSE 'PAST'    
   END AS 'OrderStatusCategory'    
  ,oo.OrderStatusCode AS 'OrderStatusCode'    
  ,oo.Source    
  ,(    
   SELECT DISTINCT oi.ItemCode AS 'ItemCode'    
    ,CONCAT (    
     '/'    
     ,ia.ModelAttributeValue    
     ,'/'    
     ,ia.ModelAttributeValue    
     ,'_Front.jpg'    
     ) AS 'ItemMedialUrl'    
    ,ia.ModelAttributeValue AS 'ItemAttributeValue'    
   FROM Orders.OrderItems oi    
   INNER JOIN [catalog].[ItemMasterAttributeValues] ia WITH (NOLOCK) ON oi.ItemCode = ia.ItemCode    
   WHERE orderid = oo.OrderID    
    AND ia.AttributeCode = 'NATIONS_ID'    
    AND ia.IsActive = 1    
    AND oi.ItemCode <> 'NB_VOUCHER_REFUND'    
   FOR JSON PATH    
   ) AS ItemDetails    
  ,oo.STATUS AS OrderStatus    
  ,orcData.ChangeType    
  ,orcData.OrderChangeRequestStatus    
  ,orcData.RequestData    
  ,(    
   CASE     
    WHEN TEMP.isFullRequest IS NULL    
     THEN CAST(0 AS BIT)    
    ELSE TEMP.isFullRequest    
    END    
   ) AS isFullRequest    
  ,oo.RefOrderId AS 'RefOrderId'    
  ,rot.isRefAllowed    
  ,cast(ISNULL(JSON_VALUE(oi.ItemData, '$.isMealKit'), 0) AS BIT) AS isMealKit    
  ,ISNULL(ort.IsComplete, 0) AS refundComplete   -- refundComplete added for order refund status as refund completed.  
 FROM orders.Orders oo WITH (NOLOCK)    
 LEFT JOIN [Orders].[OrderItems] oi ON oo.OrderID = oi.OrderID    
  AND oi.ItemCode <> 'NB_VOUCHER_REFUND'    
 LEFT JOIN #PartialTempTbl TEMP ON TEMP.orderid = oo.orderid    
 OUTER APPLY (    
  SELECT TOP 1 orc.changeType    
   ,orc.STATUS AS OrderChangeRequestStatus    
   ,orc.RequestData    
   ,orc.OrderChangeRequestID    
  FROM [Orders].[OrderChangeRequests] orc WITH (NOLOCK)    
  WHERE orc.orderid = oo.orderid    
   AND IsActive = 1    
  ORDER BY orc.OrderChangeRequestID DESC    
  ) AS orcData    
 LEFT JOIN #orderTransDataDetails ort ON ort.orderId = oo.OrderID    
  AND ort.orderChangeRequestId = orcData.OrderChangeRequestID    
 INNER JOIN #IsRefAllowendOrdersTempTbl rot ON rot.orderId = oo.OrderID  -- added for isRefAllowed status.    
 WHERE oo.NHMemberId = @NHMemberId    
  AND oo.OrderType = 'OTC'    
  AND oo.IsActive = 1    
 ORDER BY 1 DESC    
END