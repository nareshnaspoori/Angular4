SELECT TOP 1  *FROM [Orders].[OrderChangeRequestItems] orc where orderId =200269960
SELECT TOP 1  *FROM [Orders].OrderItems orc where orderId =200270254
select top 10 *from [orders].[orders] where nhmemberId ='NH202106672405'
sp_helptext '[otc].[getIsRefAllowed]'
select top 10 *from [orders].[orders] where orderid =200270322   order by 1 desc
SELECT TOP 10 *from otc.userProfiles  where Preferences is not null
SELECT TOP 10 *from otc.userProfiles   where nhmemberid ='NH202107080924'
UPDATE otc.userProfiles SET Preferences ='{"OrderCreation":{"sendEmail":true,"sendSMS":true}}'
where UserName ='sam1111'





select * from otc.userprofiles where username like '%pavan%'




sp_helptext '[otc].[GetPrefillOrderDetailsForMail]' 200270231
[otc].[GetPrefillOrderDetailsForMail] 200587072


select top 10 *from [orders].[orders] where orderid = 200270230

sp_helptext '[otc].[InsertRefundReshipOrderDetails]'

{"OrderCreation":{"sendEmail":false,"sendSMS":false}}


 select top 10 JSON_value(ii.ConfigData,'$.phone') as contactUsNumber  
 select top 10  *from insurance.insuranceConfig ii 

 where ii.InsuranceCarrierID= (select JSON_VALUE(oo.memberData,'$.clientCarrierId') from orders.orders oo where orderid = 200270230)
 and ii.configType ='otccontent'


 select top 30* from jobs.pageevents where eventcode IN('PR050','PR051')order by 1 desc
 UPDATE   jobs.pageevents SET IsProcessed =1 where eventcode='PR050'

 update jobs.pageevents SET IsProcessed =0 where pageeventId =292472



 SELECT TOP 10 *fROM JOBS.eventactions ORDER BY 1 DESC

 SELECT TOP 10* FROM orders.ordertransactiondetails order by 1 desc
 
 {"orderId":200587058}200587058
 [otc].[GetPrefillOrderDetailsForMail] 200587119

 DECLARE @OrderId BIGINT  = 200587107     
     
  WITH transShippedItemTrackingOrders AS  (        
      [otc].[GetOrderTrackingDetailsForShippedMail] @OrderId        
      
   )        
   INSERT INTO #transShippedItemTrackingOrders    
   

 sp_helptext '[otc].[GetOrderTrackingDetailsForShippedMail]'

 select top 10  *from  master.memberinsuranceDetails where insuranceNbr like'naresh%' order by 1 desc

 select top 10 *From otc.userprofiles where nhmemberid ='NH202107081403' order by 1 desc
   
       