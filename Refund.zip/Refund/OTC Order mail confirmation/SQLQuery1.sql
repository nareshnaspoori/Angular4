sp_helptext '[otc].[GetAllOTCOrderItemDetails]'
exec  [otc].[GetAllOTCOrderItemDetails] 200270305
select top 10 * from Orders.OrderTransactionDetails order by 1 desc
select top 10 * from Orders.OrderTransactionDetails where orderid in (200270445,200270447) order by 1 desc

select top 10* from jobs.pageevents order by 1 desc
SELECT  top 10*  FROM [jobs].[PageActionProcessQueue]  where isContinuous =1   order by 1 desc  --where pageeventid =132212
SELECT  top 10*  FROM [jobs].[PageActionProcessQueue]  order by 1 desc 

select top 20 * from [jobs].[PageEvents]   order by 1 desc
UPDATE [jobs].[PageEvents] SET IsProcessed =0 where pageeventId =132508
{"orderId":200585207}

select top 10 *from orders.orders order by 1 desc
SELECT * FROM [jobs].[PageActionProcessQueue] 
                     LEFT OUTER JOIN [jobs].[PageEvents] on [jobs].[PageEvents].PageEventId = [jobs].[PageActionProcessQueue].PageEventId     
                    WHERE [jobs].[PageActionProcessQueue].[IsActive] = 1 and [jobs].[PageEvents].[IsActive]=1
                    AND [jobs].[PageActionProcessQueue].[ActionCode] IN ('ACT721') 
                    AND [jobs].[PageActionProcessQueue].[IsContinuous] <= 1  
                    AND (
                        [jobs].[PageActionProcessQueue].[ScheduledRunTime] IS NULL 
                        OR (
                            [jobs].[PageActionProcessQueue].[ScheduledRunTime] IS NOT NULL 
                        AND [jobs].[PageActionProcessQueue].[ScheduledRunTime]  <= GETUTCDATE()
                        )
                    )
                    ORDER BY CASE [jobs].[PageActionProcessQueue].[ActionCode] 
                         when 'OTCEMI' then 1
                         when 'OTCSendSub' then 2
                         when 'REFUND' then 3
                         else 4
                         end
select * from jobs.PageEvents
where EventCode='PR050'
{"orderId":200270237}
{"orderId":200270230}
IsContinuous
0

select top 10 * from [contact].[MailHistory] order by  1 desc
select * from [contact].[MailHistoryEmails] order by  1 desc OFFSET 100 ROWS

select top 10 * from Orders.OrderChangeRequestItems where orderId=200270295  order by  1 desc
select top 10 * from Orders.OrderChangeRequests where orderId=200270295  order by  1 desc
select top 10 * from ORDERS.ORDERITEMS WHERE OrderId=200270295  order by  1 desc

select top 10 * from ORDERS.orders WHERE OrderId=200270500  order by  1 desc
SELECT TOP 10  * FROM Orders.OrderTransactionDetails  order by  1 desc
select top 10 * from ORDERS.OrderChangeRequests WHERE OrderId=200270515  order by  1 desc
SELECT  CAST(IIF(JSON_VALUE(Preferences,'$.OrderCreation.sendEmail') = 'true', 1, 0)AS BIT) FROM otc.UserProfiles WHERE nhmemberid=@nhMemberId
SELECT  CAST(IIF(JSON_VALUE(OrderTransactionData,'$.preferenceData.profileLevelSMS') = 'true', 1, 0)AS BIT)  FROM  Orders.OrderTransactionDetails
                                     WHERE OrderID =200270658 AND  OrderStatusCode ='COMM' AND IsActive=1
SELECT JSON_VALUE(OrderTransactionData,'$.preferenceData.profileLevelSMS') FROM  Orders.OrderTransactionDetails
                                     WHERE OrderID =200270658 AND  OrderStatusCode ='COMM' AND IsActive=1

[otc].[GetPrefillOrderDetailsForMail] 200270930
 SELECT  top 100 * FROM Orders.OrderTransactionDetails where orderStatusCode='COMM'   order by  ModifyDate desc
 SELECT  top 50 * FROM Orders.OrderTransactionDetails where orderStatusCode='COMM'   order by  1 desc  --200270736
 SELECT  top 10 * FROM Orders.OrderTransactionDetails where orderid= 200270669 
 select top 10 *from otc.userprofiles where preferences is not null
 select top 10 *from [orders].[orders] where orderid =200270566   order by 1 desc

 UPDATE Orders.OrderTransactionDetails SET OrderTransactionData ='{"preferenceData":{"sendEmail":true,"sendSMS":true,"profileLevelEmail":false,"profileLevelNumber":false}}'
 WHERE orderId IN (200270658) AND orderStatusCode ='COMM'
 {"preferenceData":{"sendEmail":true,"sendSMS":true,"profileLevelEmail":true,"profileLevelNumber":true}}
 {"preferenceData":{"sendEmail":false,"sendSMS":false,"profileLevelEmail":false,"profileLevelNumber":false}}

SELECT TOP 10 *from otc.userProfiles   where nhmemberid ='NH202106672437'


UPDATE otc.userProfiles SET Preferences ='{"OrderCreation":{"sendEmail":true,"sendSMS":false}}'
where UserName ='otc1111'

 DECLARE @orderId bigint =200270776 
 -- transaction details COMM LEVEL
 SELECT * FROM Orders.OrderTransactionDetails WHERE OrderId=@orderId  order by  1 desc

 -- userProfile Level
  select top 10 *from otc.userprofiles where nhmemberId  IN
  (
  select nhmemberId from ORDERS.orders WHERE OrderId=@orderId 
  )
  -- config level
  SELECT  JSON_VALUE(ConfigData,'$.Preferences.OrderUpdates.sendEmail') as sendEmail,JSON_VALUE(ConfigData,'$.Preferences.OrderUpdates.sendSMS') as sendSMS  FROM insurance.insuranceConfig 
WHERE  InsuranceCarrierID IN ( SELECT JSON_VALUE(memberData,'$.clientCarrierId') FROM Orders.Orders WHERE orderId =@OrderId AND ConfigType='OTCAPP'  )


SELECT *FROM  Orders.OrderTransactionDetails where OrderID =@OrderId AND  OrderStatusCode ='COMM' AND IsActive=1


  select JSON_VALUE(ConfigData,'$.Preferences.OrderUpdates.sendSMS') from Insurance.InsuranceConfig
where   ConfigType='OTCAPP' and  JSON_VALUE(ConfigData,'$.Preferences.OrderUpdates.sendSMS') ='true' and IsActive=1


DEclare @preferenceData =
UPDATE Orders.OrderTransactionDetails SET OrderTransactionData =JSON_MODIFY(OrderTransactionData,'$.preferenceData',JSON_QUERY(ISNULL(@OrderProfrencesforIncommManaged ,'{}'))
,ModifyDate =GETDATE()
WHERE orderId =@orderId AND orderStatucCode= 'COMM'


select top 10  * from Insurance.InsuranceConfig
where   ConfigType='OTCAPP' and IsActive=1
  [otc].[GetPrefillOrderDetailsForMail] 200270799
[otc].[GetPrefillOrderDetailsForMail] 200270669
select top 100  JSON_VALUE(ConfigData,'$.Preferences')   from insurance.insuranceConfig where configType ='otcapp'  and
JSON_VALUE(Configdata,'$.benefitValueSource')='nations'  order by 1 desc
select * from orders.OrderItems where orderid=200270444




UPDATE Orders.OrderTransactionDetails SET OrderTransactionData =JSON_MODIFY(OrderTransactionData,'$.preferenceData','{"orderUpdates":[{"commTrigger":"OrderCreation","commData":{"emailSent":true,"contactReferenceId":"42411"}}]}'), ModifyDate =GETDATE()WHERE orderId=200270515 AND orderStatusCode ='COMM'



UPDATE Orders.OrderTransactionDetails SET OrderTransactionData =JSON_MODIFY(OrderTransactionData,'append $.orderUpdates','[{"commTrigger":"OrderCreation","commData":{"emailSent":true}}]'), ModifyDate =GETDATE()WHERE orderId=200270551 AND orderStatusCode ='COMM'




SELECT top 10  JSON_Query(OrderTransactionData,'$.orderUpdates[1]') FROM Orders.OrderTransactionDetails WHERE  orderStatusCode ='COMM'  order by 1 desc

Select top 100 walletName, WalletCode,DisplayWalletName,ColorCode from otccatalog.wallets WHERE walletName='University of Maryland'

sp_helptext '[Orders].[GetRefundRequestsForFilter]'


update orders.orders
 SET OrderStatusCode ='SHI'   ---SHI
-- ,ModifyDate = getdate()
 --,ModifyUser = 'GailFran'
 where OrderId =200271324     


 select top 10 * from Orders.OrderTransactionDetails where orderid in(
200270329
,200270325
,200270277
,200270250
,200270248
)

select top 10 *from orders.ORDERS  where orderId =200585205 order by 1 desc
 SELECT top 20 * from Orders.ORDERS WHERE NhmemberId ='NH202106867927'order by 1 desc
 select top 20 * from Orders.OrderTransactionDetails WHERE OrderStatusCode ='shi' order by 1 desc
 select top 20 * from Orders.OrderTransactionDetails  where orderId =200404415 order by 1 desc

select top 100 * FROM Orders.OrderTransactionDetails  where   OrderStatusCode ='COMM' AND IsActive=1
  order by 1 desc
  UPDATE Orders.OrderTransactionDetails SET ORDERiD =200404415 WHERE orderTransactionid =2056421

 delete from 
   --200391893 200223082   -- NH202002843131
 SELECt * FROM otc.UserProfiles WHERE  NhmemberId ='NH202107080762' 
  
 [otc].[GetPrefillOrderDetailsForMail] 200404415
 select  * from Orders.OrderTransactionDetails  where orderId  IN (SELECT orderid from Orders.ORDERS
 WHERE NhmemberId  in ( select nhmemberId  from otc.UserProfiles group by nhmemberId,subdomain having count(nhmemberId)=2  )) order by 1 desc
 SELECT TOP 1 userProfileId FROM otc.UserProfiles WHERE isActive=1 AND lower(subDomain) = lower('eon')

 select count(nhmemberId),nhmemberId ,subdomain from otc.UserProfiles group by nhmemberId,subdomain having count(nhmemberId)=2 
select top 10 *from orders.orderitems  where orderId =200271142 order by 1 desc
select top 10 * from [Orders].[OrderChangeRequests] where ordertype ='otc' order by 1 desc
select top 10 * from [Orders].[OrderChangeRequestItems]  order by 1 desc
SELECT TOP 10 *FROM  insurance.insuranceConfig order by 1 desc
SELECT *FROM  insurance.insuranceConfig  WHERE InsuranceCarrierID IN ( SELECT JSON_VALUE(memberData,'$.clientCarrierId') FROM Orders.Orders WHERE orderId =200404415 AND ConfigType='OTCAPP')
SELECT  CAST(IIF(JSON_VALUE(ConfigData,'$.Preferences.OrderUpdates.sendEmail') = 'true', 1, 0)AS BIT) FROM insurance.insuranceConfig     
                                     WHERE InsuranceCarrierID IN ( SELECT JSON_VALUE(memberData,'$.clientCarrierId') FROM Orders.Orders WHERE orderId =200404415 AND ConfigType='OTCAPP')



SELECT TOP 1  ISNULL(( SELECT TOP 1 IIF (trackingNumber IS NOT NULL , CONCAT (trackingNumber ,',',trackingUrl),NULL)AS trackingDetails FROM OPENJSON((SELECT TOP 1 OrderTransactionData FROM  orders.OrderTransactionDetails  otd  
  WITH (NOLOCK) WHERE orderid=200270294 ORDER BY otd.CREATEDATE DESC))   WITH   (    trackingUrl NVARCHAR(200) '$.trackingUrl',   trackingNumber NVARCHAR(200) '$.trackingNumber'   )),'')     TrackingDetails 

  sp_helptext '[otc].[InsertRefundReshipOrderDetails]'
  provider.OTCMemberOrders 'NH202106672437'

  select top 10 defaultImage from cms.ItemmasterContent where ItemCode =
order by 1 desc 
SELECT defaultImage FROM cms.ItemmasterContent where ItemCode ='1723'

SELECT TOP 10 * FROM otc.UserProfiles order by 1 desc
SELECT top 10 *
FROM Orders.OrderTransactionDetails  where   OrderStatusCode ='COMM' AND IsActive=1
  order by 1 desc


  (select top 1 OrderTransactionData from  Orders.OrderTransactionDetails order by 1 desc
SELECT top 10 j.[key]
FROM Orders.OrderTransactionDetails    d 
CROSS APPLY OPENJSON(d.OrderTransactionData) j  
where   OrderStatusCode ='COMM' and IsActive=1
order by 1 desc 

SELECT * FROM OpenJson(select top 1 OrderTransactionData from  Orders.OrderTransactionDetails order by 1 desc);
DECLARE @info NVARCHAR(600)='{"preferenceData":{"sendEmail":true,"sendSMS":true,"profileLevelPreferences":false},"orderUpdates":[{"commTrigger":"OrderCreation","commData":{"emailSent":true,"contactReferenceID":45975,"smsSent":true}}]}'
IF (ISJSON(@info) > 0)  BEGIN  
   IF EXISTS(SELECT 1 FROM OPENJSON(@info) WHERE [key] = 'sendEmail') PRINT 'Yes'
   ELSE PRINT 'No'
END



--JSON_QUERY(orderTransactionData,'lax $.preferenceData')
select top 10  * from  Orders.OrderTransactionDetails 
where   OrderStatusCode ='SHIP'  and  IsActive=1 --and JSON_VALUE(orderTransactionData,'$.preferenceData') IS NOT NULL
order by 1 desc 

select top 1 JSON_VALUE(orderTransactionData,'$.preferenceData') from  Orders.OrderTransactionDetails 
where   OrderStatusCode ='COMM'  and  IsActive=1 AND JSON_VALUE(orderTransactionData,'$.preferenceData') IS NOT NULL
order by 1 desc 

select top 10* from  Orders.OrderTransactionDetails 
where   OrderStatusCode ='COMM' and orderId =200271308 AND IsActive=1
order by 1 desc 

select top 10  * FROM Orders.OrderTransactionDetails WHERE ISJSON(orderTransactionData)<=0

select * FROM Orders.OrderTransactionDetails WHERE ISJSON(orderTransactionData)>0 and  OrderStatusCode ='COMM' AND JSON_QUERY(orderTransactionData,'$.orderUpdates') IS NULL  ORDER BY 1 DESC


select top 5 *from Orders.OrderTransactionDetails where ISJSON(orderTransactionData)>0 and
JSON_VALUE(JSON_QUERY(orderTransactionData,'$.orderUpdates[0].commData'),'$.smsSent') is not null and  OrderStatusCode ='COMM'

select top 5 *  FROM Orders.OrderTransactionDetails WHERE  ISJSON(orderTransactionData)>0 and  OrderStatusCode ='COMM' and 
JSON_QUERY(orderTransactionData,'$.orderUpdates') IS not NULL 
and JSON_VALUE(JSON_QUERY(orderTransactionData,'$.orderUpdates[0].commData'),'$.smsSent') is null 
--and orderId=200270317
ORDER BY 1 DESC



DECLARE @json NVARCHAR(4000) = N'{  
      "path": {  
            "to":{  
                 "sub-object":["en-GB", "en-UK","de-AT","es-AR","sr-Cyrl"]  
                 }  
              }  
 }';

 DECLARE @json1 VARCHAR(8000) =N'{"preferenceData":{"sendEmail":true,"sendSMS":true,"profileLevelPreferences":false},"orderUpdates":[{"commTrigger":"OrderCreation","commData":{"emailSent":true,"contactReferenceID":45975,"smsSent":true}}]}'

SELECT [key], value
FROM OPENJSON(@json1,'$.orderUpdates[0]."commData"')


SELECT top 10 j.[key]
FROM Orders.OrderTransactionDetails    d 
CROSS APPLY OPENJSON(d.OrderTransactionData,'$.orderUpdates[0]."commData"') j  
where   OrderStatusCode ='COMM' and IsActive=1 AND  JSON_VALUE(d.OrderTransactionData,'$.orderUpdates[0]') is not null
order by 1 desc 


SELECT OrderID FROM [otc].[GetAllCommOrders] WHERE emailSent=''  AND (TriggerName = '' OR TriggerName = 'OrderCreation')
select top 100  * from  Orders.OrderTransactionDetails WHERE   OrderStatusCode ='COMM' order by 1 desc
 select top 100  * from  Orders.OrderTransactionDetails WHERE   OrderStatusCode ='COMM' order by 1 desc


sp_helptext '[otc].[GetPrefillOrderDetailsForMail]'  [otc].[GetPrefillOrderDetailsForMail] 200572165

select top 10 * from  [healthcare].[ICD10Codes] where Code like '%F419%'
select top 10 * from healthcare.ICD10CodeCategories where ICD10Code  IN (SELECT Code FROM  [healthcare].[ICD10Codes])
select top 10 * from healthcare.ICD10CodeCategories where Category  like '%Vagina%' --Code Vs Category 


select top 10 ICD10Code from healthcare.ICD10CodeCategories where Category  like '%Crohn''s Disease%' -- first
select top 10 * from healthcare.ICD10Categories where Category  like '%Crohn''s Disease%'  --first
select  * from  [healthcare].[ICD10Codes]  where code in  --- second 
(select top 10 ICD10Code from healthcare.ICD10CodeCategories where Category  like '%Crohn''s Disease%') 

select top 10 * from healthcare.ICD10CodeCategories where Category  like '%Crohn''s Disease%' --Code Vs Category 



select top 10 * from [otc].[ProductICDCategoriesAndICDCodes] where Category  like '%Crohn''s Disease%'   --R Products 
select top 10 * from [otc].[ProductICDCategoriesAndICDCodes] where nationsId in(5156) and  Category  like '%Iron%'
select top 10 * from  [healthcare].[ICD10Codes] 

select  * from  [healthcare].[ICD10Codes]  where code in 
(select top 10 ICD10Code from healthcare.ICD10CodeCategories where Category  like '%Crohn''s Disease%') 

select top 10 * from [otc].[ProductICDCategoriesAndICDCodes]  
select top 10 * from  [healthcare].[ICD10Codes] where Code IN (SELECT ICD10Code FROM  healthcare.ICD10CodeCategories where Category  like '%Crohn''s Disease%')
--(select ICD10Code FROM [otc].[ProductICDCategoriesAndICDCodes] ORDER BY 1 DESC )

select top 10 * from [otc].[ProductICDCategoriesAndICDCodes] WHERE ICD10Code IN
('D519')

select top 10 * from  otccatalog.itemmaster where nationsId IN (5016, 5283, 5850, 6017) order by 1 desc
select top 10* from otc.MemberICD10Codes 
select top 10* from otc.MemberDiseaseStates where Category  like '%Crohn''s Disease%'
select top 10 * from healthcare.ICD10Categories where Category  like '%Crohn''s Disease%'  --first

select top 20 *from  [jobs].[PageEvents] where eventCode= 'PR050' order by 1 desc
select top 20 *from  jobs.eventActions order by 1 desc

200802989

select top 20 *from [jobs].[PageActionProcessQueue]  order by  1 desc  where pageeventId =393794
UPDATE  [jobs].[PageActionProcessQueue]  SET ProcessSTatus =1
where pageEventId ='393796'

select top 10 * from insurance.insurancehealthplans order by 1 desc 
[otc].[GetPrefillOrderDetailsForMail] '200802991'
{"price":329.0,"amountCovered":329.0,"outOfPocket":0.0,"benefitTransactions":[{"catalogName":"OTCApple","originalWalletCode":"01","benefitType":"OTCApple","acctLast4Digits":null,"amountCovered":329.0,"amountRemaining":71.0,"transactionId":null,"outOfPocket":0.0,"source":"FIS",
"emiData":{"emiBalance":0.0,"emiAmount":0.0,"emiPeriod":0,"transactionGroupId":null,"emiProductCategory":"apple"},"isMealKitGroup":false}],"warehouseCode":null}