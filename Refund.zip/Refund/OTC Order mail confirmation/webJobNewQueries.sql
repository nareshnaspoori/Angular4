
select top 10 * FROM Orders.OrderTransactionDetails where OrderStatusCode ='COMM' order by 1 desc

--step 1

select * FROM Orders.OrderTransactionDetails WHERE ISJSON(orderTransactionData)>0 and  OrderStatusCode ='COMM'  
AND JSON_VALUE(JSON_QUERY(orderTransactionData,'$.preferenceData'),'$.sendEmail') ='true' 
AND(JSON_QUERY(orderTransactionData,'$.orderUpdates') IS NULL 
OR  JSON_VALUE(JSON_QUERY(orderTransactionData,'$.orderUpdates[0].commData'),'$.emailSent') is null
)ORDER BY 1 DESC


--step 2  sms is null

select * FROM Orders.OrderTransactionDetails WHERE ISJSON(orderTransactionData)>0 AND  OrderStatusCode ='COMM'  
AND JSON_VALUE(JSON_QUERY(orderTransactionData,'$.preferenceData'),'$.sendSMS') ='true' 
AND(JSON_QUERY(orderTransactionData,'$.orderUpdates') IS NULL 
OR  JSON_VALUE(JSON_QUERY(orderTransactionData,'$.orderUpdates[0].commData'),'$.smsSent') is null
)ORDER BY 1 DESC




select top 10 *  FROM Orders.OrderTransactionDetails WHERE  ISJSON(orderTransactionData)>0 and  OrderStatusCode ='COMM'  
--AND JSON_VALUE(JSON_QUERY(orderTransactionData,'$.preferenceData'),'$.sendSMS') ='true' 
AND JSON_QUERY(orderTransactionData,'$.orderUpdates') IS not NULL 
and
JSON_VALUE(JSON_QUERY(orderTransactionData,'$.orderUpdates[0].commData'),'$.smsSent') is null
ORDER BY 1 DESC



-- this is for email is null

select top 10 *  FROM Orders.OrderTransactionDetails WHERE  ISJSON(orderTransactionData)>0 and  OrderStatusCode ='COMM' and 
JSON_QUERY(orderTransactionData,'$.orderUpdates') IS not NULL 
and

 JSON_VALUE(JSON_QUERY(orderTransactionData,'$.orderUpdates[0].commData'),'$.emailSent') is null

--and orderId=200270317
ORDER BY 1 DESC

[otc].[GetPrefillOrderDetailsForMail] 200271421

UPDATE Orders.OrderTransactionDetails SET OrderTransactionData =JSON_MODIFY(OrderTransactionData,'$.preferenceData','{"preferenceData":{"sendEmail":true,"sendSMS":true,"profileLevelPreferences":false}}'), ModifyDate =GETDATE()WHERE orderId=200270515 AND orderStatusCode ='COMM'



UPDATE  Orders.OrderTransactionDetails  SET orderTransactionData ='{"preferenceData":{"sendEmail":true,"sendSMS":true,"profileLevelPreferences":false}}'
where orderTransactionId =1009446

select *from [otc].[GetAllCommOrders] 200271445