DECLARE @OrderID varchar(200) ='200265413'
DECLARE @NHMemberId varchar(200) ='NH202106672288'

 SELECT * FROM Orders.Orders where OrderID=@OrderID --NHMemberId=@NHMemberId 
 SELECT * FROM Orders.OrderItems where OrderID=@OrderID
SELECT * FROM Orders.OrderTransactionDetails where OrderID=@OrderID
--SELECT top 10  * FROM Orders.OrderTransactionDetails order by 1 desc
 SELECT * FROM Orders.OrderChangeRequests where OrderID=@OrderID
 select * from Orders.OrderChangeRequestItems where OrderId=@OrderID
 sp_helptext '[otc].[GetAllOTCOrderItemDetails_Shiva]' 'NH202106672288'

 sp_helptext '[otc].[InsertChangeRequestOrderTranasactionDetails]'

 [otc].[GetAllOTCOrderItemDetails] 200270230

 update Orders.OrderChangeRequests set IsActive =0
 where OrderChangeRequestID =3100

 select top 10 *from otc.userprofiles where nhmemberId ='NH202107081013'
 {"OrderCreation":{"sendEmail":false,"sendSMS":true,"isEmailUnsubscribed":false,"isSMSUnsubscribed":false}}
 select top 10* from orders.orders where orderid =200586570
 select top 10 *from insurance.insuranceConfig where configType ='otccontent'
 --update Orders.OrderChangeRequestItems set isActive=0
-- where OrderChangeRequestID =3100
-- update otc.userprofiles set preferences ='{"OrderCreation":{"sendEmail":true,"sendSMS":false}}'
 --where UserProfileId =18201
 -- otc.GetAllMemberOTCOrders 'NH202106672405'


 -- update Orders.Orders
--set OrderStatusCode='SHIP' --,isActive=0
--where OrderId='200265413' 
 select TOP 10  *from insurance.insuranceConfig where  configType ='DHELOGIN'  -- and  InsuranceCarrierID =372  -- 
  configType ='MEMBERPORTALLOGIN'  and
 ConfigData ='{"splashConfig":{"splashTemplate":"SplashLP","splashTitle" :"Welcome to NationsBenefits, proud future partner of Blue Medicare Advantage!","splashContent" :"Your benefits become effective with us on <strong>1\/1\/2022<\/strong>, so please check back with us then. Thank you for reaching out to NationsBenefits!"}}'

 INSERT INTO  insurance.insuranceConfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,isActive)
 values('MEMBERPORTALCONTENT',
 '{"splashConfig":{"splashTemplate":"SplashLP","splashTitle" :"Welcome to NationsBenefits, proud future partner of Blue Medicare Advantage!","splashContent" :"Your benefits become effective with us on <strong>1\/1\/2022<\/strong>, so please check back with us then. Thank you for reaching out to NationsBenefits!"}}'
 ,302,getDate(),'Mnanduri',getDate(),'Mnanduri',1)

 UPDATE  insurance.insuranceConfig SET ConfigType ='MEMBERPORTALLOGIN'
 WHERE   InsuranceCarrierID =302  AND configType ='MEMBERPORTALCONTENT'
  
  select top 10 *from Insurance.InsuranceConfigTypes

  select top 10 *from Insurance.InsuranceCarriers where InsuranceCarrierID=416
  select  *from Insurance.InsuranceCarriers where InsuranceCarrierID 
  in(select InsuranceCarrierID from insurance.insuranceConfig where  configType ='DHELOGIN' )
  select top 10 *from Insurance.InsuranceCarriers where InsuranceCarrierName='bluekc'
  select  InsuranceCarrierID, Json_value(CarrierConfig,'$.subdomain')as subdomain from Insurance.InsuranceCarriers where Json_value(CarrierConfig,'$.subdomain') ='bluekc'
 
 -- Inserts MEMBERPORTALLOGIN Configy type 
  INSERT INTO  Insurance.InsuranceConfigTypes (ConfigType,ConfifDescription,isActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
  VALUES('MEMBERPORTALLOGIN',
  'MEMBERPORTALLOGIN',
  1,'Mnanduri',getDate(),'Mnanduri',getDate()
  )

  -- MEMBERPORTALLOGIN splash pages inserts carriers
  DECLARE @carriers TABLE (carrierName VARCHAR(40))
	INSERT INTO @carriers VALUES('bluekc')
	INSERT INTO @carriers VALUES('zing')
	INSERT INTO @carriers VALUES('newhanoverhealthadvantage')
	INSERT INTO @carriers VALUES('reliance')
	INSERT INTO @carriers VALUES('optimahealth')
    INSERT INTO @carriers VALUES('virginiapremier')
	INSERT INTO @carriers VALUES('brighthealthcare')
	INSERT INTO @carriers VALUES('alignment')
	INSERT INTO @carriers VALUES('americanhealthadvantage')
	INSERT INTO @carriers VALUES('cchp')
	INSERT INTO @carriers VALUES('bcbsri')
	INSERT INTO @carriers VALUES('avmed')
	INSERT INTO @carriers VALUES('capitalbluecross')
	INSERT INTO @carriers VALUES('hap')
	INSERT INTO @carriers VALUES('hapempowered')
	INSERT INTO @carriers VALUES('molina')
	INSERT INTO @carriers VALUES('ExperienceHealth')
  
  SELECT * FROM @carriers

  DROP TABLE IF EXISTS #CarrerirsTmpTbl
  select *into #CarrerirsTmpTbl from (
  select insuranceCarrierId,
  Json_value(CarrierConfig,'$.subdomain')as subdomain 
  from Insurance.InsuranceCarriers 
  where Json_value(CarrierConfig,'$.subdomain') IN (SELECT carrierName fROM @carriers)
  )T

  SELECT *FROM  #CarrerirsTmpTbl

  select top 10 *from master.members where nhmemberId ='NH202107080776'

  

 

 







 

 

 

  insert into #Carriers 

  -- CONFIG DATA
  DECLARE @MEMBERPORTALCONTENT VARCHAR(40) ='MEMBERPORTALCONTENT'
  DECLARE @ConfigData NVARCHAR(MAX) ='{"splashConfig":{"splashTemplate":"SplashLP","splashTitle" :"Welcome to NationsBenefits, proud future partner of Blue Medicare Advantage!","splashContent" :"Your benefits become effective with us on <strong>1\/1\/2022<\/strong>, so please check back with us then. Thank you for reaching out to NationsBenefits!"}}'
  DECLARE @SysUser VARCHAR(40)='Mnanduri'
  
 

    -- Inserts MEMBERPORTALLOGIN Configy type  splashConfig
  SELECT  InsuranceCarrierID, Json_value(CarrierConfig,'$.subdomain')as subdomain from Insurance.InsuranceCarriers where Json_value(CarrierConfig,'$.subdomain') = @bluekc
 
 INSERT INTO  insurance.insuranceConfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,isActive)
  values(@MEMBERPORTALCONTENT,@ConfigData,302,getDate(),@SysUser,getDate(),@SysUser,1)
  select top 1 *From insurance.insuranceConfig order by 1 desc 