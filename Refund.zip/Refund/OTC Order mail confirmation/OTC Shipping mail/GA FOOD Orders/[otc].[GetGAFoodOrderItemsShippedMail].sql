 SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* =============================================                                  
  Author:Naresh Naspoori                                     
  Created Date: 14-JULY-2021                                  
  Description: OTC get GA food orders items to send order shipping mail and mobile sms.  
  =============================================                                  
  exec  [otc].[GetGAFoodOrderItemsShippedMail]    200585236     
*/                   
                     
CREATE PROC [otc].[GetGAFoodOrderItemsShippedMail] @OrderId BIGINT                                    
AS                                      
BEGIN          
  --DECLARE @OrderId BIGINT  =  200585236       
 SET NOCOUNT ON;   
  
 SELECT otd.orderId, c.orderTrackingNumber,itemTrack.*  
 FROM  Orders.OrderTransactionDetails otd WITH (NOLOCK)  
  CROSS APPLY OPENJSON(otd.OrderTransactionData, '$')   
  WITH(   
    orderTrackingNumber   VARCHAR(200)   '$.trackingNumber'   
   ,itemTracking NVARCHAR(MAX) 'strict $.itemTracking' AS JSON   
  )c  
    CROSS APPLY OPENJSON (c.itemTracking)    
  WITH(   
   nationsId   VARCHAR(200)   '$.itemNumber'   
  ) itemTrack  
    
     INNER JOIN [Orders].[Orders] oo WITH (NOLOCK) ON oo.OrderID=otd.orderId AND oo.OrderStatusCode=otd.OrderStatusCode   
  AND JSON_VALUE(OrderAmountData,'$.warehouseCode') IS NOT  NULL AND oo.isActive=1  
  WHERE otd.OrderStatusCode ='SHI' AND ISJSON(otd.OrderTransactionData)>0  AND otd.orderId=@OrderId  AND otd.isActive=1  
END  
  
  
  
  