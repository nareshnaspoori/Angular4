drop table #tempcount
CREATE table #tempcount (i INT, c NVARCHAR(MAX) CHECK (ISJSON(c)> 0  ))

INSERT INTO #tempcount VALUES (
1,
'[{"id":"101","name":"John"}, {"id":"102","name":"peter"}]')

SELECT * FROM #tempcount


 SELECT *
  FROM #tempcount
  CROSS APPLY OPENJSON(c) s
  WHERE i = 1
    AND JSON_VALUE(s.value, '$.id')=102



	WITH cte AS (
  SELECT *
  FROM #tempcount
  CROSS APPLY OPENJSON(c) s
  WHERE i = 1
    AND JSON_VALUE(s.value, '$.id')=102
) select *from cte
UPDATE cte
SET c = JSON_MODIFY(c, '$[' + cte.[key] + '].name', 'naresh')




--=================================  START UPDATE JSON array object add new columns inside any json array.

DECLARE @json nvarchar(max) = N'{"filterCriteria":[{"fieldId":"abc","filterData":[{"values":[{"id":1,"value":"1","text":"1"},{"id":2,"value":"2","text":"2"}],"filterType":"equals"}]},{"fieldId":"def","filterData":[{"values":[{"id":3,"value":"3","text":"3"},{"id":4,"value":"4","text":"4"}],"filterType":"equals"}]}]}'


SELECT @json = JSON_MODIFY(
   @json,
   CONCAT('$."filterCriteria"[', id1, '].filterData[', id2, '].values[', id3, '].name'),
   'dd'
)
FROM (
   SELECT j1.[key] AS id1, j3.[key] AS id2, j4.[key] AS id3
   FROM OPENJSON(@json, '$.filterCriteria') j1
   CROSS APPLY OPENJSON(j1.[value], '$') WITH (
      fieldId varchar(3) '$.fieldId',
      filterData nvarchar(max) '$.filterData' AS JSON
   ) j2
   CROSS APPLY OPENJSON(j2.filterData, '$') j3 
   CROSS APPLY OPENJSON (j3.[value], '$.values') j4
   CROSS APPLY OPENJSON (j3.[value], '$.values') WITH (
      id int '$.id'
   ) j5
   WHERE (j2.fieldId = 'def') AND (j5.id =3)
) t

SELECT @json



DECLARE @json nvarchar(max) = N'{"filterCriteria":[{"fieldId":"abc","filterData":[{"values":[{"id":1,"value":"1","text":"1"},{"id":2,"value":"2","text":"2"}],"filterType":"equals"}]},{"fieldId":"def","filterData":[{"values":[{"id":3,"value":"3","text":"3"},{"id":4,"value":"4","text":"4"}],"filterType":"equals"}]}]}'


 SELECT j1.[key] AS id1, j3.[key] AS id2, j4.[key] AS id3
   FROM OPENJSON(@json, '$.filterCriteria') j1
   CROSS APPLY OPENJSON(j1.[value], '$') WITH (
      fieldId varchar(3) '$.fieldId',
      filterData nvarchar(max) '$.filterData' AS JSON
   ) j2
   CROSS APPLY OPENJSON(j2.filterData, '$') j3 
   CROSS APPLY OPENJSON (j3.[value], '$.values') j4
   CROSS APPLY OPENJSON (j3.[value], '$.values') WITH (
      id int '$.id'
   ) j5
   WHERE (j2.fieldId = 'def') AND (j5.id =3)


   --- update specifiy array object add new  json propery inside json array. with key based query
DECLARE @json nvarchar(max) = N'{"preferenceData":{"sendEmail":true,"sendSMS":false,"profileLevelPreferences":false},"orderUpdates":[{"commTrigger":"OrderCreation","commData":{"emailSent":true,"contactReferenceID":270430}},{"commTrigger":"ShipmentCreation","commData":{"smsSent":true}}]}'


SELECT @json = JSON_MODIFY(
   @json,
   CONCAT('$."orderUpdates"[', id1, '].commData.name'),
   'dd'
)FROM (
 SELECT j1.[key] AS  id1, j3.[key] AS  id3   --, j3.[key] AS id3 --,  j4.[key] AS id3
   --FROM OPENJSON(@json, '$.preferenceData') j1
   FROM OPENJSON(@json, '$.orderUpdates')  j1
   CROSS APPLY OPENJSON(j1.[value], '$')with (
      commTrigger varchar(100) '$.commTrigger',
      commData nvarchar(max) '$.commData' AS JSON
   ) j2
   CROSS APPLY OPENJSON (j2.commData, '$') j3
   --CROSS APPLY OPENJSON (j3.[value], '$.values') WITH (
    --  id int '$.id'
   --) j5
   WHERE (j2.commTrigger = 'ShipmentCreation')  ---AND (j5.id =3)
   )t

   SELECT @json


   --======================
    -- table exapple--------------
   UPDATE orderS.orderTransactionDetails  SET orderTransactionData = JSON_MODIFY(
   JSON_MODIFY(orderTransactionData,
   CONCAT('$."orderUpdates"[', id1, '].commData.emailSent'),
   'false'),CONCAT('$."orderUpdates"[', id1, '].commData.mobileError'),'errr'
)
FROM (
SELECT j1.[key] AS  id1, j3.[key] AS  id3   --, j3.[key] AS id3 --,  j4.[key] AS id3
   FROM orderS.orderTransactionDetails j
   CROSS APPLY OPENJSON(j.orderTransactionData, '$.orderUpdates')  j1
   CROSS APPLY OPENJSON(j1.[value], '$')with (
      commTrigger varchar(100) '$.commTrigger',
      commData nvarchar(max) '$.commData' AS JSON
   ) j2
   CROSS APPLY OPENJSON (j2.commData, '$') j3
   --CROSS APPLY OPENJSON (j3.[value], '$.values') WITH (
    --  id int '$.id'
   --) j5
   WHERE (j2.commTrigger = 'ShipmentCreation')      ---AND (j5.id =3)
   )t
   where  orderId= 200585236   and orderStatusCode ='comm'  

   select *from orders.orderTransacotions
   --===================================END  START UPDATE JSON array object add new columns inside any json array. ===============================================================

   -- REPLACE AN ENTIRE JSON ARRAY OBJECT  --
   DECLARE @MyJson NVARCHAR(MAX) = N'{  
   "customerName":"mohan",
   "custId":"e35273d0-c002-11e9-8188-a1525f580dfd",
   "feeds":[  
      {  
         "feedId":"57f221d0-c310-11e9-8af7-cf1cf42fc72e",
         "feedName":"ccsdcdscsdc",
         "format":"Excel",
         "sources":[  
            {  
               "sourceId":69042417,
               "name":"TV 2 Livsstil"
            },
            {  
               "sourceId":69042419,
               "name":"Turk Max"
            }
         ]
      },
      {  
         "feedId":"59bbd360-c312-11e9-8af7-cf1cf42fc72e",
         "feedName":"dfgdfgdfgdfgsdfg",
         "format":"XmlTV",
         "sources":[  
            {  
               "sourceId":69042417,
               "name":"TV 2 Livsstil"
            },
            {  
               "sourceId":69042419,
               "name":"Turk Max"
            }
         ]
      }
   ]
}';

DECLARE @MyNewJson NVARCHAR(MAX) = '{"feedId": "this_is_an_entirely_new_node","feedName": "ccsdcdscsdc","format": "NewFormat","sources": [{"sourceId": 1,"name": "New Source 1"},{"sourceId": 2,"name": "New Source 2"}]}';

WITH Config_CTE AS (

    SELECT * FROM @MyJson AS Customer
    CROSS APPLY OPENJSON( configJSON, '$.feeds' ) AS Config
    WHERE
        Customer.CustomerId = '9ee07040-c001-11e9-b29a-55eb3439cd7c'
        AND JSON_VALUE( Config.value, '$.feedName' ) = 'ccsdcdscsdc'

)
UPDATE Config_CTE
SET configJSON = JSON_MODIFY( configJSON, '$.feeds[' + Config_CTE.[key] + ']', JSON_QUERY( @MyNewJson ) );
--===================================================-


--example-----------------orderTransactionData commData entire data updates we should bring existing Data and new data from api and use below query to update in specific json.

Declare @transData nvarchar(max)='{"commTrigger":"ShipmentCreation","commData":{"smsSent":true,"emailSent":true,"contactReferenceID":270430}}'

;WITH TransData_CTE AS (

    SELECT * FROM orders.orderTransactionDetails AS trans
    CROSS APPLY OPENJSON( orderTransactionData, '$.orderUpdates' ) AS orderUpdates
    WHERE
         trans.orderId= 200585236   and trans.orderStatusCode ='comm' 
        AND JSON_VALUE( orderUpdates.value, '$.commTrigger') = 'ShipmentCreation'

)
UPDATE TransData_CTE
SET orderTransactionData = JSON_MODIFY( orderTransactionData, '$.orderUpdates[' + TransData_CTE.[key] + ']', JSON_QUERY( @transData ) );

--------========================END-------------------------------------------------------------------------------------

 -- shipmentCreation with sms 
    update orders.orderTransactionDetails set OrderTransactionData = '{"preferenceData":{"sendEmail":true,"sendSMS":false,"profileLevelPreferences":false},"orderUpdates":[{"commTrigger":"OrderCreation","commData":{"emailSent":true,"contactReferenceID":270430}},{"commTrigger":"ShipmentCreation","commData":{"smsSent":true}}]}'
   where orderTransactionid =2056689

   -- default with sms 
    update orders.orderTransactionDetails set OrderTransactionData = '{"preferenceData":{"sendEmail":true,"sendSMS":false,"profileLevelPreferences":false},"orderUpdates":[{"commTrigger":"OrderCreation","commData":{"emailSent":true,"contactReferenceID":270430}}]}'
   where orderTransactionid =2056689

select top 20 * from Orders.OrderTransactionDetails WHERE  orderId =200585236 and orderStatusCode ='comm' order by 1 desc





















