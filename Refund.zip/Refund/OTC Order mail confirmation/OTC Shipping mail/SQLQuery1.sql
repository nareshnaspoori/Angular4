select top 10 *from orders.ORDERS  where orderId = 200585674  order by 1 desc -- 200585568 200585236
 SELECT top 20 * from Orders.ORDERS WHERE NhmemberId order by 1 desc
 select *From otc.userprofiles where nhmemberId IN (select NhmemberId from orders.ORDERS  where orderId = 200585682 ) 
  select top 20 * from Orders.OrderItems  where orderId = 200585682   -- 200585629 200585568 200585549 ---200585236 --200566648
 select top 20 * from Orders.OrderTransactionDetails WHERE OrderStatusCode ='shi' order by 1 desc   --200569359 
 select top 20 * from Orders.OrderTransactionDetails WHERE OrderStatusCode IN ('shi','COMM') and orderId =200585685 order by 1 desc   -- 200585559 200585549  200566403 
  select top 200 * from Orders.OrderTransactionDetails WHERE OrderStatusCode IN ('COMM','SHI')  order by OrderID desc
  select top 20 * from Orders.OrderTransactionDetails WHERE OrderStatusCode IN ('shi','COMM') and orderId =200587093 order by 1 desc

  select top 200 * from Orders.OrderTransactionDetails WHERE OrderStatusCode IN ('COMM')  order by 1 desc
  select top 50 * from [contact].[MailHistory] order by createdate desc
select top 50 * from [contact].[MailHistoryEmails] order by createdate desc
 

 select top 10 * from otc.userPRofiles where userName ='esiraj1111'

 select top 10 * from  [jobs].[PageActionProcessQueue] order by 1 desc
 select top 10 * from jobs.pageevents where eventcode in ('PR051','PR050') order by 1 desc 

  update  [jobs].[PageActionProcessQueue]  set processStatus =1  where pageEventId in(281508,
281507,
281506,
281505) 
 [otc].[GetOrderTrackingDetailsForShippedMail]    200587060
sp_helptext '[otc].[GetPrefillOrderDetailsForShippedMail]' 200585634  200585629  200585559

-- ga food shipment mail
 [otc].[GetPrefillGAFoodOrderDetailsShippedMail] 200587072

 -- normal order shippment mail
 [otc].[GetPrefillOrderDetailsForShippedMail] 200587072                                 
 delete from  Orders.OrderTransactionDetails where OrderTransactionId =2058147

 





 --- INSERT COMM record transaction Details 
 --insert into Orders.OrderTransactionDetails 
 --(orderId,OrderStatuSCode,OrderTransactionData ,isComplete, CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
-- VALUES(200585568,'COMM','{"preferenceData":{"sendEmail":true,"sendSMS":true,"profileLevelPreferences":true},"orderUpdates":[{"commTrigger":"OrderCreation","commData":{"emailSent":true,"contactReferenceID":270528}}]}',
 --1,GETDATE(),'MemberUser',GETDATE(),'MemberUser',1)


 --step 1
 --===============
 
-- UPATE ORDERS.ITEMS FOR  tracking NUmber 
  select top 20 * from Orders.OrderItems  where orderId = 200587265 
 UPDATE Orders.OrderItems SET itemData = N'{"quantity":1.0,"measuredIn":null,"nationsId":"6079","categories":"[\"First Aid & Medical Supplies\"]","healthConditions":"[]","catalogName":"EON Health Plan","catalogColorCode":"#F2604A","trackingNumber": "784060507188"}'
WHERE orderItemId =3601165

 UPDATE Orders.OrderItems SET itemData = N'{"quantity":1.0,"measuredIn":null,"nationsId":"5308","categories":"[\"Vitamins & Dietary Supplements\"]","healthConditions":"[\"Anemia\",\"Vitamin B12 Deficiency\"]","catalogName":"EON Health Plan","catalogColorCode":"#F2604A","trackingNumber": "784060507188"}'
WHERE orderItemId =3600798


--step 2
--=========
 --INSER SHI shippment record 
  insert into Orders.OrderTransactionDetails 
 (orderId,OrderStatuSCode,OrderTransactionData ,isComplete, CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
 VALUES(200587265,'SHI',
 
 N'[{
	    "orderDate": "08-20-2021",
		"carrier": "General Shipping",
		"serviceType": "FEDEX2",
		"orderId": 200587265,
		"trackingNumber": "784060507188",
		"trackingUrl": "http://www.fedex.com/Tracking?action=track&tracknumbers=784060507188",
		"shipDate": "08-17-2021",
		"shippingCost": "5.00",
		"taxCost": "0.0",
		"itemTracking": [
			{
				"itemNumber": "6079",
				"trackingNumber": "784060507188",
				"weight": "1",
				"units": "Pound"
			}
		]}
]',
 1,GETDATE(),'MemberUser',GETDATE(),'MemberUser',1)


 


-- update orders.orders statusCode 'SHI'
--step 3
--==============
 update orders.orders set orderStatusCode ='SHI'
WHERE orderId =200587265





 -- step 4
 --==================
--- INSERT PAGE EVENTS

  --select top 10 * from jobs.pageevents where eventcode in ('PR051','PR050') order by 1 desc 
  insert into jobs.pageevents (EventCode,ReferenceData,IsProcessed,IsActive,CreateDate,CreateUser,ModifyDate,ModifyUser)
  values('PR051','{"orderId":200587265,"trackingNumber":"784060507188","trackingUrl":"http://www.fedex.com/Tracking?action=track&tracknumbers=784060507188"}'
  ,0,1,getdate(),'system',getdate(),'system')

  select top 10  *from jobs.pageevents order by 1 desc
  -- normal otc orders
[otc].[GetPrefillOrderDetailsForShippedMail] 200587141 

sp_helptext [otc].[GetPrefillOrderDetailsForShippedMail] 200587265

-- ga food
 [otc].[GetPrefillGAFoodOrderDetailsShippedMail] 200587265

 -- for checking 
 select top 20 * from Orders.OrderTransactionDetails WHERE OrderStatusCode IN ('PAY','shi','COMM') and orderId =200587119 order by 1 desc



  select top 20 * from Orders.OrderTransactionDetails WHERE OrderStatusCode IN ('PAY','shi','COMM','bep') and orderId =200587119 order by 1 desc

  [otc].[GetPrefillOrderDetailsForMail] 200587119


  select top 10 *from orders.ORDERS  where orderId = 200587119  order by 1 desc 
 -- UPDATE jobs.pageevents set referencedata ='{"orderId":200585629,"trackingNumber":"784060507188","trackingUrl":"http://www.fedex.com/Tracking?action=track&tracknumbers=784060507187"}' 
  --, eventCode='PR051',isprocessed =0
 -- where pageeventId =281275

 select top 10 * from otc.userProfiles order by 1 desc









-- 200585585
  --ga foods   200585568 200569359 working    200585236 200574346
   SELECT top 20 orderid,JSON_VALUE(OrderAmountData,'$.warehouseCode'),orderAmountData from Orders.ORDERS WHERE JSON_VALUE(OrderAmountData,'$.warehouseCode') is not null   order by 1 desc
      SELECT top 20 JSON_VALUE(OrderAmountData,'$.warehouseCode'),orderId from Orders.ORDERS WHERE JSON_VALUE(OrderAmountData,'$.warehouseCode') is not null   order by 1 desc
	  select top 10 *from orders.ORDERS  where orderId =200585236 order by 1 desc
	  select top 20 * from Orders.OrderItems  where orderId IN 
	  (SELECT top 20 orderId from Orders.ORDERS WHERE JSON_VALUE(OrderAmountData,'$.warehouseCode') is not null   order by 1 desc)
	  order by 1 desc
  select top 20 * from Orders.OrderTransactionDetails  where orderId IN 
	  (SELECT top 20 orderId from Orders.ORDERS WHERE JSON_VALUE(OrderAmountData,'$.warehouseCode') is not null   order by 1 desc) and OrderStatusCode ='shi'
	  order by 1 desc
 
 select top 20 * from Orders.OrderTransactionDetails  where orderId 
  IN(SELECT orderid   from Orders.ORDERS WHERE JSON_VALUE(OrderAmountData,'$.warehouseCode') is not null    ) AND OrderStatusCode ='shi' 
   
   select top 20  orderId,orderStatusCode from Orders.OrderTransactionDetails  where orderId 
  IN(SELECT orderid   from Orders.ORDERS WHERE JSON_VALUE(OrderAmountData,'$.warehouseCode') is  null    ) AND OrderStatusCode IN ('shi','COMM') 
  group by orderId,orderStatusCode

  200585236

  --- PAGE EVENTS ---- QUERY
 sp_helptext '[otc].[GetPrefillOrderDetailsForMail]'
  select top 10 * from jobs.pageevents where eventcode in ('PR051','PR050') order by 1 desc 
  UPDATE jobs.pageevents set referencedata ='{"orderId":200585236,"trackingNumber":"784060507188","trackingUrl":"http://www.fedex.com/Tracking?action=track&tracknumbers=784060507187"}' 
  , eventCode='PR051',isprocessed =0
  where pageeventId =281275

  -- with orderCreation
  update orders.orderTransactionDetails set OrderTransactionData ='{"preferenceData":{"sendEmail":true,"sendSMS":false,"profileLevelPreferences":false},"orderUpdates":[{"commTrigger":"OrderCreation","commData":{"emailSent":true,"contactReferenceID":270430}}]}' 
   where orderTransactionid =2056689
  
   
   -- shipmentCreation with sms 
    update orders.orderTransactionDetails set OrderTransactionData = '{"preferenceData":{"sendEmail":true,"sendSMS":false,"profileLevelPreferences":false},"orderUpdates":[{"commTrigger":"OrderCreation","commData":{"emailSent":true,"contactReferenceID":270430}},{"commTrigger":"ShipmentCreation","commData":{"smsSent":true}}]}'
   where orderTransactionid =2056689
   
   select top 20 * from Orders.OrderTransactionDetails WHERE  orderId =200585236 order by 1 desc
   select top 20 * from Orders.OrderItems  where orderId =200585236  200585429    200585236
    select top 20 * from Orders.OrderTransactionDetails WHERE OrderStatusCode ='shi' order by 1 desc
	    select top 20 * from Orders.OrderTransactionDetails WHERE OrderStatusCode ='COMM' and  orderId =200585445   order by 1 desc --200585236
   
   ---SHIPPING EMAIL
   [otc].[GetPrefillOrderDetailsForShippedMail]200566403  200585236 200585438    
   [otc].[GetPrefillGAFoodOrderDetailsShippedMail]190002555 200585236


   -- Confirmation Email 

   [otc].[GetPrefillOrderDetailsForMail] 200585549
   
   '[{"orderDate":"07-13-2021","carrier":"General Shipping","serviceType":"FEDEX2","orderId":200585236,"trackingNumber":"784060507188","trackingUrl":"http://www.fedex.com/Tracking?action=track&tracknumbers=784060507187","shipDate":"02-24-2021","shippingCost":"15.34","taxCost":"0.0","itemTracking":[{"itemNumber":"6056","trackingNumber":"784060507188","weight":"1","units":"Pound"},{"itemNumber":"6079","trackingNumber":"784060507188","weight":"1","units":"Pound"}]}]'
   
  200585236
  {"orderId":200585449}
  {"orderId":200585447}
  {"orderId":200585438}

  200585297

  update Orders.OrderTransactionDetails  set orderId =200566648 where OrderTransactionID =2056423
  select distinct top 100   c.carrier,OrderID,OrderTransactionData
  -- ,JSON_VALUE(p.value,'$.itemNumber') as itemNumber
   from Orders.OrderTransactionDetails 
 cross apply openjson (OrderTransactionData,'$')
 with(
  carrier   VARCHAR(200)   '$.carrier'  
 )
 as  c
 --cross apply openJson(c.value ,'$.itemTracking')AS p
 
  WHERE OrderStatusCode ='shi' and ISJSON(OrderTransactionData)>0 and c.carrier ='General Shipping'   --and orderId =200585179

  order by orderId desc


 select top 20 * from Orders.OrderTransactionDetails  where orderId =200566648 order by 1 desc
 select top 20 * from Orders.OrderItems  where orderId =200566648 order by 1 desc
  select top 20 * from Orders.OrderTransactionDetails  where orderId =200574842 order by 1 desc

  DROP TABLE IF EXISTS #transItemTrackingOrders
  SELECT *INTO #transItemTrackingOrders
  FROM (
 SELECT top 10 orderId,JSON_VALUE(OrderTransactionData,'$[0].trackingNumber')AS orderTrackingNumber
 ,JSON_VALUE(OrderTransactionData,'$[0].trackingUrl')AS trackingUrl
 ,trans.* from Orders.OrderTransactionDetails
cross apply OPENJSON (OrderTransactionData,'$[0].itemTracking')  
WITH (   
    nationsId   VARCHAR(200)   '$.itemNumber' , 
  itemTrackingNumber  VARCHAR(200)  '$.trackingNumber'
 ) as trans
 where   OrderStatusCode ='shi' and orderId=200585236 and ISJSON(OrderTransactionData)>0 order by 1 desc
 ) AS T
 
 select *from  #transItemTrackingOrders 

 select oi.*,tro.orderTrackingNumber,tro.trackingUrl from [Orders].[OrderItems] oi  
 INNER JOIN #transItemTrackingOrders tro  ON tro.orderId = oi.orderId  AND tro.nationsId  =JSON_VALUE(oi.itemData,'$.nationsId') 
 AND JSON_VALUE(oi.itemData,'$.trackingNumber') = tro.itemTrackingNumber 


 SELECT JSON_Query(OrderTransactionData,'$.orderUpdates') as orderUpdates FROM Orders.OrderTransactionDetails WHERE orderId={orderId} AND orderStatusCode ='COMM'
  select top 200 * from Orders.OrderTransactionDetails WHERE OrderStatusCode IN ('COMM','SHI')  order by 1 desc
 SELECT top 10 otd.orderId , c.* FROM  Orders.OrderTransactionDetails  otd
		CROSS APPLY OPENJSON(otd.OrderTransactionData, '$.orderUpdates') 
		WITH( commTrigger   VARCHAR(200) '$.commTrigger' ,commData NVARCHAR(MAX) 'strict $.commData' AS JSON )c
		where otd.orderStatusCode ='comm'  and c.commTrigger ='ordercreation'




		WITH cte AS (
		SELECT otd.orderId , itemTrack.*
	FROM  Orders.OrderTransactionDetails  otd
		CROSS APPLY OPENJSON(otd.OrderTransactionData, '$') 
		WITH( 
			orderUpdates NVARCHAR(MAX) 'strict $.orderUpdates' AS JSON 
		)c
	   CROSS APPLY OPENJSON (c.orderUpdates)  
		WITH( 
			commTrigger varchar(100)  '$.commTrigger'
			,commData nvarchar(max) '$.commData' as json
		) itemTrack
		WHERE otd.orderId=200585236 and orderstatusCode ='comm' --AND itemTrack.commTrigger ='ShipmentCreation'
		) select *into #trandTbl from cte

		select *from #trandTbl for JSOn auto
		--DROP TABLE #trandTbl


		DECLARE  @newjson NVARCHAR(MAX)
		SET @newjson = '{"smsSent":true,"emailSent": true,"contactReferenceID": 270523}'
		UPDATE #trandTbl SET commData =  JSON_QUERY(@newjson) 
		WHERE commTrigger='ShipmentCreation'
		--JSON_MODIFY(commData,'append $.smsSent',JSON_QUERY('{"emailSent": true}'))

		update  Orders.OrderTransactionDetails set  OrderTransactionData = JSON_MODIFY(OrderTransactionData,'$.orderUpdates').
		from  Orders.OrderTransactionDetails o inner join #trandTbl k ON k.ORDERiD =O.ORDERiD 
		WHERE o.otd.orderStatusCode ='comm' and k.commTrigger ='ShipmentCreation'


		select *from   
		  Orders.OrderTransactionDetails o inner join #trandTbl k ON k.ORDERiD =O.ORDERiD 
		WHERE o.orderStatusCode ='comm' and k.commTrigger ='ShipmentCreation'




		UPDATE cte set commData='{"smsSent":true,"emailSent": true,"contactReferenceID": 270523}'

		 JSON_MODIFY(commData,  '{"smsSent":true,"emailSent": true,"contactReferenceID": 270523}')  
		 
		 
		 (commData,'{"smsSent":true,"emailSent": true,"contactReferenceID": 270523}') =




 SELECT *
  FROM Orders.OrderTransactionDetails  
  CROSS APPLY OPENJSON(OrderTransactionData,'strict $.orderUpdates') s
  WHERE  orderId=200585236 and  orderstatusCode ='comm' -- i = 1
    --AND JSON_VALUE(s.value, '$.id')=102

	sp_helptext 'otc.approveRefundRequest'

	
select top 50 * from [contact].[MailHistory] order by createdate desc
select top 50 * from [contact].[MailHistoryEmails] order by createdate desc



 Declare @transData nvarchar(max)='{"commTrigger":"ShipmentCreation","smsSent":true,"emailSent": true,"contactReferenceID": 270523}'
 	;WITH cte AS (
  SELECT *
  FROM Orders.OrderTransactionDetails t
  CROSS APPLY OPENJSON(t.orderTransactionData)
  WITH(
  orderUpdates NVARCHAR(MAX) 'strict $.orderUpdates' AS JSON 
  )s
  CROSS APPLY OPENJSON(s.orderUpdates) k
  WHERE t.orderId=200585236 and t.orderstatusCode ='comm'
    AND JSON_VALUE(k.value, '$.commTrigger')='ShipmentCreation'
)--select value  from cte 


update cte SET value = JSON_MODIFY(value, '$.commData', @transData)




 Declare @transData nvarchar(max)='{"commTrigger":"ShipmentCreation","smsSent":true,"emailSent": true,"contactReferenceID": 270523}'
 	
	;WITH cte AS (
  SELECT *
  FROM Orders.OrderTransactionDetails t
  CROSS APPLY OPENJSON(t.orderTransactionData,'$.orderUpdates')k
 
 -- CROSS APPLY OPENJSON(s.orderUpdates) k
  WHERE t.orderId=200585236 and t.orderstatusCode ='comm'
   AND JSON_VALUE(k.value, '$.commTrigger')='ShipmentCreation'
)--select *  from cte 

--JSON_VALUE(value,'$.commData.smsSent')



UPDATE cte
SET orderTransactionData = JSON_MODIFY(orderTransactionData,'$.orderUpdates.[' + cte.[key] + '].commData', 'Joe')

 SELECT *
  FROM Orders.OrderTransactionDetails   where orderId=200585236 and orderstatusCode ='comm'


  --- WORKING CODE BELOW FOR array update.

  -- new key add and update in commData
   UPDATE orderS.orderTransactionDetails  SET orderTransactionData = JSON_MODIFY(
   JSON_MODIFY(orderTransactionData,
   CONCAT('$."orderUpdates"[', id1, '].commData.emailSent'),
   'false'),CONCAT('$."orderUpdates"[', id1, '].commData.mobileError'),'errr1'
)
FROM (
SELECT j1.[key] AS  id1, j3.[key] AS  id3   --, j3.[key] AS id3 --,  j4.[key] AS id3
   FROM orderS.orderTransactionDetails j
   CROSS APPLY OPENJSON(j.orderTransactionData, '$.orderUpdates')  j1
   CROSS APPLY OPENJSON(j1.[value], '$')with (
      commTrigger varchar(100) '$.commTrigger',
      commData nvarchar(max) '$.commData' AS JSON
   ) j2
   CROSS APPLY OPENJSON (j2.commData, '$') j3
   --CROSS APPLY OPENJSON (j3.[value], '$.values') WITH (
    --  id int '$.id'
   --) j5
   WHERE (j2.commTrigger = 'ShipmentCreation')      ---AND (j5.id =3)
   )t
   where  orderId= 200585236   and orderStatusCode ='comm'  