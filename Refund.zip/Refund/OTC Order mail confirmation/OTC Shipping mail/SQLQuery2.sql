/****** Object:  StoredProcedure [npn].[ReminderEmailsForProviderAgreement]    Script Date: 27-10-2020 12:14:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- Exec  npn.ReminderEmailsForProviderAgreement 
CREATE PROCEDURE [npn].[ReminderEmailsForProviderAgreement]
@NoOfDays Int = -45
AS
BEGIN
	--verify isagreementcompleted != 1 or isregistrationcompleted != 1
	----drop table #eligibilerecords
	--SELECT				LegalBusinessName, max(TD.Transactionkey) as TransactionKey, TypeCode, Email, 
	--					max(Json_value(AgreementData,'$.owner.firstName'))  as OwnerFirstName, 
	--					max(Json_value(AgreementData,'$.owner.middleName')) as OwnerMiddleName, 
	--					max(Json_value(AgreementData,'$.owner.lastName')) as OwnerLastName,   
	--					max(TD.ModifyDate) As ModifiedDate, 
	--					max(Status) as Status into #eligibilerecords
	--FROM				NPN.TRANSACTIONDETAILS TD
	--INNER JOIN			NPN.PROVIDERPREREGISTRATION PPR ON PPR.TRANSACTIONKEY = TD.TRANSACTIONKEY
	--WHERE				TD.MODIFYDATE >= DATEADD(DAY, -45, GETDATE()) 	
	--					AND	IsAgreementCompleted != 1 or IsRegistrationCompleted != 1
	--					--AND TYPECODE NOT IN ('NEWLEAD')
	--					--AND STATUS NOT IN ('NEWLEAD')
	--					--AND [STATUS] = 'NEWLEAD'
	--					--AND TYPECODE != 'NEWLEAD'
	--					AND PPR.IsActive = 1 
	--					AND PPR.UnSubscribe = 0
	--GROUP BY			LegalBusinessName, TypeCode, Email
	
	--select *, datediff(day, ModifiedDate, getdate()) as nob from #eligibilerecords 



	--Drop table #PreRegDtls
	SELECT				PREG.LegalBusinessName, PREG.Transactionkey, PREG.Email, PP.AdditionalData,						
						Json_value(AdditionalData,'$.owner.firstName') as OwnerFirstName, 
						Json_value(AdditionalData,'$.owner.middleName') as OwnerMiddleName, 
						Json_value(AdditionalData,'$.owner.lastName') as OwnerLastName,
						PP.IsActive, PREG.UnSubscribe, PREG.IsAgreementCompleted,
						PREG.IsRegistrationCompleted
	INTO				#PreRegDtls
	FROM				NPN.PROVIDERPREREGISTRATION PREG
	INNER JOIN			NPN.PROVIDERPROFILES PP ON PP.TRANSACTIONKEY = PREG.TRANSACTIONKEY
	WHERE				IsAgreementCompleted != 1 OR IsRegistrationCompleted != 1						
						AND PREG.IsActive = 1 
						AND PP.IsActive = 1
						AND UnSubscribe = 0
						
	
	--select * from #PreRegDtls
	--set @NoOfDays=@NoOfDays-6;
	--Drop table #TransDtls
	SELECT				Transactionkey, TypeCode, min(Status) as Status, max(ModifyDate) as ModifyDate into #TransDtls
	FROM				NPN.TRANSACTIONDETAILS 	
	WHERE				(ModifyDate >= DATEADD(DAY, @NoOfDays, GETDATE()) or datediff(day, ModifyDate, getdate()) >= -(@NoOfDays))							
						AND IsActive = 1 
						AND STATUS != 'NEWLEAD'
	GROUP BY			TransactionKey, TypeCode
	--select * from 	#TransDtls		
	
	

	--select * from #PreRegDtls PPR
	--select * from 	#TransDtls	TD	

	select PPR.LegalBusinessName, TD.Transactionkey, TypeCode, Email, 
						--Json_value(AdditionalData,'$.owner.firstName')  as OwnerFirstName, 
						--Json_value(AdditionalData,'$.owner.middleName') as OwnerMiddleName, 
						--Json_value(AdditionalData,'$.owner.lastName') as OwnerLastName,   
						OwnerFirstName,
						OwnerMiddleName, 
						 OwnerLastName, 
						TD.ModifyDate, 
						Status as Status, datediff(day, TD.ModifyDate, getdate()) as NumberOfDays from 	#TransDtls	TD	
	inner join			#PreRegDtls PPR on PPR.TransactionKey = TD.TransactionKey
	where				Status != 'NEWLEAD' AND
						PPR.ISACTIVE = 1 AND
						PPR.UNSUBSCRIBE = 0 AND
						(ISAGREEMENTCOMPLETED != 1 or ISREGISTRATIONCOMPLETED != 1) AND
						--(((datediff(minute,TD.ModifyDate, getdate())) between 4319 and 4321) or datediff(day, TD.ModifyDate, getdate()) >= -(@NoOfDays))

						((datediff(day, TD.ModifyDate, getdate()) % 3) = 0 and datediff(day, TD.ModifyDate, getdate()) > 2) or  datediff(day, TD.ModifyDate, getdate()) >= -(@NoOfDays)


								

						
	
	
--select 	Json_value(AgreementData,'$.owner.firstName')  as OwnerFirstName					
						
--						 from 	#TransDtls	TD	
--	inner join			#PreRegDtls PPR on PPR.TransactionKey = TD.TransactionKey
--	where				Status != 'NEWLEAD' AND
--						PPR.ISACTIVE = 1 AND
--						PPR.UNSUBSCRIBE = 0 AND
--						(ISAGREEMENTCOMPLETED != 1 or ISREGISTRATIONCOMPLETED != 1)




	--select count(*) from npn.transactiondetails TD
	--INNER JOIN NPN.PROVIDERPREREGISTRATION PPR ON PPR.TRANSACTIONKEY = TD.TRANSACTIONKEY
	
	--where TD.MODIFYDATE >= DATEADD(DAY, -45, GETDATE()) and status NOT in ('NEWLEAD') 
	--AND ISAGREEMENTCOMPLETED = 0 OR ISREGISTRATIONCOMPLETED = 0


	--select count(*) from npn.transactiondetails TD
	--INNER JOIN NPN.PROVIDERPREREGISTRATION PPR ON PPR.TRANSACTIONKEY = TD.TRANSACTIONKEY
	
	--where td.MODIFYDATE >= DATEADD(DAY, -45, GETDATE()) and status NOT in ('NEWLEAD')
	--AND ISAGREEMENTCOMPLETED != 0 OR ISREGISTRATIONCOMPLETED != 0



	-- Read all the npn.transactiondetails table modifydate and its compare 45 days / 1080 hours from today
	   -- assume 10 records 
	   -- all the records which older than 45 days or 1080 hours DeActive the contract by making IsActive = 0 in npn.providerpreregistration table based on transactionkey
	
	--SELECT COUNT(*) FROM NPN.TRANSACTIONDETAILS

	-- GET THE RECORDS BETWEEN 45 DAYS AND TODAY
	--SELECT				Transactionkey, TypeCode, [Status], ModifyDate
	--FROM				NPN.TRANSACTIONDETAILS
	--WHERE				MODIFYDATE >= DATEADD(DAY, -45, GETDATE()) AND
	--					[Status] in ('AGREEMENTSENT', 'AGREEMENTSENT_VIEWED')
	--					AND TypeCode = 'PROV_AGR'

	-- UPDATING ISACTIVE  = 0 TO DISABLE THE EMAIL LINK OLDER THAN 45 DAYS
	--UPDATE			    NPN.PROVIDERPREREGISTRATION SET ISACTIVE = 0 
	--WHERE				TRANSACTIONKEY IN ( 
	--SELECT				Transactionkey
	--FROM				NPN.TRANSACTIONDETAILS
	--WHERE				MODIFYDATE < DATEADD(DAY, -45, GETDATE()) AND
	--					[Status] in ('AGREEMENTSENT', 'AGREEMENTSENT_VIEWED'))

	--SELECT				COUNT(*)
	--FROM				NPN.TRANSACTIONDETAILS
	--WHERE				MODIFYDATE >= DATEADD(DAY, -45, GETDATE()) AND
	--					[Status] in ('AGREEMENTSENT', 'AGREEMENTSENT_VIEWED')
	
	--SELECT				COUNT(*)
	--FROM				NPN.TRANSACTIONDETAILS
	--WHERE				MODIFYDATE < DATEADD(DAY, -45, GETDATE()) AND
	--					[Status] in ('AGREEMENTSENT', 'AGREEMENTSENT_VIEWED')

	--SELECT				COUNT(*)
	--FROM				NPN.TRANSACTIONDETAILS
	--WHERE				[Status] in ('AGREEMENTSENT', 'AGREEMENTSENT_VIEWED')

	-- Get all the records and loop based on transactionkey
	--select top 1 * from npn.providerpreregistration
	-- Inner join with npn.providerpreregistration table based on email 

	-- FOR JOIN NOW TEMPLATE
	
	--drop table #toprecords
	--SELECT				LegalBusinessName, max(TD.Transactionkey) as TransactionKey, TypeCode, Email, 
	--					max(TD.ModifyDate) As ModifiedDate into #toprecords
	--FROM				NPN.TRANSACTIONDETAILS TD
	--INNER JOIN			NPN.PROVIDERPREREGISTRATION PPR ON PPR.TRANSACTIONKEY = TD.TRANSACTIONKEY
	--WHERE				TD.MODIFYDATE >= DATEADD(DAY, -45, GETDATE()) AND
	--					[Status] in ('AGREEMENTSENT', 'AGREEMENTSENT_VIEWED')
	--					AND PPR.IsActive = 1 
	--GROUP BY			LegalBusinessName, TypeCode, Email
	
	--select *, datediff(day, ModifiedDate, getdate()) as nob from #toprecords


	

	--where datediff(day, ModifiedDate, getdate()) <= 45


	--SELECT				LegalBusinessName, max(TD.Transactionkey) as TransactionKey, TypeCode, Email, 
	--					max(TD.ModifyDate) As ModifiedDate
	--FROM				NPN.TRANSACTIONDETAILS TD
	--INNER JOIN			NPN.PROVIDERPREREGISTRATION PPR ON PPR.TRANSACTIONKEY = TD.TRANSACTIONKEY
	--WHERE				TD.MODIFYDATE >= DATEADD(DAY, -3, GETDATE()) AND
	--					[Status] in ('AGREEMENTSENT', 'AGREEMENTSENT_VIEWED')
	--					AND PPR.IsActive = 1
	--GROUP BY			LegalBusinessName, TypeCode, Email




	-- FOR WE CANT WAIT TEMPLATE

	--SELECT				LegalBusinessName, max(TD.Transactionkey) as TransactionKey, TypeCode, Email, 
	--					max(TD.ModifyDate) As ModifiedDate
	--FROM				NPN.TRANSACTIONDETAILS TD
	--INNER JOIN			NPN.PROVIDERPREREGISTRATION PPR ON PPR.TRANSACTIONKEY = TD.TRANSACTIONKEY
	--WHERE				TD.MODIFYDATE >= DATEADD(DAY, -45, GETDATE()) AND
	--					[Status] in ('DRAFT', 'SUBMITTED', 'AUTHORIZED')
	--					AND PPR.IsActive = 1 AND TypeCode = 'PROV_AGR'
	--GROUP BY			LegalBusinessName, TypeCode, Email
	

	--SELECT				LegalBusinessName, max(TD.Transactionkey) as TransactionKey, TypeCode, Email, 
	--					max(TD.ModifyDate) As ModifiedDate
	--FROM				NPN.TRANSACTIONDETAILS TD
	--INNER JOIN			NPN.PROVIDERPREREGISTRATION PPR ON PPR.TRANSACTIONKEY = TD.TRANSACTIONKEY
	--WHERE				TD.MODIFYDATE >= DATEADD(DAY, -3, GETDATE()) AND
	--					[Status] in ('DRAFT', 'SUBMITTED', 'AUTHORIZED')
	--					AND PPR.IsActive = 1 AND TypeCode = 'PROV_AGR'
	--GROUP BY			LegalBusinessName, TypeCode, Email

	--SELECT DISTINCT STATUS, TYPECODE FROM NPN.TRANSACTIONDETAILS 

--select * from npn.transactiondetails where transactionkey = 'C3E915C4-60C5-4080-BF60-0495248A2FC6'

	-- and compare with contact.mailhistory agreement mail sent modifydate with todate
	   
	   --SELECT DATEPART(HOUR, MODIFYDATE) FROM NPN.TRANSACTIONDETAILS order by 1 desc
END
GO


