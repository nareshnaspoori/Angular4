/* =============================================                                      
  Author:Naresh Naspoori                                         
  Updated Date:13-JULY-2021                                      
  Description: OTC get SHIPPING orders details with trackingNumbers to send shipped order details mail and mobile sms.      
  Update History:    
  =============================================                                      
  exec  [otc].[GetPrefillOrderDetailsForShippedMail] 200587093                                   
*/                       
                            
ALTER  PROC [otc].[GetPrefillOrderDetailsForShippedMail] @OrderId BIGINT                                          
AS                                            
BEGIN                
 --DECLARE @OrderId BIGINT  = 200587093             
           
 SET NOCOUNT ON;         
  DECLARE @isSendEmail BIT =0           
  DECLARE @isSendSMS BIT =0        
  DECLARE @trackingNumber VARCHAR(400)
  DECLARE @isConfiguredForEmail BIT
  DECLARE @isConfiguredForSMS BIT
 DROP TABLE          
 IF EXISTS  #transShippedItemTrackingOrders        
      
  CREATE TABLE  #transShippedItemTrackingOrders (        
   orderId BIGINT        
   ,orderTrackingNumber VARCHAR(200)      
   ,nationsId VARCHAR(200)      
   ,itemTrackingNumber varchar(100)      
   )        
   INSERT INTO #transShippedItemTrackingOrders      
   EXEC [otc].[GetOrderTrackingDetailsForShippedMail] @OrderId        
      
       
           
 DECLARE @nhMemberId NVARCHAR(40) =(SELECT nhmemberId FROM Orders.Orders WHERE orderId =@OrderId)             
           
 SELECT @isConfiguredForEmail= CAST(IIF(JSON_VALUE(ConfigData,'$.Preferences.OrderUpdates.sendEmail') = 'true', 1, 0)AS BIT),
                               @isConfiguredForSMS = CAST(IIF(JSON_VALUE(ConfigData,'$.Preferences.OrderUpdates.sendSMS') = 'true', 1, 0)AS BIT) FROM insurance.insuranceConfig           
                               WHERE InsuranceCarrierID IN ( SELECT JSON_VALUE(memberData,'$.clientCarrierId') FROM Orders.Orders WHERE orderId =@OrderId AND ConfigType='OTCAPP')         
   
 PRINT 'isConfiguredForEmail '+CAST(@isConfiguredForEmail  AS VARCHAR(4))          
        
 PRINT 'isConfiguredForSMS '+ CAST(@isConfiguredForSMS  AS VARCHAR(4))          
            
 DECLARE @isProfileLevelPreferences BIT = (SELECT  CAST(IIF(JSON_VALUE(OrderTransactionData,'$.preferenceData.profileLevelPreferences') = 'true', 1, 0)AS BIT)  FROM  Orders.OrderTransactionDetails          
                                     WHERE OrderID =@OrderId AND  OrderStatusCode ='COMM' AND IsActive=1)          
PRINT 'isProfileLevelPreferences '+ CAST(@isProfileLevelPreferences  AS VARCHAR(4))          
    
    
-- UnSubscribed in profileLevel    
 DECLARE @isProfileLevelEmailUnSubscribed BIT =(SELECT  CAST(IIF(JSON_VALUE(Preferences,'$.OrderCreation.isEmailUnsubscribed') = 'true', 1, 0)AS BIT) FROM otc.UserProfiles WHERE nhmemberid=@nhMemberId)       
PRINT 'isProfileLevelEmailUnSubscribed '+ CAST(@isProfileLevelEmailUnSubscribed  AS VARCHAR(4))       
    
-- UnSubscribed in Order Transaction level    
 DECLARE @isOrderLevelEmailUnSubscribed BIT =(SELECT  CAST(IIF(JSON_VALUE(OrderTransactionData,'$.preferenceData.isEmailUnsubscribed') = 'true', 1, 0)AS BIT)  FROM  Orders.OrderTransactionDetails where OrderID =@OrderId AND  OrderStatusCode ='COMM' AND IsActive=1)      
PRINT 'isOrderLevelEmailUnSubscribed '+ CAST(@isOrderLevelEmailUnSubscribed  AS VARCHAR(4))       
    
    
          
 IF(@isProfileLevelPreferences = 1 AND @isProfileLevelEmailUnSubscribed = 0)          
 BEGIN           
     SET @isSendEmail  = (SELECT  CAST(IIF(JSON_VALUE(Preferences,'$.OrderCreation.sendEmail') = 'true', 1, 0)AS BIT) FROM otc.UserProfiles WHERE nhmemberid=@nhMemberId)          
  PRINT 'UserProfiles isSendEmail '+ CAST(@isSendEmail  AS VARCHAR(4))          
            
  SET @isSendSMS  = (SELECT  CAST(IIF(JSON_VALUE(Preferences,'$.OrderCreation.sendSMS') = 'true', 1, 0)AS BIT) FROM otc.UserProfiles WHERE nhmemberid=@nhMemberId)          
  PRINT 'UserProfiles isSendSMS '+ CAST(@isSendSMS  AS VARCHAR(4))          
 END          
ELSE           
 BEGIN          
     IF(@isProfileLevelPreferences = 0 AND @isOrderLevelEmailUnSubscribed = 0)          
     SET @isSendEmail  =(SELECT  CAST(IIF(JSON_VALUE(OrderTransactionData,'$.preferenceData.sendEmail') = 'true', 1, 0)AS BIT)  FROM  Orders.OrderTransactionDetails where OrderID =@OrderId AND  OrderStatusCode ='COMM' AND IsActive=1)          
        PRINT 'OrderTransaction isSendEmail '+ CAST(@isSendEmail  AS VARCHAR(4))          
               
     SET @isSendSMS  = (SELECT  CAST(IIF(JSON_VALUE(OrderTransactionData,'$.preferenceData.sendSMS') = 'true', 1, 0)AS BIT)  FROM  Orders.OrderTransactionDetails where OrderID =@OrderId AND  OrderStatusCode ='COMM' AND IsActive=1)          
        PRINT 'OrderTransaction isSendSMS '+ CAST(@isSendSMS  AS VARCHAR(4))          
 END          
          
 IF(@isConfiguredForEmail = 1 OR @isConfiguredForSMS =1 )              
 BEGIN           
   BEGIN          
   SELECT DISTINCT oi.OrderId                
   ,oo.CreateDate AS 'OrderCreateDate'                                                  
   ,(                                                  
   SELECT DISTINCT oi.ItemCode AS 'ItemCode'                                                  
   ,oim.ItemName                                                  
   ,oi.Quantity                                                  
   ,oi.STATUS ItemStatus                                     
   ,cast(oi.UnitPrice AS DECIMAL(18, 2)) 'UnitPrice'                 
   ,CONCAT (                                                  
    '/'                                                  
    ,oim.NationsId                                                  
    ,'/'                                                  
    ,oim.NationsId                                                  
    ,'_Front.jpg'                                                  
    ) AS 'ItemMedialUrl'                                                  
   ,oim.NationsId AS 'ItemAttributeValue' -- NationsID source changed from ItemMasterAttributeValue to otccatalog.ItemMaster                                                          
   ,ISNULL(JSON_VALUE(oi.ItemData, '$.catalogName'), '') AS [CatalogName]                                                  
   ,oi.OrderItemId        
   FROM orders.orderItems oi WITH (NOLOCK)                                                  
   LEFT JOIN [otccatalog].[itemmaster] oim WITH (NOLOCK) --Modified Inner Join to Left Join                                                  
   ON oi.ItemCode = oim.ItemCode AND oi.IsActive=1                                                  
   LEFT JOIN cms.ItemmasterContent ic WITH (NOLOCK) ON oi.ItemCode = ic.ItemCode AND ic.IsActive=1 LEFT JOIN [catalog].[ItemMasterAttributeValues] ia WITH (NOLOCK) ON oi.ItemCode = ia.ItemCode  AND ia.IsActive=1                                            
  
   INNER JOIN  #transShippedItemTrackingOrders trto ON trto.orderId=oi.orderId AND trto.nationsId =JSON_VALUE(oi.itemData,'$.nationsId')       
   AND trto.itemTrackingNumber  =JSON_VALUE(oi.itemData,'$.trackingNumber')       
   WHERE oi.OrderId = @OrderId                      
   AND oi.ItemCode <> 'NB_VOUCHER_REFUND'                    
   FOR JSON PATH                                                  
   ) ItemDetails                                                  
   ,oo.OrderAmountData 'benefitTransactions'                                                  
   ,oo.MemberData                                                  
   ,oo.ShippingData                                                  
   ,tr.OrderTransactionData                                                  
   ,JSON_VALUE(tr.OrderTransactionData, '$.transactions[0].paymentType') as PaymentMode              
   ,UPPER(JSON_VALUE(tr.OrderTransactionData,'$.transactions[0].accountNumber')) AS accountNumber              
   ,JSON_VALUE(tr.OrderTransactionData,'$.totalAmount') AS youPaid              
   -- ,JSON_VALUE(oo.OrderAmountData,'$.price')AS totalPrice              
   ,oo.source                  
   ,ISNULL(@isSendEmail,0) AS isSendEmail              
   ,ISNULL(@isSendSMS,0) AS IsSendSMS              
   ,CASE WHEN oo.OrderStatusCode IN ('INI','ACK','EMI') THEN 'ACTIVE'  WHEN (SELECT COUNT(*) FROM Orders.OrderChangeRequests WHERE OrderId=oo.orderId and IsActive=1 and Status= 'Pending') >                          
   0 THEN 'ACTIVE' ELSE 'PAST' END AS 'OrderStatusCategory'                              
   ,cast(ISNULL(JSON_VALUE(oi.ItemData, '$.isMealKit'), 0) as bit) AS isMealKit               
   ,ISNULL((SELECT TOP 1 userProfileId FROM otc.UserProfiles WHERE nhMemberid =@nhMemberId AND isActive=1 AND subDomain = JSON_VALUE(oo.MemberData,'$.subdomain')),0) AS userProfileId                     
   ,(SELECT TOP 1 JSON_VALUE(ii.ConfigData,'$.phone') FROM  insurance.insuranceConfig  ii WITH (NOLOCK) WHERE  ii.InsuranceCarrierID = JSON_VALUE(oo.memberData,'$.clientCarrierId') AND ii.configType ='otccontent')as contactUsNumber             
   ,JSON_VALUE(oo.MemberData,'$.subdomain') as subDomain      
   FROM orders.orderItems oi WITH (NOLOCK)                                                  
   LEFT JOIN [otccatalog].[itemmaster] oim WITH (NOLOCK) ON oi.ItemCode = oim.ItemCode AND oim.IsActive=1 AND oi.IsActive=1                                                  
   INNER JOIN orders.orders oo WITH (NOLOCK) ON oi.OrderId = oo.OrderId  AND oo.IsActive=1                                                  
   LEFT JOIN Orders.OrderTransactionDetails tr WITH (NOLOCK) ON tr.OrderID = oo.OrderID AND tr.IsActive=1         
   AND tr.OrderStatusCode = 'PAY'                                                
   AND oo.OrderType = 'OTC'                                                  
   WHERE oi.OrderId = @OrderId  AND JSON_VALUE(oo.OrderAmountData,'$.warehouseCode') IS  NULL                    
   AND oi.ItemCode <> 'NB_VOUCHER_REFUND'                   
   END          
 END              
END 