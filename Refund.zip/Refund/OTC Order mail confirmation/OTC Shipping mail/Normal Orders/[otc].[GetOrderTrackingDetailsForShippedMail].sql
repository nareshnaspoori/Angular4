SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* =============================================                                    
  Author:Naresh Naspoori                                       
  Updated Date: 13-JULY-2021                                    
  Description: OTC get normal orders tracking details to send order shipping mail and mobile sms,    
               will be used as internal sproc.     
  =============================================                                    
  exec  [otc].[GetOrderTrackingDetailsForShippedMail]    200585236       
*/                     
                       
CREATE PROC [otc].[GetOrderTrackingDetailsForShippedMail] @OrderId BIGINT                                      
AS                                        
BEGIN            
  --DECLARE @OrderId BIGINT  =  200585236         
 SET NOCOUNT ON;     
    
 SELECT otd.orderId , c.orderTrackingNumber,itemTrack.*    
 FROM  Orders.OrderTransactionDetails  otd    
  CROSS APPLY OPENJSON(otd.OrderTransactionData, '$')     
  WITH(     
    orderTrackingNumber   VARCHAR(200)   '$.trackingNumber'     ,itemTracking NVARCHAR(MAX) 'strict $.itemTracking' AS JSON     
  )c    
    CROSS APPLY OPENJSON (c.itemTracking)      
  WITH(     
   nationsId   VARCHAR(200)   '$.itemNumber'     
   ,itemTrackingNumber varchar(100)  '$.trackingNumber'    
  ) itemTrack    
      
 INNER JOIN [Orders].[Orders] oo ON oo.OrderID=otd.orderId AND oo.OrderStatusCode=otd.OrderStatusCode AND JSON_VALUE(OrderAmountData,'$.warehouseCode') IS  NULL AND oo.isactive=1    
  WHERE otd.OrderStatusCode ='SHI' and ISJSON(otd.OrderTransactionData)>0  and otd.orderId=@OrderId AND otd.isActive =1  END          


  