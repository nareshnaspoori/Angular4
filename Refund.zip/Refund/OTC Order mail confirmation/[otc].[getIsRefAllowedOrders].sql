SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* =============================================                                
  Author:    NARESH NASPOORI                                   
  Updated Date: 21-JUNE-2021                                
  Description: OTC get  all orders isRefund allowed or not .                                
    
  [otc].[getIsRefAllowedOrders]  'NH202106672405'  
 ============================================================ */  
ALTER proc  [otc].[getIsRefAllowedOrders] @NHMemberId NVARCHAR(max)        
AS    
BEGIN     
  
  --DECLARE  @NHMemberId NVARCHAR(max) ='NH202106672293'   
 ;with cte as (          
 select DISTINCT oo.OrderID          
  ,SUM(oi.Quantity) AS TotalQuantity          
  ,ocri.ReqQuantity          
FROM Orders.Orders oo WITH (NOLOCK)            
INNER JOIN Orders.OrderItems oi  WITH (NOLOCK) ON oi.OrderId = oo.OrderID AND oi.IsActive = 1  AND oi.itemCode !='NB_VOUCHER_REFUND'            
LEFT JOIN          
   (SELECT ocri.OrderId           
     ,SUM(ocri.Quantity) AS ReqQuantity          
   FROM Orders.OrderChangeRequestItems ocri  WITH (NOLOCK)           
   INNER JOIN Orders.OrderChangeRequests ocr ON ocr.OrderChangeRequestID = ocri.OrderChangeRequestId   AND ocr.changeType= 'REFUND' and ocr.Status='APPROVED' AND ocri.Status='APPROVED' AND ocr.IsActive=1 AND ocri.IsActive=1     
   GROUP BY ocri.OrderID    
   )ocri ON ocri.OrderId = oo.OrderID          
   WHERE oo.NHMemberId = @NHMemberId      AND    
    oo.IsActive = 1              
  GROUP BY oo.OrderID          
  ,ocri.ReqQuantity )          
         SELECT  CAST(   --TotalQuantity, ReqQuantity ,    
(CASE WHEN TotalQuantity > ISNULL(ReqQuantity, 0)   THEN 1      
WHEN TotalQuantity = ISNULL(ReqQuantity,0) THEN 0    
ELSE 0 END) AS BIT )as isRefAllowed,orderId -- ,TotalQuantity,    ReqQuantity           
FROM CTE  
  
END 