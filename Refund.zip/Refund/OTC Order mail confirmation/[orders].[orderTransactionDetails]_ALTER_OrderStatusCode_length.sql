
-- need confirmation from DB devloper 
--OrderStatusCode length modify from 3 to 4 for OrderStatusCode COMM
ALTER TABLE [orders].[orderTransactionDetails]
--ALTER COLUMN OrderStatusCode NVARCHAR (3) NOT NULL;
ALTER COLUMN OrderStatusCode NVARCHAR (4) NOT NULL;

