/****** Object:  StoredProcedure [otc].[insertChangeRequestTranasactionDetails]    Script Date: 08-03-2021 19:22:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO
            
            
/* =============================================                
  Author: Naresh Naspoori                       
  Updated Date: 05-MARCH-2021                
  Description: OTC insert refunds change request order transacation details.                
  =============================================                
   exec [otc].[InsertChangeRequestTranasactionDetails] 200266154,'systemUser'               
*/            
            
              
/* =============================================                  
  Author: Naresh Naspoori                         
  Updated Date: 05-MARCH-2021                  
  Description: OTC insert refunds change request order transacation details.                  
  =============================================                  
   exec [otc].[InsertChangeRequestTranasactionDetails] 200266154,'systemUser'                 
*/              
CREATE PROC [otc].[InsertChangeRequestTranasactionDetails] @orderId BIGINT              
 ,@createUser NVARCHAR(100) = NULL              
AS              
BEGIN              
 BEGIN TRY              
  BEGIN TRAN              
              
  DECLARE @action NVARCHAR(MAX) = 'REFUND'              
  DECLARE @refundAmtType NVARCHAR(max) = 'Member Responsibility'              
  DECLARE @transData1 NVARCHAR(MAX)              
  DECLARE @transData2 NVARCHAR(MAX)              
  DECLARE @orderAmountDataBenefitTransactions NVARCHAR(MAX)            
  DECLARE @RequestData NVARCHAR(MAX) = (              
    SELECT TOP 1 RequestData              
    FROM [Orders].[OrderChangeRequests] WITH (NOLOCK)              
    WHERE OrderId = @orderId              
     AND ChangeType = 'Refund'              
    ORDER BY CreateDate DESC              
    )              
   SET  @orderAmountDataBenefitTransactions  =(SELECT OrderAmountData from   orders.orders Where OrderId IN(@orderId) and IsActive=1)            
             
  DROP TABLE                
  IF EXISTS #ordrTrnsTempTbl              
               
   DROP TABLE                
   IF EXISTS #RequestDataTrnsTempTbl              
               
   DROP TABLE              
   IF EXISTS #TempTrans              
        
     DECLARE @orderChangeRequestId BIGINT= (SELECT TOP 1 OrderChangeRequestID              
    FROM [Orders].[OrderChangeRequests] WITH (NOLOCK)              
    WHERE OrderId = @orderId              
     AND ChangeType = 'Refund' and IsActive=1             
    ORDER BY CreateDate DESC              
    )         
               
   SELECT *              
    ,@orderId AS orderId          
 ,@orderChangeRequestId AS 'OrderChangeRequestID'        
   INTO #RequestDataTrnsTempTbl              
   FROM (              
    SELECT JSON_Value(c.value, '$.purseName') AS purseName              
     ,JSON_Value(c.value, '$.amountReturnToPocket') AS outOfPocket              
     ,CAST(ISNULL(JSON_Value(c.value, '$.amountToReturn'),0) AS  decimal(8,2)) AS refundAmount              
     ,JSON_Value(c.value, '$.paymentType') AS paymentType              
  , CAST(ISNULL(JSON_Value(c.value, '$.benefitsToReturn'),0) AS  decimal(8,2)) AS benefitsToReturn      
     ,CASE               
      WHEN (              
        SELECT CAST( ISNULL(JSON_Value(c.value, '$.benefitsToReturn'),0) AS  decimal(8,2)              
        )) > 0     AND    ( SELECT JSON_Value (t.value, '$.source') as source FROM OPENJSON (@orderAmountDataBenefitTransactions, '$.benefitTransactions') as t             
       WHERE JSON_Value (t.value, '$.catalogName') = JSON_Value(c.value, '$.purseName') AND            
       (SELECT ISNULL(JSON_Value(c.value, '$.paymentType'), 0)) = '0'            
     ) = 'NATIONS'           
       THEN 'Nations Benefits'          
     WHEN (              
        SELECT CAST( ISNULL(JSON_Value(c.value, '$.benefitsToReturn'), 0) AS  decimal(8,2)            
        )) > 0    AND    ( SELECT JSON_Value (t.value, '$.source') as source FROM OPENJSON (@orderAmountDataBenefitTransactions, '$.benefitTransactions') as t             
       WHERE JSON_Value (t.value, '$.catalogName') = JSON_Value(c.value, '$.purseName') AND            
       (SELECT ISNULL(JSON_Value(c.value, '$.paymentType'), 0)) = '0'            
     ) = 'INCOMM'           
    THEN 'Incomm Benefits'        
    WHEN  (SELECT  cast(ISNULL(JSON_Value(c.value, '$.amountReturnToPocket'), 0)  as  decimal(8,2))             
        ) > 0      
        
  THEN 'Member Responsibility'      
      ELSE ''              
      END AS refundAmtType               
        ,CASE               
     WHEN (              
       SELECT JSON_Value (t.value, '$.source') as source            
       FROM OPENJSON (@orderAmountDataBenefitTransactions, '$.benefitTransactions') as t             
       WHERE JSON_Value (t.value, '$.catalogName') = JSON_Value(c.value, '$.purseName') AND            
       (SELECT ISNULL(JSON_Value(c.value, '$.paymentType'), 0)) = '0'            
     ) = 'NATIONS'                
         THEN 'Complete'                
        ELSE 'InProgress'               
      END AS transStatus            
    FROM OPENJSON(@RequestData, '$.paymentDetails') AS c              
    ) t              
              
  --SELECT *FROM  #RequestDataTrnsTempTbl              
  SELECT DISTINCT @transData1 = (              
    SELECT DISTINCT              
     --, refTransactions.orderChangeRequestItemId               
     (              
      SELECT JSON_VALUE(OrderTransactionData, '$.transactions[0].transactionId')              
      FROM [Orders].[OrderTransactionDetails] WITH (NOLOCK)              
      WHERE orderId = @orderId AND IsActive=1           
       AND OrderStatusCode = 'PAY'              
      ) AS paymentTransactionId              
     ,tempTrans.paymentType              
     ,(              
      SELECT GETDATE()              
      ) AS refundDate              
     --, tempTrans.outOfPocket              
     ,tempTrans.refundAmount              
     ,tempTrans.purseName              
     ,tempTrans.benefitsToReturn              
     ,@action AS action              
     ,tempTrans.refundAmtType           
     ,transStatus AS status         
  ,tempTrans.OrderChangeRequestID     as orderChangeRequestId    
     ,CASE               
      WHEN (ISNULL(tempTrans.paymentType, 0)) = '0'              
       THEN ''              
   ELSE otcc.CardNumber              
      END AS cardNumber              
    FROM #RequestDataTrnsTempTbl tempTrans              
    LEFT JOIN [Orders].[OrderTransactionDetails] otd WITH (NOLOCK) ON otd.OrderId = tempTrans.OrderId              
     AND otd.OrderStatusCode = 'PAY'              
    INNER JOIN [Orders].[OrderChangeRequests] OCR WITH (NOLOCK) ON tempTrans.orderId = OCR.OrderId              
    LEFT JOIN [otc].[cards] otcc WITH (NOLOCK) ON OCR.NHMemberId = otcc.NHMemberId              
    WHERE --otd.OrderStatusCode =  case when LEN(tempTrans.paymentType)>0 then 'PAY' end AND              
     OCR.changeType = 'REFUND'              
     AND ocr.OrderId IN (@orderId)              
    FOR JSON AUTO              
    )              
              
  -- PRINT @transData1              
  CREATE TABLE #TempTrans (transData NVARCHAR(max));              
              
  INSERT INTO #TempTrans (transData)              
  VALUES (@transData1)              
              
  SELECT *              
  FROM #TempTrans              
              
  INSERT INTO [Orders].[OrderTransactionDetails] (              
    OrderID              
   ,OrderStatusCode              
   ,OrderTransactionData              
   ,CreateDate              
   ,ModifyDate              
   ,CreateUser              
   ,ModifyUser              
   ,IsActive              
   ,IsComplete              
   )              
  VALUES (              
   @orderId              
   ,'REF'              
   ,(              
    SELECT transData              
    FROM #TempTrans              
    )              
   ,GETDATE()              
   ,GETDATE()              
   ,@createUser              
   ,@createUser              
   ,1              
   ,0              
   )              
        
  COMMIT              
 END TRY              
              
 BEGIN CATCH              
  DECLARE @ErrorMessage NVARCHAR(4000);              
  DECLARE @Severity INT;              
  DECLARE @ErrorState INT;              
              
  SELECT @ErrorMessage = ERROR_MESSAGE()              
   ,@Severity = ERROR_SEVERITY()              
   ,@ErrorState = ERROR_STATE()              
              
  RAISERROR (              
    @ErrorMessage              
    ,@Severity              
    ,@ErrorState              
    )              
              
  PRINT (@ErrorMessage)              
  PRINT (@Severity)              
  PRINT (@ErrorState)              
              
  ROLLBACK              
 END CATCH              
END