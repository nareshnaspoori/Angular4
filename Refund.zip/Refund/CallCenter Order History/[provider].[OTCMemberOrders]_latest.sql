SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* =============================================          
          
  Description: OTC get all member orders details.       
        
  Update History:      
	 Updated Date: 27-APRIL-2021  
	 Author: Naresh Naspoori        
	 AdminComments,OrderItemsCount, ChangeRequestStatus, TrackingDetails  added. 
  =============================================          
 
 EXEC [provider].[OTCMemberOrders] 'NH202106672275'   
*/   

ALTER PROC [provider].[OTCMemberOrders] @NHMemberId VARCHAR(20)  
AS  
BEGIN  
 DECLARE @otcCarrierId BIGINT = (  
   SELECT TOP 1 InsuranceCarrierID  
   FROM Insurance.InsuranceCarriers  
   WHERE IsActive = 1  
    AND JSON_VALUE(CarrierConfig, '$.subdomain') = 'otcnetwork'  
   )  
 DECLARE @otcPlanId BIGINT = (  
   SELECT TOP 1 InsuranceHealthPlanID  
   FROM Insurance.InsuranceHealthPlans  
   WHERE IsActive = 1  
    AND InsuranceCarrierID = @otcCarrierId  
    AND PlanConfigData IS NULL  
   )  
  
 SELECT DISTINCT o.OrderID
   ,IIF(o.RefOrderId IS NOT NULL, 'Reshipment','Regular Order')AS OrderType -- order type  reshipment and regular order by refOrderId
  ,[DateOrderReceived]  
  ,o.[CreateDate]  
  ,o.[ModifyDate]
  ,[DateOrderInitiated]  
  ,(  
   CASE [OrderStatusCode]  
    WHEN 'INI'  
     THEN 'Submitted'  
    WHEN 'ACK'  
     THEN 'Confirmed'  
    WHEN 'CAN'  
     THEN 'Cancelled'  
    WHEN 'SHI'  
     THEN 'Shipped'  
    WHEN 'REF'      
     THEN 'Refunded'   
    END  
   ) AS OrderStatusCode  
  ,CONVERT(DECIMAL(10, 2), o.[Amount]) AS TotalAmount  
  ,CAST(ISNULL(JSON_VALUE([OrderAmountData], '$.amountCovered'),0) AS DECIMAL(10, 2)) AS BenefitApplied  
  ,CAST(ISNULL(o.[Amount],0) AS DECIMAL(10, 2)) - CAST(ISNULL(JSON_VALUE([OrderAmountData], '$.amountCovered'),0)AS DECIMAL(10, 2)) AS MemberResponsibilty  
  ,[OrderAmountData]  
  ,[ShippingData]  
  ,o.[NHMemberId]  
  ,[MemberData]  
  ,CONVERT(BIGINT, [MemberChartDataId]) AS MemberChartDataId  
  ,o.[Status]  
  ,me1.[EmailAddress] AS MemberEmailId  
  ,(  
   SELECT insuranceCarrierName  
   FROM insurance.InsuranceCarriers  
   WHERE InsuranceCarrierId = JSON_VALUE(o.MemberData, '$.insCarrierId')  
   ) AS BenefitType  
  ,(  
   SELECT TOP 1 JSON_VALUE(CarrierConfig, '$.subdomain')  
   FROM Insurance.InsuranceCarriers  
   WHERE InsuranceCarrierID = JSON_VALUE(o.MemberData, '$.insCarrierId')  
   ) AS SubDomain  
  ,InsD.InsuranceNbr  
  ,InsD.OTCCardNumber  
 ,ISNULL(Ins.InsuranceCarrierID, 0)AS InsuranceCarrierID  
 ,ISNULL(Ins.InsuranceHealthPlanID, 0)AS InsuranceHealthPlanID  
  ,Source  
  , CAST(SUM(oi.Quantity) OVER (PARTITION BY o.orderid)AS VARCHAR(20)) AS OrderItemsCount
  ,(SELECT TOP 1 JSON_VALUE(AdminComments,'$.Comment')AS AdminComments FROM orders.orderChangeRequests WITH (NOLOCK) WHERE orderid =o.orderId ORDER BY orderChangeRequestId  DESC) AS AdminComments ---Change request ADMIN COMMENTS.
  ,(SELECT TOP 1  CONCAT(UPPER(LEFT(changeType,1))+LOWER(SUBSTRING(changeType,2,LEN(changeType))),' ',UPPER(LEFT(status,1))+LOWER(SUBSTRING(status,2,LEN(status)))) AS ChangeRequestStatus  FROM orders.orderChangeRequests WITH (NOLOCK) WHERE orderid =o.orderId ORDER BY orderChangeRequestId  DESC) AS ChangeRequestStatus -- status for change request latest .
  ,(SELECT TOP 1  ModifyDate  FROM orders.orderChangeRequests WITH (NOLOCK) WHERE orderid =o.orderId  ORDER BY orderChangeRequestId  DESC) AS ChangeRequestDate -- for changeRequests modifyDate
  ,(SELECT TOP 1  ISNULL(( SELECT TOP 1 IIF (trackingNumber IS NOT NULL , CONCAT (trackingNumber ,',',trackingUrl),NULL)AS trackingDetails FROM OPENJSON((SELECT TOP 1 OrderTransactionData FROM  orders.OrderTransactionDetails  otd
     WITH (NOLOCK) WHERE orderid=o.orderId ORDER BY otd.CREATEDATE DESC))
		WITH
		(
		 trackingUrl NVARCHAR(200) '$.trackingUrl',
		trackingNumber NVARCHAR(200) '$.trackingNumber'
		)),'')
   ) TrackingDetails   -- comma seperated details for trackingnumber, trackingUrl
 FROM orders.orders o   WITH (NOLOCK)  
  INNER JOIN  orders.OrderItems oi WITH (NOLOCK)   ON oi.OrderId=o.OrderID
 LEFT JOIN [provider].[MemberProfiles] mp WITH (NOLOCK)   ON mp.[NHMemberId] = o.[NHMemberId]  
  AND mp.[IsActive] = 1  
 LEFT JOIN provider.memberemails me1 WITH (NOLOCK)   ON me1.[MemberProfileId] = mp.[MemberProfileId]  
 LEFT JOIN provider.memberemails me2 WITH (NOLOCK)   ON me2.[MemberProfileId] = mp.[MemberProfileId]  
  AND me1.MemberEmailId < me2.MemberEmailId  
 INNER JOIN Master.Members M WITH (NOLOCK)   ON M.NHMemberID = Mp.NHMemberId  
 LEFT JOIN master.MemberInsurances Ins WITH (NOLOCK)  ON M.MemberID = ins.MemberID  
  AND Ins.InsuranceCarrierID = CAST(ISNULL(JSON_VALUE(o.MemberData, '$.insCarrierId'), @otcCarrierId) AS BIGINT)  
  AND Ins.InsuranceHealthPlanID = CAST(ISNULL(JSON_VALUE(o.MemberData, '$.insPlanId'), @otcPlanId) AS BIGINT)  
  AND (  
   CAST(o.CreateDate AS DATE) BETWEEN CAST(Ins.InsuranceEffectiveDate AS DATE)  
    AND CAST(Ins.InsuranceEndDate AS DATE)  
   )  
  AND Ins.IsActive = 1  
 LEFT JOIN master.memberinsuranceDetails InsD WITH (NOLOCK) ON InsD.MemberInsuranceId = Ins.Id  
  AND InsD.IsActive = 1  
 WHERE o.[NHMemberId] = @NHMemberId  
  AND [OrderType] = 'OTC'  
  AND me2.IsActive IS NULL  
  AND o.[IsActive] = 1  
 ORDER BY orderid DESC  
END  