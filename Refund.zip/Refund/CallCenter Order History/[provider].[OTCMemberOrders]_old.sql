  
--EXEC [provider].[OTCMemberOrders] 'NH202002474804'    
CREATE PROC [provider].[OTCMemberOrders] @NHMemberId VARCHAR(20)  
AS  
BEGIN  
 DECLARE @otcCarrierId BIGINT = (  
   SELECT TOP 1 InsuranceCarrierID  
   FROM Insurance.InsuranceCarriers  
   WHERE IsActive = 1  
    AND JSON_VALUE(CarrierConfig, '$.subdomain') = 'otcnetwork'  
   )  
 DECLARE @otcPlanId BIGINT = (  
   SELECT TOP 1 InsuranceHealthPlanID  
   FROM Insurance.InsuranceHealthPlans  
   WHERE IsActive = 1  
    AND InsuranceCarrierID = @otcCarrierId  
    AND PlanConfigData IS NULL  
   )  
  
 SELECT DISTINCT [OrderID]  
  ,[OrderType]  
  ,[DateOrderReceived]  
  ,o.[CreateDate]  
  ,[DateOrderInitiated]  
  ,(  
   CASE [OrderStatusCode]  
    WHEN 'INI'  
     THEN 'Submitted'  
    WHEN 'ACK'  
     THEN 'Confirmed'  
    WHEN 'CAN'  
     THEN 'Cancelled'  
    WHEN 'SHI'  
     THEN 'Shipped'  
    WHEN 'REF'      
     THEN 'Refunded'   
    END  
   ) AS OrderStatusCode  
  ,convert(DECIMAL(10, 2), [Amount]) AS TotalAmount  
  ,convert(DECIMAL(10, 2), Json_value([OrderAmountData], '$.amountCovered')) AS BenefitApplied  
  ,convert(DECIMAL(10, 2), ([Amount] - convert(DECIMAL(10, 2), Json_value([OrderAmountData], '$.amountCovered')))) AS MemberResponsibilty  
  ,[OrderAmountData]  
  ,[ShippingData]  
  ,o.[NHMemberId]  
  ,[MemberData]  
  ,convert(BIGINT, [MemberChartDataId]) AS MemberChartDataId  
  ,[Status]  
  ,me1.[EmailAddress] AS MemberEmailId  
  ,(  
   SELECT insuranceCarrierName  
   FROM insurance.InsuranceCarriers  
   WHERE InsuranceCarrierId = json_value(o.MemberData, '$.insCarrierId')  
   ) AS BenefitType  
  ,(  
   SELECT TOP 1 JSON_VALUE(CarrierConfig, '$.subdomain')  
   FROM Insurance.InsuranceCarriers  
   WHERE InsuranceCarrierID = json_value(o.MemberData, '$.insCarrierId')  
   ) AS SubDomain  
  ,InsD.InsuranceNbr  
  ,InsD.OTCCardNumber  
  ,isnull(Ins.InsuranceCarrierID, 0) InsuranceCarrierID  
  ,isnull(Ins.InsuranceHealthPlanID, 0) InsuranceHealthPlanID  
  ,Source  
 FROM orders.orders o  
 LEFT JOIN [provider].[MemberProfiles] mp ON mp.[NHMemberId] = o.[NHMemberId]  
  AND mp.[IsActive] = 1  
 LEFT JOIN provider.memberemails me1 ON me1.[MemberProfileId] = mp.[MemberProfileId]  
 LEFT JOIN provider.memberemails me2 ON me2.[MemberProfileId] = mp.[MemberProfileId]  
  AND me1.MemberEmailId < me2.MemberEmailId  
 INNER JOIN Master.Members M ON M.NHMemberID = Mp.NHMemberId  
 LEFT JOIN master.MemberInsurances Ins ON M.MemberID = ins.MemberID  
  AND Ins.InsuranceCarrierID = cast(Isnull(json_value(o.MemberData, '$.insCarrierId'), @otcCarrierId) AS BIGINT)  
  AND Ins.InsuranceHealthPlanID = cast(Isnull(Json_Value(o.MemberData, '$.insPlanId'), @otcPlanId) AS BIGINT)  
  AND (  
   Cast(o.CreateDate AS DATE) BETWEEN Cast(Ins.InsuranceEffectiveDate AS DATE)  
    AND Cast(Ins.InsuranceEndDate AS DATE)  
   )  
  AND Ins.IsActive = 1  
 LEFT JOIN master.memberinsuranceDetails InsD ON InsD.MemberInsuranceId = Ins.Id  
  AND InsD.IsActive = 1  
 WHERE o.[NHMemberId] = @NHMemberId  
  AND [OrderType] = 'OTC'  
  AND me2.IsActive IS NULL  
  AND o.[IsActive] = 1  
 ORDER BY orderid DESC  
END  