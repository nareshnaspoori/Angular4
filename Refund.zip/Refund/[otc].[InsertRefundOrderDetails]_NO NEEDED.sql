SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author: Naresh Naspoori       
-- Create Date: 01-MARCH-2021
-- Description: OTC Refund insert refund order details.
-- =============================================
-- exec  [otc].[InsertRefundOrderDetails]
-- DECLARE @OrderId bigint	=190009011
-- DECLARE @RequestData varchar(4000) ='{"Reason":"Other","AdditionalComments":"abc"}'
-- DECLARE @NHMemberId nvarchar(100)='OTC201901964101'
-- DECLARE @SubmitUserProfileId bigint=11924
-- DECLARE @CreateUser nvarchar(100) ='GailFran'
-- DECLARE @OrderChangeRequestItems NVARCHAR(max)  = N'[{"OrderId" : 190009011,  "OrderItemId": "78964", "ItemCode": 97958116426, "Quantity": 1,   "ItemData": "25" ,"Comments":"test"  } ]'
-- drop PROCEDURE [otc].[InsertRefundOrderDetails] 

CREATE PROCEDURE [otc].[InsertRefundOrderDetails] (
	@OrderId BIGINT
	,@RequestData VARCHAR(4000)
	,@NHMemberId NVARCHAR(100) = NULL
	,@SubmitUserProfileId BIGINT
	,@CreateUser NVARCHAR(100)
	,@OrderChangeRequestItems NVARCHAR(MAX)
	)
AS
BEGIN TRY
	DECLARE @SCOPE_IDENTITY BIGINT
	DECLARE @STATUS VARCHAR(200) = 'PENDING'
	DECLARE @errorMsg VARCHAR(200)
	DECLARE @errorSeverity VARCHAR(200)
	DECLARE @orderPreviousStatus VARCHAR(20) = (
			SELECT orderStatusCode
			FROM orders.orders
			WHERE orderId = @OrderId
			)

	BEGIN TRANSACTION

	INSERT INTO [Orders].[OrderChangeRequests] (
		[OrderId]
		,[ChangeType]
		,[Status]
		,[OrderType]
		,[PreviousStatus]
		,[RequestData]
		,[NHMemberId]
		,[SubmitUserProfileId]
		,[IsActive]
		,[CreateDate]
		,[SubmitDate]
		,[CreateUser]
		)
	VALUES (
		@OrderId
		,'REFUND'
		,'PENDING'
		,'OTC'
		,@orderPreviousStatus
		,@RequestData
		,@NHMemberId
		,@SubmitUserProfileId
		,1
		,getdate()
		,getdate()
		,@CreateUser
		)

	SET @SCOPE_IDENTITY = SCOPE_IDENTITY()

	INSERT INTO [Orders].[OrderChangeRequestItems] (
		OrderChangeRequestId
		,OrderId
		,OrderItemId
		,ItemCode
		,Quantity
		,ItemData
		,Comments
		,STATUS
		,PreviousStatus
		,CreateDate
		,CreateUser
		,IsActive
		,ModifyDate
		,ModifyUser
		)
	SELECT @SCOPE_IDENTITY OrderChangeRequestId
		,@OrderId
		,*
		,@STATUS STATUS
		,(
			SELECT TOP 1 STATUS
			FROM orders.orderitems
			WHERE orderItemid = t.OrderItemId
			) PreviousStatus
		,getdate() CreateDate
		,@CreateUser CreateUser
		,1 IsActive
		,getdate() ModifyDate
		,@CreateUser ModifyUser
	FROM (
		SELECT *
		FROM OPENJSON(@OrderChangeRequestItems) WITH (
				--OrderId bigint '$.OrderId' 
				OrderItemId BIGINT '$.OrderItemId'
				,ItemCode NVARCHAR(200) '$.ItemCode'
				,Quantity BIT '$.Quantity'
				,ItemData VARCHAR(4000) '$.ItemData'
				,Comments VARCHAR(4000) '$.Comments'
				)
		) t

	UPDATE orders.orders
	SET OrderStatusCode = 'RFP'
		,ModifyDate = getdate()
		,ModifyUser = @CreateUser
	WHERE OrderId = @OrderId

	UPDATE orders.orderitems
	SET STATUS = 'REFUND_PENDING'
		,ItemData = Json_modify(ItemData, '$.Remarks', 'Refund Applied')
		,ModifyDate = getdate()
		,ModifyUser = @CreateUser
	WHERE OrderId = @OrderId
		AND orderitemId IN (
			SELECT orderItemId
			FROM OPENJSON(@OrderChangeRequestItems) WITH (
					OrderItemId BIGINT '$.OrderItemId'
					,ItemCode NVARCHAR(200) '$.ItemCode'
					,Quantity BIT '$.Quantity'
					,ItemData VARCHAR(4000) '$.ItemData'
					)
			)

	COMMIT;
END TRY

BEGIN CATCH
	DECLARE @ErrorMessage NVARCHAR(4000);
	DECLARE @Severity INT;
	DECLARE @ErrorState INT;

	SELECT @ErrorMessage = ERROR_MESSAGE()
		,@Severity = ERROR_SEVERITY()
		,@ErrorState = ERROR_STATE()

	RAISERROR (
			@ErrorMessage
			,@Severity
			,@ErrorState
			)

	PRINT (@ErrorMessage)
	PRINT (@Severity)
	PRINT (@ErrorState)

	ROLLBACK
END CATCH
GO

