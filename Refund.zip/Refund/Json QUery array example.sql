declare @tmp table ([id] int, BankDataText nvarchar(max))
declare @j nvarchar(max)='{
    "data": [{
        "account": {
            "account": [{
                "schemaName": "SortCodeAccountNumber",
                "identification": "99999829250103",
                "name": "Load testing ....",
                "secondaryIdentification": "123456789"
            }],
            "accountType": "null",
            "accountSubType": "null",
            "description": null,
            "accountId": "LOADACC001",
            "currency": "GBP",
            "nickname": "LoadTest",
            "servicer": {
                "schemaName": "BICFI",
                "identification": "PAPAUK00XXX"
            }
        }
    }]
}'
insert into @tmp select 675, @j

select top 1
    A.accountId as NonUserAccountId,        B.identification
from @tmp t
    cross apply openjson (t.BankDataText, N'$.data') with
    ( 
        accountId varchar(100)  'strict $.account.accountId',
        account   nvarchar(max) 'strict $.account.account' as json 
    ) A
    cross apply openjson(A.account) with 
    ( 
        identification varchar(100)
    ) B


	--==========================================================================


	DECLARE @json NVARCHAR(1000)   
    SELECT @json =    
    N'[   
        {   
          "orderDate": "07-12-2021",
         "carrier": "General Shipping",
         "itemTracking": [
			{
				"itemNumber": "6040",
				"trackingNumber": "784060507188",
				"weight": "1",
				"units": "Pound"
			}
		]  
        }  
		,
		{   
          "orderDate": "07-12-2021",
         "carrier": "General Shipping",
         "itemTracking": [
			{
				"itemNumber": "6040",
				"trackingNumber": "784060507188",
				"weight": "1",
				"units": "Pound"
			}
		]  
        }  
    ]'   
        
    SELECT   
        JSON_Value (c.value, '$.orderDate') as orderDate,    
        JSON_Value (c.value, '$.carrier') as carrier,    
        JSON_Value (p.value, '$.itemNumber') as itemNumber,    
        JSON_Value (p.value, '$.trackingNumber') as trackingNumber   
         
    FROM OPENJSON (@json, '$') as c   
    CROSS APPLY OPENJSON (c.value, '$.itemTracking') as p  

	-- array query for get as rows.
	--===============================
	DECLARE @data NVARCHAR(4000)
                SET @data=N'{  
                   
                       "Employees":["Raj","Mohan","Shyam"]
                      }'

				 select value from openJson(@data,'$.Employees')as t
