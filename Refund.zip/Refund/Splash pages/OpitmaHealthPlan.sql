BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
--------------------------------------STEP:1- Create Carrier and configure required configurations-------------------------------------------------------------------------------------------------

DECLARE @carrierName NVARCHAR(100)='OptimaHealth'
DECLARE @carrierId BIGINT
DECLARE @memberNBPortalconfig NVARCHAR(MAX) ='{"splashConfig":{"splashTemplate":"SplashBenefitsLP","splashTitle" :"Thank you for visiting.","splashContent" :"Your benefit period begins on <strong>January 1, 2022.<\/strong><br /> Please contact your health plan if you have any questions."}}'
DECLARE @memberNBPortalconfigUpdate NVARCHAR(MAX) ='{"splashTemplate":"SplashBenefitsLP","splashTitle" :"Thank you for visiting.","splashContent" :"Your benefit period begins on <strong>January 1, 2022.<\/strong><br /> Please contact your health plan if you have any questions."}'

DECLARE @otcConfig NVARCHAR(MAX) ='{"splashTemplate":"SplashLP","splashConfig":"{"splashTemplate":"SplashLP","splashTitle" :"<h1>Thank you for visiting NationsOTC.</h1>","splashContent" :"<p>Access to your online portal will be available when your benefit period begins on <strong>January 1, 2022.</strong></p><p class=''mt-3''>Please contact your health plan if you have any questions.</p><div class=''dropdown catalog'' id=''dropdownCatalog_CustomLP''></div>"}"}'
DECLARE @otcConfigUpdate NVARCHAR(MAX) ='{"splashTemplate":"SplashLP","splashTitle" :"<h1>Thank you for visiting NationsOTC.</h1>","splashContent" :"<p>Access to your online portal will be available when your benefit period begins on <strong>January 1, 2022.</strong></p><p class=''mt-3''>Please contact your health plan if you have any questions.</p><div class=''dropdown catalog'' id=''dropdownCatalog_CustomLP''></div>"}"}'--SELECT INSERTED CARRIERID

DECLARE @MEMBERPORTALLOGIN VARCHAR(50)='MEMBERPORTALLOGIN'
DECLARE @OTCLOGIN VARCHAR(50) ='OTCLOGIN'

SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));

IF(ISNULL(@carrierId,0)>0)
BEGIN
--Update Config {"subdomain":"molina","carrierCode":"molina"}
UPDATE Insurance.InsuranceCarriers
SET CarrierConfig = IIF(ISNULL(CarrierConfig,'') ='','{"subdomain":"optimahealth","carrierCode":"optima"}', JSON_MODIFY(JSON_MODIFY(CarrierConfig,'$.subdomain','optimahealth'),'$.carrierCode','optima')),ModifyDate=GETDATE(),ModifyUser='mnanduri'
WHERE InsuranceCarrierID=@carrierId
END
ELSE
BEGIN

--INSERTING CARRIER
INSERT INTO insurance.insurancecarriers (CreateDate,CreateUser,InsuranceCarrierName,IsActive,IsContracted,IsDiscountProgram,MemberDataFileProvided,ModifyDate,ModifyUser,IsAutoSendPaymentReceipt,CarrierConfig,IsNHDiscount,AllowAdditionalServices)
VALUES (getdate(),'script',@carrierName,1,1,0,0,getdate(),'script',0,'{"subdomain":"optimahealth","carrierCode":"optima"}',0,0)

--SELECT INSERTED CARRIERID
SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));
END

 ---INSERTING CONFIGURATIONS('MEMBERPORTALLOGIN') 

IF NOT EXISTS(select * from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid and ConfigType=@MEMBERPORTALLOGIN and ISNULL(InsuranceHealthPlanId, 0)=0)
	BEGIN
		INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive,InsuranceHealthPlanId)
		VALUES
		(@MEMBERPORTALLOGIN,@memberNBPortalconfig,@carrierid,GETDATE(),'mnanduri',GETDATE(),'mnanduri',1,null)
	END

ELSE
	BEGIN
		UPDATE Insurance.insuranceconfig
		SET ConfigData=IIF(ISNULL(ConfigData,'')='', @memberNBPortalconfig, JSON_MODIFY(ConfigData,'$.splashConfig',JSON_QUERY(@memberNBPortalconfigUpdate))), 
		ModifyDate=GETDATE(), ModifyUser='mnanduri'
		WHERE InsuranceCarrierID=@carrierid and ConfigType=@MEMBERPORTALLOGIN and InsuranceHealthPlanId is null
	END


---INSERTING CONFIGURATIONS('OTCLOGIN') 
IF NOT EXISTS(select * from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid and ConfigType=@OTCLOGIN and ISNULL(InsuranceHealthPlanId, 0)=0)
	BEGIN
		INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive,InsuranceHealthPlanId)
		VALUES
		(@OTCLOGIN,@otcConfig,@carrierid,GETDATE(),'mnanduri',GETDATE(),'mnanduri',1,null)
	END

ELSE
	BEGIN
		UPDATE Insurance.insuranceconfig
		SET ConfigData=IIF(ISNULL(ConfigData,'')='', @otcConfig, JSON_MODIFY(ConfigData,'$.splashConfig',JSON_QUERY(@otcConfigUpdate))), 
		ModifyDate=GETDATE(), ModifyUser='mnanduri'
		WHERE InsuranceCarrierID=@carrierid and ConfigType=@OTCLOGIN and InsuranceHealthPlanId is null
	END

IF(@carrierId>0)
PRINT 'succefully executed.'

COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH

