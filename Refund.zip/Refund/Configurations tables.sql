-- carriers 
SELECT TOP 10 * FROM Insurance.InsuranceCarriers   ORDER BY 1 DESC

-- health planss
SELECT TOP 10 * FROM insurance.insurancehealthplans ORDER BY 1 DESC

-- congigurations
SELECT TOP 10 *FROM insurance.insuranceconfig ORDER BY 1 DESC

SELECT TOP 10 * FROM  Insurance.LoginTemplateConfig   WHERE LoginTemplate ='OTCNationsStandard'  
   AND IsActive = 1     ORDER BY 1 DESC

SELECT TOP 10 * FROM MASTER.MemberInsuranceDetails    ORDER BY 1 DESC
SELECT TOP 10 * FROM [Master].[MemberInsurances] ORDER BY 1 DESC

 
-- Configuration catalogs for carriers
--------------------------------------

--wallets

SELECT TOP 10 * FROM  otccatalog.wallets ORDER BY 1 DESC


-- wallet items

SELECT TOP 10 * FROM otccatalog.walletItems  ORDER BY 1 DESC

SELECT TOP 10 * FROM otccatalog.walletItems WHERE  walletid in (select top 10  walletid from otccatalog.wallets order by 1 desc )  ORDER BY 1 DESC

--- wallet plans

SELECT TOP 10 * FROM otccatalog.walletplans ORDER BY 1 DESC

SELECT TOP 10 * FROM otccatalog.walletplans WHERE walletId in (select top 10 walletid from otccatalog.wallets order by 1 desc ) order by 1 desc 

------ BENEFITS.
SELECT TOP 10 * FROM insurance.healthplancontracts ORDER BY 1 DESC

-- RULES ENGINE  benefit ruleIDs

SELECT TOP 10 *FROM rulesengine.benefitrulesdata ORDER BY 1 DESC

-- insert contract rules
--===================
SELECT TOP 10 *FROM INSURANCE.CONTRACTRULES  ORDER BY 1 DESC

SELECT TOP 10 *FROM INSURANCE.CONTRACTRULES ic
INNER JOIN  rulesengine.benefitrulesdata  rb ON rb.BenefitRuleDataId =ic.BenefitRuleDataId
INNER JOIN  insurance.healthplancontracts ih ON ih.healthplanContractId =ic.healthplanContractId

ORDER BY 1 DESC 
 


