  
  /*     
 =============================================    
-- 08-FEB-2021 Harika  - Added BenPayData column and OrderTransactionDetails Table   
    
=======================================================================================  
  
-- 25-MAR-2021 Harika -  Changed the derivation of MemberResponsibility.  
  
=======================================================================================  
Modified Date : 27-JULY-2021 
Modified By : JOEL -  Added benefitValueSource.   
=======================================================================================  
*/  
  
--exec [otc].[GetMemberOrderPayDetails] 200585864    
  
CREATE OR ALTER PROC [otc].[GetMemberOrderPayDetails]    
@OrderId BIGINT 
AS
 BEGIN    

SET NOCOUNT ON;    
    
SELECT     
 oo.OrderID AS [OrderID]    
 , CAST(JSON_VALUE(oo.OrderAmountData, '$.price') AS decimal) AS [TotalPrice]    
 , CAST(JSON_VALUE(oo.OrderAmountData, '$.amountCovered')AS decimal) AS [AmountCovered]    
 , JSON_QUERY(oo.OrderAmountData, '$.benefitTransactions') AS [BenefitTransactions]    
    --, CAST(JSON_VALUE(oo.OrderAmountData, '$.price') - CAST(JSON_VALUE(oo.OrderAmountData, '$.amountCovered')) AS 'MemberResponsibility' -- (25-MAR-2021)  
 , CAST(JSON_VALUE(oo.OrderAmountData, '$.outOfPocket') AS decimal) AS [MemberResponsibility]  -- Modified MemberResponsibility derivation -- (25-MAR-2021)  
 , ISNULL(ot.OrderTransactionData, '') AS [PayTransactionData]    
 , ISNULL(ot1.OrderTransactionData, '') AS [BenPayData] -- Added by Harika (for WEX and VISA Cancellation)  
 , ISNULL(oc.CardNumber,'') AS [CardNumber]
 ,ISNULL((SELECT TOP 1 JSON_VALUE(ConfigData,'$.benefitValueSource')
        FROM Insurance.InsuranceConfig
        WHERE InsuranceCarrierID = JSON_VALUE(oo.MemberData, '$.clientCarrierId')
        AND ISNULL(InsuranceHealthPlanId,0) IN (ISNULL(JSON_VALUE(oo.MemberData, '$.clientPlanId'),0),0)
        AND ConfigType = 'OTCLOGIN'
        ORDER BY InsuranceHealthPlanId desc),'') AS BenefitValueSource
 , CASE     
  WHEN oo.OrderStatusCode IN ('INI')    
  THEN CAST(1 AS BIT)    
  ELSE CAST(0 AS BIT) END    
 AS [IsEditable]    
 , (SELECT DISTINCT oi.ItemCode AS [ItemCode], oi.Quantity AS [ItemQuantity], CAST(oi.Amount AS DECIMAL) AS [ItemCost], CAST(oi.UnitPrice AS DECIMAL) AS [UnitPrice]    
  FROM Orders.OrderItems oi      
  WHERE oi.orderid= @OrderId AND oi.[Status] = 'ACTIVE' FOR JSON PATH) AS [ItemDetails]    
FROM orders.Orders  oo WITH (NOLOCK)    
LEFT JOIN [Orders].[OrderTransactionDetails] ot ON ot.OrderID = @OrderId AND ot.OrderStatusCode = 'PAY'  AND ot.IsActive = 1   
LEFT JOIN [Orders].[OrderTransactionDetails] ot1 ON ot1.OrderID = @OrderId AND ot1.OrderStatusCode = 'BEP' AND ot1.IsActive = 1  -- Added by Harika (for WEX and VISA Cancellation)  
LEFT JOIN [otc].[Cards] oc ON oc.[NHMemberId] = oo.NHMemberId  AND oc.[IsActive] = 1  
WHERE oo.OrderID = @OrderId  AND oo.OrderType =  'OTC'  
AND oo.OrderStatusCode in ('INI','EMI')    
AND oo.IsActive = 1  
END 