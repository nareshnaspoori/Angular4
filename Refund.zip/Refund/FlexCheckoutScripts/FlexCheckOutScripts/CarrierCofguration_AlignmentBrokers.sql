--Adding New Carrier AlignmentAgent And Configurations

BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
--------------------------------------STEP:1- Create Carrier,health plan and configure required configurations-------------------------------------------------------------------------------------------------

DECLARE @carrierName NVARCHAR(100)='Alignment Partners'
DECLARE @planName NVARCHAR(100)='Alignment Partners'
DECLARE @walletcode1 NVARCHAR(100) ='FLEXGROCERY';
DECLARE @walletcode2 NVARCHAR(100) ='FLEXOTC';
DECLARE @walletcode3 NVARCHAR(100) ='FLEXREWARDS';
DECLARE @displayWalletName1 NVARCHAR(100) ='Grocery';
DECLARE @displayWalletName2 NVARCHAR(100) ='OTC';
DECLARE @displayWalletName3 NVARCHAR(100) ='Rewards';

DECLARE @carrierId BIGINT
DECLARE @planId BIGINT;

--INSERTING CARRIER
INSERT INTO insurance.insurancecarriers (CreateDate,CreateUser,InsuranceCarrierName,IsActive,IsContracted,IsDiscountProgram,MemberDataFileProvided,ModifyDate,ModifyUser,IsAutoSendPaymentReceipt,CarrierConfig,IsNHDiscount,AllowAdditionalServices)
VALUES (getdate(),'script',@carrierName,1,1,0,0,getdate(),'script',0,'{"subdomain":"alignmentpartners","benefitValueSource":"fis","isManaged":true}',0,0)

--SELECT INSERTED CARRIERID
SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));


---INSERTING HEALTHPLAN

INSERT INTO insurance.insurancehealthplans (CreateDate,CreateUser,HealthPlanName,InsuranceCarrierID,IsActive,IsDiscountProgram,ModifyDate,ModifyUser,IsMedicaid,IsMedicare,IsProgramCode)
VALUES (getdate(),'script',@planName,@carrierId,1,0,getdate(),'script',0,0,0)

--SELECT INSERTED HEALTHPLANID
SELECT @planId=InsuranceHealthPlanID FROM insurance.insurancehealthplans WHERE HealthPlanName=@planName
PRINT Concat('InsuranceHealthplanId:',ISNULL(@planId,0))

IF(ISNULL(@carrierId,0) = 0 OR ISNULL(@planId,0)=0)
PRINT 'Carrier or plan creation failed.'

---INSERTING CONFIGURATIONS('CARRIERCONFIG','OTCLOGIN','OTCAPP','OTCCONTENT') 

INSERT INTO insurance.insuranceconfig(ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
VALUES
('CARRIERCONFIG','{"programType":"Funded","benefitTypes":["OTC"]}',@carrierId,getdate(),'Mnanduri',getdate(),'Mnanduri',1),
('OTCLOGIN','{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"allowAgentAccess":false,"benefitValueSource":"fis","loginTemplate":"OTCFlexStandard","ReplaceWallets":[],"AddWallets":[],"MapWallets":{"12100":"FLEXOTC","GROCERY 2100":"FLEXGROCERY"},"tags":[]}',@carrierId,getdate(),'Mnanduri',getdate(),'Mnanduri',1),
('OTCAPP','{"canSubscribe":false,"isHealthProfileDisabled":false,"alwaysViewCatalog":false,"disablePromotions":false,"expressOrdersDisabled":true,"Preferences":{"OrderUpdates" :{"sendEmail": true, "sendSMS": true}}}',@carrierId,getdate(),'Mnanduri',getdate(),'Mnanduri',1),
('OTCCONTENT','{"phone":"877-209-8596","showOTCGuidelines":false}',@carrierId,getdate(),'Mnanduri',getdate(),'Mnanduri',1);

-----------------------------------------------------STEP:2-Configuring catalogs for carrier-------------------------------------------------------------------------
DECLARE @walletSource NVARCHAR(100) ='NATIONS';
DECLARE @walletId1 BIGINT;
DECLARE @walletId2 BIGINT;
DECLARE @walletId3 BIGINT;

---OtherItems Wallet
INSERT INTO otccatalog.wallets (WalletName,WalletDescription,DisplayOrder,ShowonWeb,WalletCode,WalletSource,DisplayWalletName,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate,ColorCode)
VALUES 
(@displayWalletName2,@displayWalletName2,1,1,@walletcode2,@walletSource,@displayWalletName2,1,'mnanduri',getdate(),'mnanduri',getdate(),''),
(@displayWalletName3,@displayWalletName3,1,1,@walletcode3,@walletSource,@displayWalletName3,1,'mnanduri',getdate(),'mnanduri',getdate(),'');

---SELECT INSERTED WLLETID
SELECT TOP 1 @walletId1=walletId FROM otccatalog.wallets WHERE walletcode=@walletcode1
 PRINT CONCAT('WalletId:', ISNULL(@walletId1,0))

SELECT TOP 1 @walletId2=walletId FROM otccatalog.wallets WHERE walletcode=@walletcode2
 PRINT CONCAT('WalletId:', ISNULL(@walletId2,0))

 SELECT TOP 1 @walletId3=walletId FROM otccatalog.wallets WHERE walletcode=@walletcode3
 PRINT CONCAT('WalletId:', ISNULL(@walletId3,0))

---INSERT WALLETITEMS FOR NEW WALLET BY USING EXISTING 
INSERT INTO otccatalog.walletItems(NationsId,WalletId,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
VALUES
(5000,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5001,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5002,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5003,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5004,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5005,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5006,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5007,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5008,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5009,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5010,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5011,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5012,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5013,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5015,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5016,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5017,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5018,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5019,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5020,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5021,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5022,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5023,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5024,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5025,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5026,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5027,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5029,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5030,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5031,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate())


-- INSERT INTO WALLETPLANS
DECLARE @walletplanId1 bigint
DECLARE @walletplanId2 bigint
DECLARE @walletplanId3 bigint;


INSERT INTO otccatalog.walletplans (InsuranceCarrierId,WalletId,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
VALUES 
(@carrierId,@walletId1,1,'mnanduri',getdate(),'mnanduri',getdate()),
(@carrierId,@walletId2,1,'mnanduri',getdate(),'mnanduri',getdate()),
(@carrierId,@walletId3,1,'mnanduri',getdate(),'mnanduri',getdate());


SELECT TOP 1 @walletplanId1=WalletPlanId FROM otccatalog.walletplans WHERE InsuranceCarrierId=@carrierId AND WalletId=@walletId1;

SELECT TOP 1 @walletplanId2=WalletPlanId FROM otccatalog.walletplans WHERE InsuranceCarrierId=@carrierId AND WalletId=@walletId2;

SELECT TOP 1 @walletplanId3=WalletPlanId FROM otccatalog.walletplans WHERE InsuranceCarrierId=@carrierId AND WalletId=@walletId3;

IF(ISNULL(@walletId1,0)=0 or ISNULL(@walletplanId1,0)=0 or ISNULL(@walletId2,0)=0 or ISNULL(@walletplanId2,0)=0 or  ISNULL(@walletId3,0)=0 or ISNULL(@walletplanId3,0)=0)

PRINT 'catalog configuration failed.'

------------------------------------------------------------STEP:3-CONFIGURING BENEFITS-------------------------------------------------
--Inserting/creating healthplancontract
DECLARE @healthplanContractId BIGINT;
declare @contractname nvarchar(100)=concat(@carrierName,'_',@planName);

INSERT INTO  insurance.healthplancontracts(ContractName,CreateDate,CreateUser,Description,EffectiveFromDate,EffectiveToDate,InsuranceCarrierID,InsuranceHealthPlanID,IsActive	,ModifyDate,ModifyUser)
VALUES(@contractname,getdate(),'mnanduri',@contractname,getdate(),'2099-12-31 04:21:24.0100000',@carrierId,@planid,1,getdate(),'mnanduri');

---Select Inserted HEALTHPLANCONTRACTID
SELECT TOP 1 @healthplanContractId=HealthPlanContractID  FROM INSURANCE.HEALTHPLANCONTRACTS WHERE InsuranceCarrierID=@carrierId and InsuranceHealthPlanID=@planid;
PRINT CONCAT('healthplancontractid:',ISNULL(@healthplanContractId,0))


---Insert benefit rule
DECLARE @benefitruleid1 BIGINT
DECLARE @benefitruleid2 BIGINT
DECLARE @benefitruleid3 BIGINT

INSERT INTO rulesengine.benefitrulesdata(BenefitRuleId,BenefitRuleData,CreateUser,CreateDate,ModifyUser,ModifyDate,IsActive)
VALUES 
(2,'{"BENCAT":"Amount","BENCATVALUE":20,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":1,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"'+@walletcode2+'"}','MNanduri',getdate(),'MNanduri',getdate(),1),
(2,'{"BENCAT":"Amount","BENCATVALUE":10,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":1,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"'+@walletcode3+'"}','MNanduri',getdate(),'MNanduri',getdate(),1)

---Select inserted benefitrulId 
SELECT TOP 1 @benefitruleid1=BenefitRuleDataId  FROM rulesengine.benefitrulesdata WHERE JSON_VALUE(BenefitRuleData,'$.WALCODE')=@walletcode1
PRINT CONCAT('benefitruleid:',ISNULL(@benefitruleid1,0));

SELECT TOP 1 @benefitruleid2=BenefitRuleDataId  FROM rulesengine.benefitrulesdata WHERE JSON_VALUE(BenefitRuleData,'$.WALCODE')=@walletcode2
PRINT CONCAT('benefitruleid:',ISNULL(@benefitruleid2,0));

SELECT TOP 1 @benefitruleid3=BenefitRuleDataId  FROM rulesengine.benefitrulesdata WHERE JSON_VALUE(BenefitRuleData,'$.WALCODE')=@walletcode3
PRINT CONCAT('benefitruleid:',ISNULL(@benefitruleid3,0));

---Insert Contract rule
DECLARE @contractruleId1 BIGINT;
DECLARE @contractruleId2 BIGINT;
DECLARE @contractruleId3 BIGINT;

INSERT INTO INSURANCE.CONTRACTRULES(BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,CreateDate,ModifyUser,ModifyDate,IsActive)
VALUES
(@benefitruleid1,@healthplanContractId,getdate(),'2099-12-31 00:00:00.000','MNanduri',getdate(),'MNanduri',getdate(),1),
(@benefitruleid2,@healthplanContractId,getdate(),'2099-12-31 00:00:00.000','MNanduri',getdate(),'MNanduri',getdate(),1),
(@benefitruleid3,@healthplanContractId,getdate(),'2099-12-31 00:00:00.000','MNanduri',getdate(),'MNanduri',getdate(),1);

--Select inserted contract ruleid 
SELECT @contractruleId1=ContractRuleId FROM INSURANCE.CONTRACTRULES WHERE BenefitRuleDataId=@benefitruleid1 and HealthPlanContractId=@healthplanContractId
PRINT concat('ContarctruleId:',ISNULL(@contractruleid1,0))

SELECT @contractruleId2=ContractRuleId FROM INSURANCE.CONTRACTRULES WHERE BenefitRuleDataId=@benefitruleid2 and HealthPlanContractId=@healthplanContractId
PRINT concat('ContarctruleId:',ISNULL(@contractruleid2,0))

SELECT @contractruleId3=ContractRuleId FROM INSURANCE.CONTRACTRULES WHERE BenefitRuleDataId=@benefitruleid3 and HealthPlanContractId=@healthplanContractId
PRINT concat('ContarctruleId:',ISNULL(@contractruleid3,0))

--show error message if any inserted id is null or 0

IF(ISNULL(@healthplanContractId,0) = 0 OR  ISNULL(@benefitruleid1,0)=0  OR ISNULL(@contractruleid1,0)=0 or ISNULL(@benefitruleid2,0)=0  OR ISNULL(@contractruleid2,0)=0 or ISNULL(@benefitruleid3,0)=0  OR ISNULL(@contractruleid3,0)=0)
PRINT 'Benefit configuration failed.'


IF(@carrierId>0 AND @planId>0 AND @walletId1>0 AND @walletId2>0 AND @walletId3>0 AND @healthplanContractId >0 AND @benefitruleid1>0 AND  @benefitruleid2>0 AND  @benefitruleid3>0 AND @contractruleId1 > 0 AND @contractruleId2 > 0 AND @contractruleId3 > 0)

PRINT 'succefully executed.'

COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH

