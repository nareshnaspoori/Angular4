insert into Insurance.LoginTemplateConfig(LoginTemplate,FieldValidationConfig,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
values('OTCFlexStandard','{"InsuranceNumber": true,"LoginPassword": true}',1,'mnanduri',GETDATE(),'mnanduri',GETDATE())
