--Adding New Carrier Molina And Configurations

BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
--------------------------------------STEP:1- Create Carrier,health plan and configure required configurations-------------------------------------------------------------------------------------------------

DECLARE @carrierName NVARCHAR(100)='Molina'
DECLARE @planName NVARCHAR(100)='Molina HealthPlan'
DECLARE @walletcode NVARCHAR(100) ='FLEXGROCERY';
DECLARE @displayWalletName NVARCHAR(100) ='Grocery';

DECLARE @carrierId BIGINT
DECLARE @planId BIGINT;

--INSERTING CARRIER
INSERT INTO insurance.insurancecarriers (CreateDate,CreateUser,InsuranceCarrierName,IsActive,IsContracted,IsDiscountProgram,MemberDataFileProvided,ModifyDate,ModifyUser,IsAutoSendPaymentReceipt,CarrierConfig,IsNHDiscount,AllowAdditionalServices)
VALUES (getdate(),'script',@carrierName,1,1,0,0,getdate(),'script',0,'{"subdomain":"molina","benefitValueSource":"fis","isManaged":true}',0,0)

--SELECT INSERTED CARRIERID
SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));


---INSERTING HEALTHPLAN

INSERT INTO insurance.insurancehealthplans (CreateDate,CreateUser,HealthPlanName,InsuranceCarrierID,IsActive,IsDiscountProgram,ModifyDate,ModifyUser,IsMedicaid,IsMedicare,IsProgramCode)
VALUES (getdate(),'script',@planName,@carrierId,1,0,getdate(),'script',0,0,0)

--SELECT INSERTED HEALTHPLANID
SELECT @planId=InsuranceHealthPlanID FROM insurance.insurancehealthplans WHERE HealthPlanName=@planName
PRINT Concat('InsuranceHealthplanId:',ISNULL(@planId,0))

IF(ISNULL(@carrierId,0) = 0 OR ISNULL(@planId,0)=0)
PRINT 'Carrier or plan creation failed.'

---INSERTING CONFIGURATIONS('CARRIERCONFIG','OTCLOGIN','OTCAPP','OTCCONTENT') 

INSERT INTO insurance.insuranceconfig(ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
VALUES
('CARRIERCONFIG','{"programType":"Funded","benefitTypes":["OTC"]}',@carrierId,getdate(),'Mnanduri',getdate(),'Mnanduri',1),
('OTCLOGIN','{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"allowAgentAccess":false,"benefitValueSource":"fis","loginTemplate":"OTCFlexStandard","ReplaceWallets":[],"AddWallets":[],"MapWallets":{},"tags":[]}',@carrierId,getdate(),'Mnanduri',getdate(),'Mnanduri',1),
('OTCAPP','{"canSubscribe":false,"isHealthProfileDisabled":false,"alwaysViewCatalog":false,"disablePromotions":false,"expressOrdersDisabled":true,"Preferences":{"OrderUpdates" :{"sendEmail": true, "sendSMS": true}}}',@carrierId,getdate(),'Mnanduri',getdate(),'Mnanduri',1),
('OTCCONTENT','{"phone":"877-284-0513","showOTCGuidelines":false}',@carrierId,getdate(),'Mnanduri',getdate(),'Mnanduri',1);

-----------------------------------------------------STEP:2-Configuring catalogs for carrier-------------------------------------------------------------------------
DECLARE @walletSource NVARCHAR(100) ='NATIONS';
DECLARE @walletId BIGINT;

---OtherItems Wallet
INSERT INTO otccatalog.wallets (WalletName,WalletDescription,DisplayOrder,ShowonWeb,WalletCode,WalletSource,DisplayWalletName,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate,ColorCode)
VALUES 
(@displayWalletName,@displayWalletName,1,1,@walletcode,@walletSource,@displayWalletName,1,'mnanduri',getdate(),'mnanduri',getdate(),'')

---SELECT INSERTED WLLETID
SELECT TOP 1 @walletId=walletId FROM otccatalog.wallets WHERE walletcode=@walletcode
 PRINT CONCAT('WalletId:', ISNULL(@walletId,0))
 
---INSERT WALLETITEMS FOR NEW WALLET BY USING EXISTING 
INSERT INTO otccatalog.walletItems(NationsId,WalletId,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
VALUES
(5000,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5001,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5002,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5003,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5004,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5005,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5006,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5007,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5008,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5009,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5010,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5011,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5012,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5013,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate()),
(5015,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate())


-- INSERT INTO WALLETPLANS
DECLARE @walletplanId bigint;


INSERT INTO otccatalog.walletplans (InsuranceCarrierId,WalletId,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
VALUES (@carrierId,@walletId,1,'mnanduri',getdate(),'mnanduri',getdate());


SELECT TOP 1 @walletplanId=WalletPlanId FROM otccatalog.walletplans WHERE InsuranceCarrierId=@carrierId AND WalletId=@walletId;

IF(ISNULL(@walletId,0)=0 or ISNULL(@walletplanId,0)=0)

PRINT 'catalog configuration failed.'

------------------------------------------------------------STEP:3-CONFIGURING BENEFITS-------------------------------------------------
--Inserting/creating healthplancontract
DECLARE @healthplanContractId BIGINT;
declare @contractname nvarchar(100)=concat(@carrierName,'_',@planName);

INSERT INTO  insurance.healthplancontracts(ContractName,CreateDate,CreateUser,Description,EffectiveFromDate,EffectiveToDate,InsuranceCarrierID,InsuranceHealthPlanID,IsActive	,ModifyDate,ModifyUser)
VALUES(@contractname,getdate(),'mnanduri',@contractname,getdate(),'2099-12-31 04:21:24.0100000',@carrierId,@planid,1,getdate(),'mnanduri');

---Select Inserted HEALTHPLANCONTRACTID
SELECT TOP 1 @healthplanContractId=HealthPlanContractID  FROM INSURANCE.HEALTHPLANCONTRACTS WHERE InsuranceCarrierID=@carrierId and InsuranceHealthPlanID=@planid;
PRINT CONCAT('healthplancontractid:',ISNULL(@healthplanContractId,0))


---Insert benefit rule
DECLARE @benefitruleid BIGINT

INSERT INTO rulesengine.benefitrulesdata(BenefitRuleId,BenefitRuleData,CreateUser,CreateDate,ModifyUser,ModifyDate,IsActive)
VALUES 
(2,'{"BENCAT":"Amount","BENCATVALUE":30,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":1,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"'+@walletcode+'"}','MNanduri',getdate(),'MNanduri',getdate(),1);

---Select inserted benefitrulId 
SELECT TOP 1 @benefitruleid=BenefitRuleDataId  FROM rulesengine.benefitrulesdata WHERE JSON_VALUE(BenefitRuleData,'$.WALCODE')=@walletcode
PRINT CONCAT('benefitruleid:',ISNULL(@benefitruleid,0));

---Insert Contract rule
DECLARE @contractruleId BIGINT;

INSERT INTO INSURANCE.CONTRACTRULES(BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,CreateDate,ModifyUser,ModifyDate,IsActive)
VALUES(@benefitruleid,@healthplanContractId,getdate(),'2099-12-31 00:00:00.000','MNanduri',getdate(),'MNanduri',getdate(),1);

--Select inserted contract ruleid 
SELECT @contractruleId=ContractRuleId FROM INSURANCE.CONTRACTRULES WHERE BenefitRuleDataId=@benefitruleid and HealthPlanContractId=@healthplanContractId
PRINT concat('ContarctruleId:',ISNULL(@contractruleid,0))

--show error message if any inserted id is null or 0
IF(ISNULL(@healthplanContractId,0) = 0 OR  ISNULL(@benefitruleid,0)=0  OR ISNULL(@contractruleid,0)=0)
PRINT 'Benefit configuration failed.'


IF(@carrierId>0 AND @planId>0 AND @walletId>0 AND @healthplanContractId >0 AND @benefitruleid>0 AND @contractruleId > 0)
PRINT 'succefully executed.'

COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH

