-- =============================================  
-- Author:     THARUN  
-- Create Date: 19-December-2020  
-- Description:Authenticate OTCNationsStandardTemplate  
-- =============================================  
  
-- 12/30/2020 Returning Client Plan Id to Return Response Procedure (Plan level config issue fix) 
-- =============================================
   -- Updated By : Joel b
   -- Updated Date :05-Aug-2021
   -- Changes: Added Carrierid Feild Condition to avoid duplcate profiles
-- =============================================
  
CREATE OR ALTER PROCEDURE [otc].[AuthenticateOTCNationsStandardLogin] (  
  @domain VARCHAR(200)  
 ,@loginData VARCHAR(2000)  
 ,@isSSO BIT  
 )  
AS  
BEGIN  
 --Global Variables  
 DECLARE @NHmemberId VARCHAR(100)  
 DECLARE @envelopNHId VARCHAR(100)  
 DECLARE @memCarrierID BIGINT  
 DECLARE @errorMessage VARCHAR(200)  
 DECLARE @fieldValidationConfig VARCHAR(2000)  
 DECLARE @domainCarrierID BIGINT  
 DECLARE @healthPlanId BIGINT  
 ---Constants  
 DECLARE @LoginTemplate_OTCNationsStandard VARCHAR(100) = 'OTCNationsStandard'  
  
 BEGIN  
  --validate input data   
  IF (@domain IS NULL OR @loginData IS NULL)  
  BEGIN  
   EXECUTE [otc].[ThrowErrorMessage] 'Invalid input data.', 51400  
  END  
  
  --getting domain carrierid  
  SELECT TOP 1 @domainCarrierID = InsuranceCarrierID  
  FROM Insurance.InsuranceCarriers  
  WHERE IsActive = 1  
   AND JSON_VALUE(CarrierConfig, '$.subdomain') = @domain  
  ORDER BY InsuranceCarrierId  
  
  --validate subdomain whether it is belong to any insurance carrier or not  
  IF (@domainCarrierID IS NULL)  
  BEGIN  
   EXECUTE [otc].[ThrowErrorMessage] 'Invalid subdomain.', 51400  
  END  
  
  SELECT @fieldValidationConfig = FieldValidationConfig  
  FROM Insurance.LoginTemplateConfig  
  WHERE LoginTemplate = @LoginTemplate_OTCNationsStandard  
   AND IsActive = 1  
  
  IF (@fieldValidationConfig IS NULL)  
  BEGIN  
   SET @errorMessage = 'Insurance.LoginTemplateConfig table is missing LoginTemplate values for template [ ' + @LoginTemplate_OTCNationsStandard + ']'  
  
   EXECUTE [otc].[ThrowErrorMessage] @errorMessage, 51503  
  END  
  
  IF (@isSSO = 0 AND CAST(JSON_VALUE(@fieldValidationConfig, '$.LoginPassword') AS BIT) = 0)  
  BEGIN  
   SET @errorMessage='Password is required.'  
   EXECUTE [otc].[ThrowErrorMessage] @errorMessage,51503  
  END  
  
  
  BEGIN  
     
   SET @envelopNHId = JSON_VALUE(@loginData, '$.NHMemberId');  
   SELECT @NHmemberId = m.NHMemberID  
    ,@memCarrierID = mi.InsuranceCarrierID  
    ,@healthPlanId = mi.Insurancehealthplanid  
   FROM MASTER.MemberInsuranceDetails mid  
   INNER JOIN [Master].[MemberInsurances] mi ON mi.ID = mid.MemberInsuranceID  
    AND mi.IsActive = 1  
   INNER JOIN Master.Members m ON m.MemberID = mi.MemberID  
    AND m.IsActive = 1  
   WHERE mid.InsuranceNbr = JSON_VALUE(@loginData, '$.InsuranceNumber')  
    AND mid.IsActive = 1  
	AND mi.InsuranceCarrierID=@domainCarrierID --Added Carrierid Feild Condition 
    AND mi.InsuranceType IN (  
     'primary'  
     ,'discount'  
    )  
    AND (GETDATE() BETWEEN mi.InsuranceEffectiveDate AND mi.InsuranceEndDate)  
    AND NOT EXISTS (  
     SELECT *  
     FROM [provider].[IVQueue] ivq  
     WHERE ivq.NHMemberID = m.NHMemberID  
      AND ivq.insurancecarrierId = mi.Insurancecarrierid  
      AND ivq.insurancehealthplanid = mi.Insurancehealthplanid  
      AND (  
       ivq.IsApproved = 0  
       OR ivq.IsApproved IS NULL  
      )  
      AND ivq.IsActive = 1  
     )  
    ORDER BY InsuranceEndDate DESC  
  
   PRINT 'NHMemberId:' + @NHmemberId;  
   PRINT 'subdomain CarrierId:' + CAST(@domainCarrierId AS VARCHAR)  
   PRINT 'MeberCarrierId:' + CAST(@memCarrierID AS VARCHAR)  
     
   IF ((@NHmemberId IS NOT NULL AND @envelopNHId IS NOT NULL AND @envelopNHId <> @NHmemberId))  
   BEGIN  
    SET @errorMessage = 'Envelop NH Id does not match with Insurance Nbr NH Id. '  
    +'@envelopNHId = ' +@envelopNHId + '@NHmemberId = ' +@NHmemberId;  
  
    EXECUTE [otc].[ThrowErrorMessage] @errorMessage, 51503  
   END  
  
   SET @NHmemberId = ISNULL(@envelopNHId, @NHmemberId);  
   IF (@domainCarrierId <> @memCarrierID)  
   BEGIN  
    SET @errorMessage = 'Member does not belongs to ' + @domain + ' domain. '+ '@NHmemberId = ' +@NHmemberId + 'DomainCarrierId' + cast( @domainCarrierId as char) +'MemberCarrierID'+ cast(@memCarrierID as char) ;;  
    --SET @errorMessage = 'Member does not belongs to ' + @domain + ' domain. '+ '@NHmemberId = ' +@NHmemberId ;  
  
    EXECUTE [otc].[ThrowErrorMessage] @errorMessage, 51503  
   END  
  
   --Extract existing NHMemberId  
   DECLARE @existNHMemberId NVARCHAR(50);  
  
   SELECT @existNHMemberId = nhmemberId  
   FROM otc.UserProfiles  
   WHERE UserName = JSON_VALUE(@loginData, '$.InsuranceNumber')  
    AND ISACTIVE = 1  
  
   IF (@existNHMemberId IS NULL AND @envelopNHId IS NOT NULL)  
   BEGIN  
    SELECT @existNHMemberId = nhmemberId  
    FROM otc.UserProfiles  
    WHERE nhmemberId = @envelopNHId  
     AND ISACTIVE = 1  
   END  
     
   IF ((@NHmemberId IS NOT NULL AND @existNHMemberId IS NOT NULL AND @existNHMemberId <> @NHmemberId))  
   BEGIN  
    SET @errorMessage = 'Username associated to another member profile.'  
    + '@NHmemberId = ' + @NHmemberId + '@existNHMemberId = ' + @existNHMemberId;  
  
    EXECUTE [otc].[ThrowErrorMessage] @errorMessage, 51503  
   END  
  
   SET @NHmemberId = ISNULL(@existNHMemberId, @NHmemberId);  
  
   IF (@NHmemberId IS NULL AND @envelopNHId IS NULL AND @existNHMemberId IS NULL)  
   BEGIN  
    SET @errorMessage = 'Member not found. '+ '@InsuranceNumber = ' + JSON_VALUE(@loginData, '$.InsuranceNumber');  
  
    EXECUTE [otc].[ThrowErrorMessage] @errorMessage, 51503  
   END  
  
   ELSE  
   BEGIN  
  
    PRINT '@NHmemberId = ' + @NHmemberId + '@existNHMemberId = ' + @existNHMemberId +'@envelopNHId = ' +@envelopNHId;  
      
    IF (@healthPlanId IS NOT NULL AND @healthPlanId > 0)  
    SET @loginData = JSON_MODIFY(@loginData, '$.PlanId', @healthPlanId);  
  
    EXEC [otc].[ReturnLoginAuthenticationResponse] @domain, @loginData, @NHmemberId  
  
    RETURN  
   END  
  END  
 END  
END  