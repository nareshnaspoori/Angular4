  -- exec  sp_helptext '[otc].[InsertRefundOrderDetails]'
   DECLARE @itemData  NVARCHAR(max)= N'[{"Quantity":3, "price":30, "totalPirce":90,"productName":"tett tree medcines" }]'
	 DECLARE @OrderId bigint =190009011
	 DECLARE @RequestData varchar(4000) ='{"Reason":"Other","AdditionalComments":"abc"}'
	 DECLARE @NHMemberId nvarchar(100)='OTC201901964107'
	 DECLARE @SubmitUserProfileId bigint--=11924
	 --DECLARE @AdminComments nvarchar(max)='Refund this order'
	 DECLARE @CreateUser nvarchar(100) --='GailFran'
	 DECLARE @OrderChangeRequestItems NVARCHAR(max)  = '[{"OrderId" : 190009011,  "OrderItemId": 78963, "ItemCode": "97958116426", "Quantity":3, "ItemData": "","Comments":"refund is needed"  }
 ]'
 DECLARE @IsRefund bit=1


exec [otc].InsertRefundReshipOrderDetails
     @OrderId 	
	,@RequestData 
	,@NHMemberId 
	,@SubmitUserProfileId 
	--,@AdminComments 
	,@CreateUser 
	,@OrderChangeRequestItems 
	,@IsRefund	

	 DECLARE @itemData  NVARCHAR(max)= N'[{"Quantity":3, "price":30, "totalPirce":90,"productName":"tett tree medcines" }]'
	  update [Orders].[OrderChangeRequestItems]
	  set itemData =@itemData
	  where orderitemid =78964 --  1 886303

	 DECLARE @OrderId bigint =190009011
	 DECLARE @RequestData varchar(4000) ='{"Reason":"Other","AdditionalComments":"abc"}'
	 DECLARE @NHMemberId nvarchar(100)='OTC201901964107'
	 DECLARE @SubmitUserProfileId bigint=11924
	 --DECLARE @AdminComments nvarchar(max)='Refund this order'
	 DECLARE @CreateUser nvarchar(100) ='GailFran'
	 DECLARE @OrderChangeRequestItems NVARCHAR(max)  = N'[{"OrderId" : 190009011,  "OrderItemId": 78962, "ItemCode": "74887622204", "Quantity": 3,  "ItemData": "tt" ,"Comments":"reship is needed"  },
	 {"OrderId" : 190009011,  "OrderItemId": 78963, "ItemCode": "97957806098", "Quantity": 2,  "ItemData": "kk" ,"Comments":"reship is needed"  }
 ]'
 DECLARE @IsRefund bit=1
 

exec [otc].InsertRefundReshipOrderDetails
     @OrderId 	
	,@RequestData 
	,@NHMemberId 
	,@SubmitUserProfileId 
	--,@AdminComments 
	,@CreateUser 
	,@OrderChangeRequestItems 
	,@IsRefund







		 select  * from orders.orders where orderid =200206687  order by 1 desc
   select  * from orders.orderitems where orderid =200206687  order by 1 desc
	select top 10 *from	[Orders].[OrderChangeRequests] where orderid =200206687 order by 1 desc
	select top 10  *from [Orders].[OrderChangeRequestItems] where orderid =200206687 order by 1 desc

	UPDATE  orders.orderitems
	SET STATU =''

select top 10 *from	[Orders].[OrderChangeRequests] where orderid =200265168 order by 1 desc
	select top 10  *from [Orders].[OrderChangeRequestItems] where orderid =200265168 order by 1 desc
	
	select top 10  *from [Orders].[OrderChangeRequests order by 1 desc
	 select  * from orders.orders order by 1 desc



		select top 10  *from [Orders].[OrderTransactionDetails]  order by 1 desc
		select top 10 *from	[Orders].[OrderTransactionDetails] where orderid =200265168 order by 1 desc
	
	 select  * from orders.orders where orderid =200265594  order by 1 desc
   select  TOP 10  * from orders.orders where JSON_VALUE(OrderAmountData,'$.paymentType') like'%CC%'  order by 1 desc
   	 
	 
	 select top 10  * from orders.ordertransactiondetails where JSON_VALUE(OrderTransactionData,'$.paymentType') like'%CC%' order by 1 desc

	 select top 10  * from orders.orders order by 1 desc
   select  * from orders.orderitems where orderid =200238447  order by 1 desc
    
	 select TOP 10   * from orders.orders where ordertype ='OTC' AND STATUS=''   order by 1 desc
	 [otc].[GetAllOTCOrderItemDetails]  200238447
	DELETE FROM  [Orders].[OrderChangeRequests] where orderid =200265740
	DELETE FROM [Orders].[OrderChangeRequestItems] where orderid =200265740
	select top 10 *from	[Orders].[OrderChangeRequests] order by 1 desc
	select top  10  *from [Orders].[OrderChangeRequestItems]  order by 1 desc
	
  UPDATE orders.orderitems
 SET    
   status ='active' 
 --, ItemData = Json_modify(ItemData,'$.Remarks','Refund Applied')
 where orderid =200270074   --and orderitemid IN (78964,78963,78962)
 
 update orders.orders
 SET OrderStatusCode ='SHI'   ---SHI
-- ,ModifyDate = getdate()
 --,ModifyUser = 'GailFran'
 where OrderId =200270930    
   
 -- user profile insert
 SELECT TOP 20  *FROM otc.userprofiles up WHERE NHMemberId='QA202005647868' 

 --QA202005647868
INSERT INTO otc.userprofiles (UserName,PasswordSalt,PasswordHash,IsReceiveOffers,IsBlocked,IsActive,CreateUser, CreateDate,ModifyUser,ModifyDate,nhmemberId)
VALUES('rr','$2a$10$8xBVz9Hmfpl7j/rEZhxtxe','$2a$10$8xBVz9Hmfpl7j/rEZhxtxehrxyENuoOnhxCUwpaB1jmA/X4Yb0jIu',0,0,1,'SystemUser',GETDATE(),'SystemUser',GETDATE(),'QA202005647868')
--=========================

	 DECLARE @OrderId bigint =190009011
	 DECLARE @RequestData varchar(4000) ='{"Reason":"Other","AdditionalComments":"abc"}'
	 DECLARE @NHMemberId nvarchar(100)='OTC201901964101'
	 DECLARE @SubmitUserProfileId bigint=11924
	 --DECLARE @AdminComments nvarchar(max)='Refund this order'
	 DECLARE @CreateUser nvarchar(100) ='GailFran'
	 DECLARE @OrderChangeRequestItems NVARCHAR(max)  = N'[{"OrderId" : 190009011,  "OrderItemId": 78964, "ItemCode": "97958116426", "Quantity": 1,  "ItemData": "25" ,"Comments":"refund is needed"  } 
  ]'


	SELECT  orderItemId FROM OPENJSON(@OrderChangeRequestItems)
 WITH (
  OrderId bigint '$.OrderId' 
 ,OrderItemId bigint '$.OrderItemId' 
 ,ItemCode nvarchar(200) '$.ItemCode' 
 ,Quantity bit '$.Quantity' 
 ,PriceData varchar(4000) '$.PriceData' 
 ) t

 select top 10 * from orders.orders where ordertype ='OTC' and orderstatuscode ='shi' order by 1 desc
 select top 5 * from orders.orderitems where orderid =190009011  order by 1 desc
  select top 5 * from orders.orderitems where orderid =200250902  order by 1 desc
 

  select top 5 * from orders.orderitems order by 1 desc

 select *from master.members where nhmemberid IN (select top 10 nhmemberid from orders.orders where ordertype ='OTC' and orderstatuscode ='shi' order by 1 desc)

 select top 10 * from orders.orders where ordertype ='OTC' and orderstatuscode ='shi'  and nhmemberid ='OTC201901964107' order by 1 desc

  select top 5 * from orders.orderitems where orderid =190009011  order by 1 desc

  
  select top 10 *from	[Orders].[OrderChangeRequests] where orderid =200238447 order by 1 desc
 
  select  * from orders.orders where orderid =190009011  order by 1 desc
   select  * from orders.orderitems where orderid =200084345  order by 1 desc
  
  "Remarks": "Refund Applied."


  SELECT TOP 10 *FROM  [npn].[ContractReviewComments]  order by 1 desc

   SELECT TOP 1 STATUS
			FROM orders.orderitems
			WHERE  OrderItemId =78964






 SELECT   
   @SCOPE_IDENTITY OrderChangeRequestId
   ,@OrderId
   ,*
   ,@STATUS Status
   ,(select status from orders.orderitems where orderItemid = OrderItemId)
   ,NULL Comments
   ,getdate() CreateDate
   ,@CreateUser CreateUser
   ,1 IsActive
   ,getdate() ModifyDate
   ,@CreateUser ModifyUser
   from
   (SELECT  *FROM OPENJSON(@OrderChangeRequestItems)
 WITH (
  --OrderId bigint '$.OrderId' 
	OrderItemId bigint '$.OrderItemId' 
	,ItemCode nvarchar(200) '$.ItemCode' 
	,Quantity bit '$.Quantity' 
	,PriceData varchar(4000) '$.PriceData' 
 )) t




 [otc].[GetOrderChangeRequests] 
 
sp_helptext '[otc].[GetAllOTCOrderItemDetails]' 200264035

[otc].[GetAllOTCOrderItemDetails] 200264151
[{"ItemCode":"88438910206","ItemName":"Pedal Exerciser","Quantity":4,"ItemStatus":"ACTIVE","UnitPrice":87.00,"ItemMedialUrl":"\/6073\/6073_Front.jpg","ItemAttributeValue":6073,"CatalogName":"Alignment 009 Medicare","OrderItemId":1886308}]


update  orders.Orders set OrderStatusCode='SHI' where orderid=200265740

sp_helptext 'otc.GetAllMemberOTCOrders'


  select top 10 *from	[Orders].[OrderChangeRequests] where orderid =200265138 order by 1 desc
  select top 10 *from	[Orders].OrderChangeRequestItems where orderid =200264183 order by 1 desc
     select  * from orders.orderitems where orderid =200238447  order by 1 desc

  select top 10 *from	[Orders].OrderChangeRequestItems  order by 1 desc
    select top 10 *from	[Orders].[OrderChangeRequests] order by 1 desc
  update [Orders].OrderChangeRequestItems
  set STATUS ='REJECTED' WHERE OrderChangeRequestItemId =10532



  select  * from orders.orders where orderid =200264171  order by 1 desc   --200264171 NH202106670903

   [otc].[GetAllOTCOrderItemDetails]   200238447     --- 200250902    NH202005632192

Select SUM(ocri.Quantity) refundedQuantity,oi.OrderItemId from orders.OrderChangeRequestItems ocri WITH (NOLOCK)
 INNER JOIN orders.OrderItems oi on oi.OrderId =ocri.orderId and oi.OrderItemId =ocri.OrderItemId
 INNER JOIN [Orders].[OrderChangeRequests] ocrir on ocrir.OrderChangeRequestID =ocri.OrderChangeRequestID
 WHERE  oi.OrderId = 200264171  and oi.Status ='REFUND_PENDING'
GROUP BY ocri.Quantity ,oi.OrderItemId 

Select SUM(ocri.Quantity) refundedQuantity,oi.OrderItemId from orders.OrderChangeRequestItems ocri -- WITH (NOLOCK)
 INNER JOIN  orders.OrderItems oi  on  oi.OrderId =ocri.orderId and ocri.OrderItemId =oi.OrderItemId
INNER JOIN [Orders].[OrderChangeRequests] ocrir on ocrir.OrderChangeRequestID =ocri.OrderChangeRequestID 
 WHERE  ocri.OrderId = 200264171  and oi.Status ='RESHIP_PENDING'
 GROUP BY ocri.Quantity, oi.OrderItemId ;



Select SUM(oi.Quantity) refundedQuantity  from orders.OrderItems oi WITH (NOLOCK)
 left JOIN  orders.OrderChangeRequestItems ocri  on  ocri.OrderId =oi.orderId and ocri.OrderItemId =oi.OrderItemId
 INNER JOIN [Orders].[OrderChangeRequests] ocrir on ocrir.OrderChangeRequestID =ocri.OrderChangeRequestID 
 WHERE  ocri.OrderId = 200264171  and oi.Status ='RESHIP_PENDING'
GROUP BY ocri.Quantity ,oi.Status






(Select   ocri.OrderItemId,  string_AGG(ocri.Status, '; ') WITHIN GROUP(ORDER BY ocri.OrderItemId)  from orders.OrderChangeRequestItems ocri -- WITH (NOLOCK)
	INNER JOIN  orders.OrderItems oim  on  oim.OrderId =ocri.orderId and ocri.OrderItemId =oim.OrderItemId
    INNER JOIN [Orders].[OrderChangeRequests] ocrir on ocrir.OrderChangeRequestID =ocri.OrderChangeRequestID 
	WHERE  ocri.OrderId = 200238447   
	GROUP BY ocri.OrderItemId)  --for  json auto  AS ChangeRequestIt emStatus

	 
--select top 10 * from orders.orders where nhmemberid ='QA202005647868'





drop table #TMPtBL
declare @NHMemberId NVARCHAR(max) ='NH202106672101'
SELECT * INTO   #TMPtBL
FROM (
SELECT  CASE 
	WHEN oi.quantity = SUM(ocri.quantity)  THEN 0
	ELSE   1 END AS IsPartialOrder,oi.quantity,ocri.quantity as requestQuantity, ocri.orderItemId
	,oi.orderId FROM  orders.orderItems oi 
	JOIN Orders.Orders oo ON oo.orderId = oi.Orderid
	LEFT JOIN orders.OrderChangeRequestItems ocri  ON oi.orderId = ocri.orderId and oi.OrderItemId=ocri.orderItemId 
	where ocri.status IN ('approved','pending') and oo.NHMemberId =@nhMemberId
	GROUP BY  ocri.orderItemId,oi.quantity,oi.orderId,ocri.quantity
	--ORDER BY  ocri.orderItemId DESC
) as x

declare @NHMemberId NVARCHAR(max) ='NH202106672101'
SELECT CASE 
	WHEN oi.quantity = SUM(ocri.quantity)  THEN 0
	ELSE   1 END AS IsPartialOrder,oi.quantity,ocri.quantity as requestQuantity, ocri.orderItemId
	,oi.orderId FROM  orders.orderItems oi 
	JOIN Orders.Orders oo ON oo.orderId = oi.Orderid
	inner JOIN orders.OrderChangeRequestItems ocri  ON oi.orderId = ocri.orderId and oi.OrderItemId=ocri.orderItemId 
	where ocri.status IN ('approved','pending') and oo.NHMemberId =@nhMemberId
	GROUP BY  ocri.orderItemId,oi.quantity,oi.orderId,ocri.quantity
	--ORDER BY  ocri.orderItemId DESC






	 select top 10 *from	[Orders].OrderChangeRequestS order by 1 desc
	   select top 20 *from	[Orders].OrderChangeRequestItems   order by 1 desc
	    select top 10 *from  orders.orderItems  where orderid =200265253 order by 1 desc
		 select top 10 *from  orders.orders  where orderid =200265253 order by 1 desc







SELECT *FROM #TMPtBL


SELECT orderId,
CASE WHEN 
(SELECT COUNT(*) FROM   #TMPtBL WHERE IsPartialOrder in(1) group by IsPartialOrder,orderId )>0 THEN 1 ELSE 0 end as IsPartialOrder
FROM #TMPtBL
GROUP BY orderId

select *from #Temp123

drop table #Temp123
SELECT * INTO #Temp123 from(
EXEC [Orders].[GetRequestPartialOrderStatus] 'NH202106670816')


UPDATE orders.OrderChangeRequestItems set Quantity= 1 where orderitemid=1888613


UPDATE  #TMPtBL
SET IsPartialOrder =1 WHERE orderItemId =1888613 AND 




UPDATE Orders.Orders set Status ='REFUNDED'  where orderid=200238447
UPDATE Orders.Orders set OrderStatusCode ='REF'  where orderid=200238447
UPDATE Orders.OrderItems set Status ='ACTIVE'  where OrderItemId in(1795451)

 

 

UPDATE orders.OrderChangeRequests set Status='APPROVED' where orderid=200238447
UPDATE orders.OrderChangeRequestItems set Status= 'APPROVED' where orderid=200238447


 --  select top 10 *from	[Orders].[OrderChangeRequests] where orderid =200264930 order by 1 desc
 -- select top 10 *from	[Orders].OrderChangeRequestItems where orderid =200264930 order by 1 desc
  --select top 10 *from	[Orders].OrderChangeRequestItems  order by 1 desc
  select top 10 *from	[Orders].[OrderChangeRequests]  order by 1 desc
   select top 10 *from	 orders.orders order by 1 desc

   select top 10 *from otc.userprofiles up where up.NHMemberId ='NH202106672032'
	
	update orders.orders set Orderstatuscode='SHI' Where OrderId=200265740
	
	
	declare @action NVarchar(max) ='Refund'
	declare @refundAmtType NVarchar(max) ='Member Responsibility'
	--declare @OrderTransactionData Nvarchar(max()
	--declare @OrderId bigint =
	 declare @OrderTransactionData NVARCHAR(MAX) 
 --SET @OrderTransactionData = 
	select OCR.OrderChangeRequestID 	 
	, refTransactions.orderChangeRequestItemId
	,(JSON_VALUE(otd.OrderTransactionData,'$.transactions[0].transactionId'))AS transactionId 
	,(JSON_VALUE(otd.OrderTransactionData,'$.transactions[0].paymentType'))AS paymentType 
    ,(SELECT GETDATE()) AS refundDate
	,(JSON_VALUE(ocr.RequestData,'$.paymentDetails[0].amountReturnToPocket') ) as refundAmount
	,@action  AS action
	,@refundAmtType AS refundAmtType
	,'Pending' as status
	  FROM [Orders].[OrderChangeRequests] OCR  
	  INNER  JOIN  [Orders].[OrderTransactionDetails] otd ON otd.OrderId=OCR.OrderId
	 INNER JOIN  [Orders].OrderChangeRequestItems refTransactions ON refTransactions.OrderId=otd.OrderId
	
	   WHERE OCR.changeType = 'REFUND'  and otd.OrderStatusCode='PAY' and ocr.changeType = 'REFUND' and ocr.OrderId IN (200265160)   
	    FOR JSON  AUTO 
	 

	  print @OrderTransactionData
	  	 select top 10  * from orders.ordertransactiondetails otd 
		 inner join orders.orders oo on otd.orderid =oo.orderid where otd.OrderStatusCode='PAY' and oo.status ='REF_p' ORDER BY 1 DESC



	 select top 10  * from orders.ordertransactiondetails where JSON_VALUE(OrderTransactionData,'$.transactions[0].paymentType') like'%CC%' order by 1 desc

	  select top 10  * from orders.ordertransactiondetails  order by 1 desc FOR JSON AUTO
	    select top 10  * from [orders].[OrderChangeRequests] ocr
		 inner join otc.cards crd ON ocr.NHMemberId =crd.NHMemberId
		 where  ocr.changeType='REfund'  order by 1 desc

	  [Orders].[OrderChangeRequests]

	INSERT INTO Orders.OrderTransactionDetails  (
	Orderid
	,OrderStatusCode
	,OrderTransactionData
	,IsComplete
	,CreatedDate
	,CreateUser
	,IsActive
	)
	VALUES
	(
	
	
	)



	update orders.orders set Orderstatuscode='SHI' ,status ='active'  Where OrderId= 200265780    --200265654 200265653 200265652  200265651 200265650 200265648

	SELECT TOP 10 *FROM  orders.orderiTEMS  Where OrderId IN(200265657   ) -- 200265654 200265653 200265652 200265651 200265650  200265648  200265489, 200265490, 200265491,    200265493  200265496
	 
	SELECT TOP 10 *FROM  orders.orders  Where OrderId IN(200265884   ) -- 200265654 200265653 200265652 200265651 200265650  200265648  200265489, 200265490, 200265491,    200265493  200265496
	 
		update orders.orders
		SET  OrderAmountData ='{"price":0.0,"amountCovered":0.0,"outOfPocket":0.0,"benefitTransactions":[{"catalogName": "EON Health Plan", "originalWalletCode": null, "benefitType":"EON Health Plan","acctLast4Digits":null,"amountCovered":0.0 ,"amountRemaining":0.0,"transactionId":null,"outOfPocket":0.0,"source":"NATIONS","emiData":null}]}'
		WHERE ORDERID=200265748
	 select top 10  * from orders.ordertransactiondetails where orderid IN(200265744) order by 1 desc
	  	SELECT TOP 10 *FROM  orders.orders ORDER BY 1 DESC
			  select top 10  * from orders.ordertransactiondetails ORDER BY 1 DESC
			  delete from orders.ordertransactiondetails where orderTransactionid in (980784
)

	  	    select top 10  * from [orders].[OrderChangeRequests] order by 1 desc   -- where orderid = 200265657  200265489
	  	    select top 10  * from [orders].[OrderChangeRequestItems] order by 1 desc   -- where orderid = 200265657  200265489
			select * from Orders.OrderChangeRequests where  OrderID in (200265657,200265491)
			exec [otc].[GetAllMemberOTCOrders] 'NH202106672204'

			  select top 10  * from [orders].[OrderChangeRequests]  where orderid = 200265489  order by 1 desc
			    select top 10  * from [orders].[OrderChangeRequestItems] where orderid = 200265599 order by 1 desc
				   select top 10  * from [orders].[OrderChangeRequests] where ChangeType ='refund 'order by 1 desc

				   select top 10* from [master].[MemberInsuranceDetails] order by 1 desc
				      select top 10* from [master].[memberinsurances] order by 1 desc
					   select top 10* from otc.userProfiles order by 1 desc

					   select top 10  *from   otc.cards WHERE NHMEMBERID ='NH202106672204'
					    select top 10* from [master].[memberinsurances] order by 1 desc

 select top 10* from otc.userprofiles order by 1 desc
			SELECT *FROM OPENJSON(SELECT OrderAmountData from   orders.orders Where OrderId IN(200265493))
	  with(
	  price BIGINT '$.price'
	  
	  )t

	  DECLARE @orderAmountData nvarchar(max) =(SELECT OrderAmountData from   orders.orders Where OrderId IN(200265493))
	  --select @orderAmountData
	    SELECT  price,originalWalletCode FROM CROSS APPLY OPENJSON(@orderAmountData)
	  with(
	  price  nvarchar(max) '$.price',
	  originalWalletCode nvarchar(max) '$.benefitTransactions.originalWalletCode'
	  )t
	  
	  
	  
	  DECLARE @orderAmountData nvarchar(max) =(SELECT OrderAmountData from   orders.orders Where OrderId IN(200265489 ))
	 -- select @orderAmountData
	 
	
    SELECT
        JSON_Value (c.value, '$.catalogName') as catalogName 
        ,JSON_Value (c.value, '$.originalWalletCode') as originalWalletCode
		,JSON_Value (c.value, '$.source') as source

    FROM OPENJSON (@orderAmountData, '$.benefitTransactions') as c

		SP_HELPTEXT '[otc].[InsertChangeRequestTranasactionDetails]'

		SELECT TOP 10 * FROM orders.orders order by 1 desc

		select TOP 10  JSON_VALUE(OrderAmountData,'$.benefitTransactions[0].source')
		FROM ORDERS.ORDERS  	--ORDER BY 1 DESC
		WHERE  JSON_VALUE(OrderAmountData,'$.benefitTransactions[0].source') ='NATIONS'
		ORDER BY 1 DESC


		SP_HELPTEXT '[otc].[GetAllMemberOTCOrders_Shiva]'


		 (Select SUM(ocri.Quantity) totalQuanity from orders.OrderChangeRequestItems ocri WITH (NOLOCK)      
  --INNER JOIN [Orders].[OrderChangeRequests] ocrir WITH (NOLOCK)    ON ocrir.OrderChangeRequestID =ocri.OrderChangeRequestID    
 WHERE  ocri.OrderId = 200265769 AND  ocri.orderItemId = oi.orderItemId AND ocri.Status!='REJECTED' --AND ocrir.ChangeType!='RESHIP' 
 GROUP BY ocri.Quantity )as ChangeRequestedQuantity      


 declare @OrderId bigint =200265769

 --SELECT TOP 1  orc.status FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId and orc.OrderItemId = oi.OrderItemId ORDER BY  orc.OrderChangeRequestItemId desc


 select (SELECT TOP 1  orc.status FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId and orc.OrderItemId = oi.OrderItemId ORDER BY  orc.OrderChangeRequestItemId desc) as ChangeRequestItemStatus            
 ,(SELECT TOP 1  orc.Comments  FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId and orc.OrderItemId = oi.OrderItemId ORDER BY  orc.OrderChangeRequestItemId desc) as ChangeRequestItemComment           
 ,(SELECT TOP 1  orc.Quantity  FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId and orc.OrderItemId = oi.OrderItemId ORDER BY  orc.OrderChangeRequestItemId desc) as ChangeRequestItemQuantity          
 ,(SELECT TOP 1  ocr.changeType from [Orders].[OrderChangeRequests] ocr WITH (NOLOCK) LEFT JOIN  [Orders].[OrderChangeRequestItems]  ocri ON ocri.orderid = ocr.orderId AND ocri.OrderChangeRequestID = ocr.OrderChangeRequestID   WHERE  ocr.orderid = @OrderId  
   
   declare @OrderId bigint =200265774

   Select SUM(ocri.Quantity) refundedQuantity from orders.OrderChangeRequestItems ocri WITH (NOLOCK)
 INNER JOIN orders.OrderItems oi  WITH (NOLOCK) on oi.OrderId =ocri.orderId and oi.OrderItemId =ocri.OrderItemId
 INNER JOIN [Orders].[OrderChangeRequests] ocrir  WITH (NOLOCK) on ocrir.OrderChangeRequestID =ocri.OrderChangeRequestID
 WHERE  oi.OrderId = @OrderId  and oi.Status ='REFUND_PENDING'
GROUP BY oi.OrderId

	 Select SUM(ocri.Quantity) totalQuanity from orders.OrderChangeRequestItems ocri WITH (NOLOCK) 
	 INNER JOIN orders.OrderItems oi  WITH (NOLOCK) on oi.OrderId =ocri.orderId and oi.OrderItemId =ocri.OrderItemId
 WHERE  ocri.OrderId = @OrderId AND  ocri.orderItemId = oi.orderItemId AND ocri.Status!='REJECTED'    
 GROUP BY oi.OrderId
    
	
	declare @OrderId bigint =200265774

 Select SUM(ocri.Quantity) reshipedQuantity,oim.OrderItemId  from orders.OrderChangeRequestItems ocri  WITH (NOLOCK)      
 INNER JOIN  orders.OrderItems oim  on  oim.OrderId =ocri.orderId and ocri.OrderItemId =oim.OrderItemId      
    INNER JOIN [Orders].[OrderChangeRequests] ocrir on ocrir.OrderChangeRequestID =ocri.OrderChangeRequestID       
 WHERE  ocri.OrderId = @OrderId  and oim.Status ='REFUND_PENDING'      
 GROUP BY oim.OrderItemId

 SP_HELPTEXT '[otc].[GetAllOTCOrderItemDetails]'