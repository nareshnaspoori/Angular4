
ALTER TABLE [Orders].[Orders]  DROP CONSTRAINT [OrderStatusCodeCheck] 

ALTER TABLE [Orders].[Orders]  WITH NOCHECK ADD  CONSTRAINT [OrderStatusCodeCheck] 
CHECK -- (([OrderStatusCode]='EMI' OR [OrderStatusCode]='CAN' OR [OrderStatusCode]='RET' OR [OrderStatusCode]='ACK' OR [OrderStatusCode]='SHI' OR [OrderStatusCode]='DOC' OR [OrderStatusCode]='PO' OR [OrderStatusCode]='APP' OR [OrderStatusCode]='PAY' OR [OrderStatusCode]='INI' OR [OrderStatusCode]='CLM' OR [OrderStatusCode]='EXC' OR [OrderStatusCode]='APQ' OR [OrderStatusCode]='REC' OR [OrderStatusCode]='FFC' OR [OrderStatusCode]='EMI' OR [OrderStatusCode]='REF' OR [OrderStatusCode]='REF_P' OR [OrderStatusCode]='RES_P' ))
(([OrderStatusCode]='EMI' OR [OrderStatusCode]='CAN' OR [OrderStatusCode]='RET' OR [OrderStatusCode]='ACK' OR [OrderStatusCode]='SHI' OR [OrderStatusCode]='DOC' OR [OrderStatusCode]='PO' OR [OrderStatusCode]='APP' OR [OrderStatusCode]='PAY' OR [OrderStatusCode]='INI' OR [OrderStatusCode]='CLM' OR [OrderStatusCode]='EXC' OR [OrderStatusCode]='APQ' OR [OrderStatusCode]='REC' OR [OrderStatusCode]='FFC' OR [OrderStatusCode]='EMI' OR [OrderStatusCode]='REF'  OR [OrderStatusCode]='DAP'))

GO

ALTER TABLE [Orders].[Orders] NOCHECK CONSTRAINT [OrderStatusCodeCheck]
GO




-- need confirmation from Veeran 
--OrderStatusCode length modify from 3 to 5
ALTER TABLE [Orders].[Orders] ALTER COLUMN OrderStatusCode NVARCHAR (5) NOT NULL;

