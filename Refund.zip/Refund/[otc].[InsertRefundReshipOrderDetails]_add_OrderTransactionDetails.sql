    
/*    
=============================================    
Author: Naresh Naspoori           
Create Date: 01-MARCH-2021    
Description: OTC Refund insert refund or reship order details.    
=============================================    
exec  [otc].[InsertRefundReshipOrderDetails]    
DECLARE @OrderId bigint =190009011    
DECLARE @RequestData varchar(4000) ='{"Reason":"Other","AdditionalComments":"abc"}'    
DECLARE @NHMemberId nvarchar(100)='OTC201901964101'    
DECLARE @SubmitUserProfileId bigint=11924    
DECLARE @CreateUser nvarchar(100) ='GailFran'    
DECLARE @OrderChangeRequestItems NVARCHAR(max)  = N'[{"OrderId" : 190009011,  "OrderItemId": 78964, "ItemCode": "97958116426", "Quantity": 1,   "ItemData": "25" ,"Comments":"test"  } ]'    
DECLARE @IsRefund bit=0    
 */    
ALTER PROCEDURE [otc].[InsertRefundReshipOrderDetails] (    
 @OrderId BIGINT    
 ,@RequestData VARCHAR(4000)    
 ,@NHMemberId NVARCHAR(100) = NULL    
 ,@SubmitUserProfileId BIGINT    
 ,@CreateUser NVARCHAR(100)    
 ,@OrderChangeRequestItems NVARCHAR(MAX)    
 ,@IsRefund bit=0    
 )    
AS    
BEGIN TRY    
--TESTING ONLY    
  -- SET @SubmitUserProfileId =11924    
-- SET @CreateUser ='GailFran'    
    
 DECLARE @SCOPE_IDENTITY BIGINT    
 DECLARE @status VARCHAR(200) = 'PENDING'    
 DECLARE @orderType VARCHAR(20) ='OTC'    
 DECLARE @changeType VARCHAR(20) = CASE @IsRefund WHEN 1 THEN 'REFUND' WHEN 0 THEN 'RESHIP' END    
 DECLARE @orderStatusCode NVARCHAR(6) = CASE @IsRefund WHEN 1 THEN 'REF_P' WHEN 0 THEN 'RES_P' END  --REF_P  RES_P    
 DECLARE @orderStatus VARCHAR(100) = CASE @IsRefund WHEN 1 THEN 'REFUND_PENDING' WHEN 0 THEN 'RESHIP_PENDING' END    
 DECLARE @orderItemData VARCHAR(100) = CASE @IsRefund WHEN 1 THEN 'Refund applied.' WHEN 0 THEN 'Reship requested.' END    
    
 DECLARE @errorMsg VARCHAR(200)    
 DECLARE @errorSeverity VARCHAR(200)    
 DECLARE @orderPreviousStatus VARCHAR(20) = (    
   SELECT orderStatusCode    
   FROM orders.orders    
   WHERE orderId = @OrderId    
   )    
    
 BEGIN TRANSACTION    
    
 INSERT INTO [Orders].[OrderChangeRequests] (    
  [OrderId]    
  ,[ChangeType]    
  ,[Status]    
  ,[OrderType]    
  ,[PreviousStatus]    
  ,[RequestData]    
  ,[NHMemberId]    
  ,[SubmitUserProfileId]    
  ,[IsActive]    
  ,[CreateDate]    
  ,[SubmitDate]    
  ,[CreateUser]    
  )    
 VALUES (    
  @OrderId    
  ,@changeType    
  ,@status    
  ,@orderType    
  ,@orderPreviousStatus    
  ,@RequestData    
  ,@NHMemberId    
  ,@SubmitUserProfileId    
  ,1    
  ,getdate()    
  ,getdate()    
  ,@CreateUser    
  )    
    
 SET @SCOPE_IDENTITY = SCOPE_IDENTITY()    
    
 INSERT INTO [Orders].[OrderChangeRequestItems] (    
  OrderChangeRequestId    
  ,OrderId    
  ,OrderItemId    
  ,ItemCode    
  ,Quantity    
  ,ItemData    
  ,Comments    
  ,STATUS    
  ,PreviousStatus    
  ,CreateDate    
  ,CreateUser    
  ,IsActive    
  ,ModifyDate    
  ,ModifyUser    
  )    
 SELECT @SCOPE_IDENTITY OrderChangeRequestId    
  ,@OrderId    
  ,*    
  ,@status status    
  ,(    
   SELECT TOP 1 STATUS    
   FROM orders.orderitems    
   WHERE orderItemid = t.OrderItemId    
   ) PreviousStatus    
  ,getdate() CreateDate    
  ,@CreateUser CreateUser    
  ,1 IsActive    
  ,getdate() ModifyDate    
  ,@CreateUser ModifyUser    
 FROM (    
  SELECT *    
  FROM OPENJSON(@OrderChangeRequestItems) WITH (    
    --OrderId bigint '$.OrderId'     
    OrderItemId BIGINT '$.OrderItemId'    
    ,ItemCode NVARCHAR(200) '$.ItemCode'    
    ,Quantity BIGINT '$.Quantity'    
    ,ItemData VARCHAR(4000) '$.ItemData'    
    ,Comments VARCHAR(4000) '$.Comments'    
    )    
  ) t    
    
 --UPDATE orders.orders    
 --SET OrderStatusCode = @orderStatusCode    
 -- ,ModifyDate = getdate()    
 -- ,ModifyUser = @CreateUser    
 --WHERE OrderId = @OrderId    
    
 UPDATE orders.orderitems    
 SET Status = @orderStatus    
  ,ItemData = Json_modify(ItemData, '$.Remarks', @orderItemData)    
  ,ModifyDate = getdate()    
  ,ModifyUser = @CreateUser    
 WHERE OrderId = @OrderId    
  AND orderitemId IN (    
   SELECT orderItemId    
FROM OPENJSON(@OrderChangeRequestItems) WITH (    
     OrderItemId BIGINT '$.OrderItemId'    
     ,ItemCode NVARCHAR(200) '$.ItemCode'    
     ,Quantity BIT '$.Quantity'    
     ,ItemData VARCHAR(4000) '$.ItemData'    
     )    
   )    
    
 COMMIT;    
END TRY    
    
BEGIN CATCH    
 DECLARE @ErrorMessage NVARCHAR(4000);    
 DECLARE @Severity INT;    
 DECLARE @ErrorState INT;    
    
 SELECT @ErrorMessage = ERROR_MESSAGE()    
  ,@Severity = ERROR_SEVERITY()    
  ,@ErrorState = ERROR_STATE()    
    
 RAISERROR (    
   @ErrorMessage    
   ,@Severity    
   ,@ErrorState    
   )    
    
 PRINT (@ErrorMessage)    
 PRINT (@Severity)    
 PRINT (@ErrorState)    
    
 ROLLBACK    
END CATCH    
  
  