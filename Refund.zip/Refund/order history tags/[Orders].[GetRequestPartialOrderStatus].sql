SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
         
           
/* =============================================            
  Author: Naresh Naspoori                   
  Updated Date: 25-MARCH-2021            
  Description: OTC  orders is isPartialOrder or not .            
  =============================================            
   exec [Orders].[GetRequestPartialOrderStatus] 'NH202106672045'          
*/          
CREATE PROC [Orders].[GetRequestPartialOrderStatus] @NHMemberId NVARCHAR(max)              
AS              
BEGIN     
 ;with cte as (    
 select DISTINCT oo.OrderID    
  ,SUM(oi.Quantity) AS TotalQuantity    
  ,ocri.ReqQuantity    
FROM Orders.Orders oo WITH (NOLOCK)      
INNER JOIN Orders.OrderItems oi  WITH (NOLOCK) ON oi.OrderId = oo.OrderID AND oi.IsActive = 1        
LEFT JOIN    
   (SELECT ocri.OrderId     
     ,SUM(ocri.Quantity) AS ReqQuantity    
   FROM Orders.OrderChangeRequestItems ocri  WITH (NOLOCK)     
   INNER JOIN Orders.OrderChangeRequests  D ON D.OrderChangeRequestID = ocri.OrderChangeRequestId   AND changeType= 'REFUND'      
   GROUP BY ocri.OrderID)ocri ON ocri.OrderId = oo.OrderID --AND oi.orderitemid = ocri.orderitemid      
WHERE oo.NHMemberId = @NHMemberId         
   AND oo.IsActive = 1        
   --AND oo.OrderID=200266202    
  GROUP BY oo.OrderID    
  ,ocri.ReqQuantity )    
    
SELECT  CAST((CASE WHEN TotalQuantity <= ISNULL(ReqQuantity, 0)   THEN 1 ELSE 0 END) AS BIT) AS isFullRequest              
  ,orderId       
  --, CASE WHEN TotalQuantity <= ISNULL(ReqQuantity, 0)   THEN 1 ELSE 0 END AS isFullOrder        
FROM CTE             
END 

