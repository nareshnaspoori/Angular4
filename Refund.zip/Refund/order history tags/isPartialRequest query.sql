
SELECT TOP 10 *  FROM ORDERS.ORDERITEMS oi   WHERE OrderId = 200084345 and OrderItemId =1886301
 inner JOIN Orders.OrderRequestItems ori ON ori.orderId = oi.orderId
 and ori.OrderChangeRequestId =

 
 SELECT  *  FROM  Orders.OrderChangeRequestItems  WHERE OrderId = 200084345 order by 1 desc
  SELECT TOP 10 *  FROM  Orders.OrderChangeRequestItems  WHERE  OrderItemId =190009011 
 CASE 1
 WHEN 
 SELECT  * from orders.OrderItems ordItem 
 --inner join orders.Orders oo ON oo.OrderID = ordItem.OrderId
 where ordItem.Quantity <= (select SUM(Quantity) from orders.OrderChangeRequestItems WHERE OrderItemId =ordItem.OrderItemId AND OrderId = 200238447)
 left join orders.OrderChangeRequestItems ocri on ocri.OrderItemId = ordItem.OrderItemId and ocri.Quantity = ordItem.Quantity


 SELECT *FROM orders.OrderChangeRequestItems where OrderItemId =1886301 and OrderId = 200264033
 Select TOP 1 SUM(Quantity) as quanitity,orderItemId as  totalQuanity from orders.OrderChangeRequestItems 
 where  OrderId = 200238447 
 group by OrderItemId 


 
SELECT TOP 10 *  FROM ORDERS.ORDERITEMS oi   WHERE OrderId = 200238447 and orderItemId =1795451
 SELECT  *  FROM  Orders.OrderChangeRequestItems  WHERE OrderId = 200238447 and orderItemId =1795451
 DELETE FROM  Orders.OrderChangeRequestItems WHERE OrderId = 200238447 and orderItemId =1795451
 	DELETE FROM  [Orders].[OrderChangeRequests] where  OrderId = 200238447 and orderItemId =1795451

 DECLARE @changesQuantity bigint 
 SET @changesQuantity = (Select SUM(Quantity) totalQuanity from orders.OrderChangeRequestItems 
 WHERE  OrderId = 200238447 and orderItemId =1795451
GROUP BY OrderItemId 
 )
-- PRINT @changesQuantity
 DECLARE @itemQuantity bigint = (SELECT  COUNT(quantity) FROM orders.orderitems 
 WHERE OrderId = 200238447 and orderItemId =1795451 )
 
  SELECT 
  CASE WHEN 
   @changesQuantity =@itemQuantity
   THEN  1
   WHEN 
	@changesQuantity <>@itemQuantity
	THEN
	0 
	END AS isPartialRequest



 

 SELECT TOP 10 *FROM ORDERS.orders  WHERE OrderId = 200084345 order by 1 desc 
 SELECT TOP 10 *  FROM ORDERS.ORDERITEMS oi   WHERE OrderId = 200264171 order by 1 desc

 declare @orderid bigint =200238447

 Select SUM(ocri.Quantity) totalQuanity,ocri.orderItemId from orders.OrderChangeRequestItems ocri
 JOIN Orders.OrderItems oi ON oi.orderItemId =ocri.orderItemId
 WHERE  ocri.OrderId = 200264171--   and  ocri.orderItemId =200264171
GROUP BY ocri.OrderItemId 


SELECT TOP 10 *  FROM ORDERS.ORDERITEMS oi   WHERE OrderId = 200084345 and orderItemId =1795452
 SELECT  *  FROM  Orders.OrderChangeRequestItems  WHERE OrderId = 200238447 and orderItemId =1795456
  SELECT TOP 10 *FROM  Orders.OrderChangeRequestItems order by 1 desc
   SELECT TOP 10 *  FROM ORDERS.ORDERITEMS order by 1 desc



 (SELECT  oim.ItemName, oci.Quantity as itemDetails  from Orders.OrderChangeRequestItems oci as for json path) as item 
LEFT JOIN [otccatalog].[itemmaster] oim WITH (NOLOCK) --Modified Inner Join to Left Join      
    ON oci.ItemCode = oim.ItemCode AND oi.IsActive=1  


	select top 10 JSON_VALUE(ItemData,'$.unitPrice') as UnitPrice  from  Orders.OrderChangeRequestItems   order by 1 desc
	select * from  Orders.OrderChangeRequestItems oci order by 1 desc
		SELECT TOP 10    *FROM ORDERS.ORDERITEMS oi  order by 1 desc
	SELECT TOP 1    *FROM ORDERS.ORDERITEMS oi where orderItemId =200264170  order by 1 desc
	SELECT TOP 1 ISNULL(JSON_VALUE(oi.ItemData, '$.catalogName'), '') AS [CatalogName],oi.orderItemId FROM ORDERS.ORDERITEMS oi where oi.orderItemId =1886676  order by 1 desc
	SELECT TOP 1 JSON_VALUE(oi.ItemData, '$.catalogName') AS [CatalogName],oi.orderItemId FROM ORDERS.ORDERITEMS oi where oi.orderItemId =1886676  order by 1 desc
	
	(oci.Quantity * CAST(JSON_VALUE(oci.ItemData,'strict$.unitPrice') As bigint))AS TotalPrice

	delete from Orders.OrderChangeRequestItems where ItemData = ''