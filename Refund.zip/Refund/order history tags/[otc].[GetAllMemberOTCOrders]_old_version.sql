/****** Object:  StoredProcedure [otc].[GetAllMemberOTCOrders]    Script Date: 08-03-2021 19:22:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

  
    
--exec otc.GetAllMemberOTCOrders 'NH202002837997'    
    
CREATE  PROC [otc].[GetAllMemberOTCOrders]      
 @NHMemberId nvarchar(max)      
AS BEGIN      
 SET NOCOUNT ON;      
      
 SELECT  DISTINCT      
 oo.OrderID AS 'OrderID',      
 oo.CreateDate AS 'OrderDate',      
 JSON_VALUE(oo.OrderAmountData, '$.price') AS 'TotalPrice',       
 json_query(oo.OrderAmountData, '$.benefitTransactions') AS 'benefitTransactions',      
 CAST(JSON_VALUE(oo.OrderAmountData, '$.outOfPocket') AS decimal(7,2)) AS 'MemberResponsibility',      
 CASE       
   WHEN oo.OrderStatusCode IN ('INI')      
   THEN CAST(1 AS bit)      
   ELSE CAST(0 AS bit) END      
 AS 'IsEditable'      
 ,CASE       
   WHEN oo.OrderStatusCode IN ('INI', 'ACK','EMI')       
   THEN 'ACTIVE'       
   ELSE 'PAST'       
  END       
 AS 'OrderStatusCategory',      
 OO.OrderStatusCode AS 'OrderStatusCode',    
 oo.Source,    
 (    
  SELECT distinct oi.ItemCode AS 'ItemCode'    
  ,CONCAT('/',ia.ModelAttributeValue,'/',ia.ModelAttributeValue,'_Front.jpg')  AS 'ItemMedialUrl'    
  ,ia.ModelAttributeValue AS 'ItemAttributeValue'    
    
  FROM Orders.OrderItems oi    
  INNER JOIN  [catalog].[ItemMasterAttributeValues] ia WITH (NOLOCK) ON oi.ItemCode = ia.ItemCode      
  WHERE orderid=oo.OrderID and ia.AttributeCode='NATIONS_ID' FOR JSON PATH    
 ) AS ItemDetails      
 FROM orders.Orders  oo WITH (NOLOCK)       
 LEFT JOIN [Orders].[OrderItems] oi ON oo.OrderID = oi.OrderID      
 WHERE oo.NHMemberId = @NHMemberId  AND oo.OrderType =  'OTC'  and oo.IsActive = 1 order by oo.OrderId desc     
END 
GO


