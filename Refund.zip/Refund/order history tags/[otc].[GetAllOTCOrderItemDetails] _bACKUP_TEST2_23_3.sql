/* =============================================  
  Author: Naresh Naspoori         
  Updated Date: 05-MARCH-2021  
  Description: OTC get  all orders  itemd details , refundended and reshipped quantity .  
  =============================================  
  exec  [otc].[GetAllOTCOrderItemDetails]  200264183    
*/  
    
CREATE PROC [otc].[GetAllOTCOrderItemDetails] @OrderId BIGINT    
AS      
BEGIN    
SELECT DISTINCT oi.OrderId            
  ,oo.CreateDate AS 'OrderCreateDate'            
  ,(            
   SELECT DISTINCT oi.ItemCode AS 'ItemCode'            
    ,oim.ItemName            
    ,oi.Quantity            
    ,oi.STATUS ItemStatus            
    ,cast(oi.UnitPrice AS DECIMAL(18, 2)) 'UnitPrice'            
    ,CONCAT (            
     '/'            
     ,oim.NationsId            
     ,'/'            
     ,oim.NationsId            
     ,'_Front.jpg'            
     ) AS 'ItemMedialUrl'            
    ,oim.NationsId AS 'ItemAttributeValue' -- NationsID source changed from ItemMasterAttributeValue to otccatalog.ItemMaster                    
    ,ISNULL(JSON_VALUE(oi.ItemData, '$.catalogName'), '') AS [CatalogName]            
 ,oi.OrderItemId          
 ,(SELECT TOP 1  orc.status FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId and orc.OrderItemId = oi.OrderItemId ORDER BY  orc.OrderChangeRequestItemId desc) as ChangeRequestItemStatus          
 ,(SELECT TOP 1  orc.Comments  FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId and orc.OrderItemId = oi.OrderItemId ORDER BY  orc.OrderChangeRequestItemId desc) as ChangeRequestItemComment         
 ,(SELECT TOP 1  orc.Quantity  FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId and orc.OrderItemId = oi.OrderItemId ORDER BY  orc.OrderChangeRequestItemId desc) as ChangeRequestItemQuantity        
 ,(SELECT TOP 1  ocr.changeType from [Orders].[OrderChangeRequests] ocr WITH (NOLOCK) LEFT JOIN  [Orders].[OrderChangeRequestItems] ocri ON ocri.orderid = ocr.orderId AND ocri.OrderChangeRequestID = ocr.OrderChangeRequestID   WHERE  ocr.orderid = @OrderId
 AND ocri.OrderItemid =oi.orderItemId  ORDER BY ocri.OrderChangeRequestID  desc) as ChangeType 
 
 ,(Select SUM(ocri.Quantity) totalQuanity from orders.OrderChangeRequestItems ocri WITH (NOLOCK)      
 WHERE  ocri.OrderId = @OrderId AND  ocri.orderItemId = oi.orderItemId AND ocri.Status!='REJECTED'  
 GROUP BY ocri.Quantity )as ChangeRequestedQuantity      
    
,(Select SUM(ocri.Quantity) refundedQuantity  from orders.OrderChangeRequestItems ocri -- WITH (NOLOCK)    
 INNER JOIN  orders.OrderItems oim  on  oim.OrderId =ocri.orderId and ocri.OrderItemId =oim.OrderItemId    
    INNER JOIN [Orders].[OrderChangeRequests] ocrir on ocrir.OrderChangeRequestID =ocri.OrderChangeRequestID     
 WHERE  ocri.OrderId = @OrderId  and  ocri.OrderItemId =  oi.OrderItemId  and oi.Status ='REFUND_PENDING'    
 GROUP BY ocri.Quantity, oim.OrderItemId)  AS RefundedQuantity    
    
,(Select SUM(ocri.Quantity) reshipedQuantity  from orders.OrderChangeRequestItems ocri -- WITH (NOLOCK)    
 INNER JOIN  orders.OrderItems oim  on  oim.OrderId =ocri.orderId and ocri.OrderItemId =oim.OrderItemId    
    INNER JOIN [Orders].[OrderChangeRequests] ocrir on ocrir.OrderChangeRequestID =ocri.OrderChangeRequestID     
 WHERE  ocri.OrderId = @OrderId  and  ocri.OrderItemId =  oi.OrderItemId  and oi.Status ='RESHIP_PENDING'    
 GROUP BY ocri.Quantity, oim.OrderItemId)  AS ReshipedQuantity    
    
 FROM orders.orderItems oi WITH (NOLOCK)            
   LEFT JOIN [otccatalog].[itemmaster] oim WITH (NOLOCK) --Modified Inner Join to Left Join            
    ON oi.ItemCode = oim.ItemCode AND oi.IsActive=1            
   LEFT JOIN cms.ItemmasterContent ic WITH (NOLOCK) ON oi.ItemCode = ic.ItemCode AND ic.IsActive=1            
   LEFT JOIN [catalog].[ItemMasterAttributeValues] ia WITH (NOLOCK) ON oi.ItemCode = ia.ItemCode  AND ia.IsActive=1            
   WHERE oi.OrderId = @OrderId             
   --AND ia.AttributeCode='NATIONS_ID'                     
   FOR JSON PATH            
   ) ItemDetails            
  ,oo.OrderAmountData 'benefitTransactions'            
  ,oo.MemberData            
  ,oo.ShippingData            
  ,tr.OrderTransactionData            
  ,JSON_VALUE(tr.OrderTransactionData, '$.transactions[0].paymentType') 'Payment_Mode'            
  ,(            
   SELECT isnull((OrderTransactionData), 0)            
   FROM Orders.OrderTransactionDetails            
   WHERE OrderId = @OrderId            
    AND OrderStatusCode = 'SHI' AND IsActive=1            
   ) AS 'TrackingNumber'            
  ,CAST(CASE             
    WHEN oo.STATUS = 'CANCELLED'            
     THEN 1            
    ELSE 0            
    END AS BIT) AS [IsCancelled]            
  ,CAST(ISNULL((            
     SELECT TOP 1 IsComplete            
     FROM Orders.OrderTransactionDetails otd            
     WHERE otd.OrderID = oi.OrderId            
      AND otd.OrderStatusCode = 'REF' AND otd.IsActive=1            
     ), 0) AS BIT) AS [IsComplete]            
  ,CAST(CASE             
    WHEN oo.OrderStatusCode = 'INI'            
     THEN 1            
    ELSE 0            
    END AS BIT) AS [IsEditable]            
  ,oo.OrderStatusCode AS OrderStatusCode            
 ,(SELECT TOP 1  orc.changeType from [Orders].[OrderChangeRequests] orc where orc.orderid =oo.orderid ORDER BY orc.OrderChangeRequestID  desc) as ChangeType        
 ,(SELECT TOP 1  orc.status from [Orders].[OrderChangeRequests] orc where orc.orderid =oo.orderid ORDER BY orc.OrderChangeRequestID  desc) as OrderChangeRequestStatus       
 ,(SELECT TOP 1 concat('[', string_agg(JSON_QUERY(orc.RequestData, '$.paymentDetails'),','),']') from [Orders].[OrderChangeRequests] orc where orc.orderid =oo.orderid) as RequestData    
  ,oo.RefOrderId as 'RefOrderId'    
 FROM orders.orderItems oi WITH (NOLOCK)            
 LEFT JOIN [otccatalog].[itemmaster] oim WITH (NOLOCK) ON oi.ItemCode = oim.ItemCode AND oim.IsActive=1 AND oi.IsActive=1            
 INNER JOIN orders.orders oo WITH (NOLOCK) ON oi.OrderId = oo.OrderId  AND oo.IsActive=1            
 LEFT JOIN Orders.OrderTransactionDetails tr WITH (NOLOCK) ON tr.OrderID = oo.OrderID AND tr.IsActive=1            
  AND tr.OrderStatusCode = 'PAY'              
  AND oo.OrderType = 'OTC'            
 WHERE oi.OrderId = @OrderId    
END    