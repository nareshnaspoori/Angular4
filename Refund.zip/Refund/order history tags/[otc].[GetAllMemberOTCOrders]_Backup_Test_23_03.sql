    
      
--exec otc.GetAllMemberOTCOrders 'NH202106672136'        
CREATE  PROC [otc].[GetAllMemberOTCOrders]        
 @NHMemberId nvarchar(max)        
AS BEGIN            
 SET NOCOUNT ON;            
            
 SELECT  DISTINCT            
 oo.OrderID AS 'OrderID',            
 oo.CreateDate AS 'OrderDate',            
 JSON_VALUE(oo.OrderAmountData, '$.price') AS 'TotalPrice',             
 json_query(oo.OrderAmountData, '$.benefitTransactions') AS 'benefitTransactions',            
 CAST(JSON_VALUE(oo.OrderAmountData, '$.price') AS decimal) - CAST(JSON_VALUE(oo.OrderAmountData, '$.amountCovered') AS decimal) AS 'MemberResponsibility',            
 CASE             
   WHEN oo.OrderStatusCode IN ('INI')            
   THEN CAST(1 AS bit)            
   ELSE CAST(0 AS bit) END            
 AS 'IsEditable'            
 ,CASE             
   WHEN oo.OrderStatusCode IN ('INI', 'ACK','EMI','RES_P','REF_P')             
   THEN 'ACTIVE'             
   ELSE 'PAST'             
  END             
 AS 'OrderStatusCategory',            
 oo.OrderStatusCode AS 'OrderStatusCode',          
 oo.Source,          
 (          
  SELECT distinct oi.ItemCode AS 'ItemCode'          
  ,CONCAT('/',ia.ModelAttributeValue,'/',ia.ModelAttributeValue,'_Front.jpg')  AS 'ItemMedialUrl'          
  ,ia.ModelAttributeValue AS 'ItemAttributeValue'          
          
  FROM Orders.OrderItems oi          
  INNER JOIN  [catalog].[ItemMasterAttributeValues] ia WITH (NOLOCK) ON oi.ItemCode = ia.ItemCode            
  WHERE orderid=oo.OrderID and ia.AttributeCode='NATIONS_ID' FOR JSON PATH          
 ) AS ItemDetails         
 ,oo.Status as OrderStatus        
 ,(SELECT TOP 1  orc.changeType from [Orders].[OrderChangeRequests] orc where orc.orderid =oo.orderid ORDER BY orc.OrderChangeRequestID  desc) as ChangeType        
 ,(SELECT TOP 1  orc.status from [Orders].[OrderChangeRequests] orc where orc.orderid =oo.orderid ORDER BY orc.OrderChangeRequestID  desc) as OrderChangeRequestStatus        
--(SELECT top 1  orc.orderChangeRequestId from [Orders].[OrderChangeRequests] orc where orc.orderid =oo.orderid ORDER BY orc.CreateDate  desc) as orderChangeRequestId      
--,(SELECT TOP 1 concat('[', string_agg(JSON_QUERY(orc.RequestData, '$.paymentDetails'),','),']') from [Orders].[OrderChangeRequests] orc where orc.orderid =oo.orderid) as RequestData   
 ,(SELECT TOP 1  orc.RequestData from [Orders].[OrderChangeRequests] orc where orc.orderid =oo.orderid ORDER BY orc.OrderChangeRequestID  desc) as RequestData  
 , CAST(1 AS BIT) as isFullRequest       
  ,oo.RefOrderId as 'RefOrderId'    
 FROM orders.Orders  oo WITH (NOLOCK)             
 LEFT JOIN [Orders].[OrderItems] oi ON oo.OrderID = oi.OrderID            
 WHERE oo.NHMemberId = @NHMemberId  AND oo.OrderType =  'OTC'  and oo.IsActive = 1 order by oo.OrderId desc           
END 