/****** Object:  StoredProcedure [otc].[InsertVocherOrderDetails]    Script Date: 08-03-2021 19:22:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO
      
/* =============================================          
  Author: Naresh Naspoori                 
  Updated Date: 12-APRIL-2021          
  Description: OTC insert (NATIONS) refunds voucher order and order item details.          
  =============================================          
   exec [otc].[InsertVocherOrderDetails] 200265740,'systemUser'         
*/  

CREATE PROC [otc].[InsertVocherOrderDetails] @orderId BIGINT        
 ,@createUser NVARCHAR(100) = NULL        
AS        
BEGIN        
 BEGIN TRY        
 
  DECLARE @price BIGINT
  DECLARE @amountCovered BIGINT
  DECLARE @outOfPocket BIGINT 
  DECLARE @benefitTransactionDetails NVARCHAR(4000)
  DECLARE @existingOrderAmountData NVARCHAR(4000) 
  
  DROP TABLE IF EXISTS #benefitTransaction
  DROP TABLE IF EXISTS #benefitTransDetails

  DECLARE @benefitTransaction NVARCHAR(4000) =(SELECT TOP 1 JSON_QUERY (OrderAmountData, '$.benefitTransactions') FROM ORDERS.ORDERS WHERE orderid=@orderid and isActive=1 )
  
  SELECT * INTO #benefitTransaction FROM OPENJSON(@benefitTransaction)  
  SELECT *INTO #benefitTransDetails FROM #benefitTransaction  WHERE JSON_VALUE(value,'$.source')='NATIONS'

   BEGIN TRAN 

		UPDATE #benefitTransDetails SET value =	JSON_MODIFY(value,'$.outOfPocket','0.0')
		SELECT @benefitTransactionDetails= '['+STRING_AGG(value,',')+']' FROM #benefitTransDetails
	
		SET @price =  (SELECT 0-SUM(cast(JSON_VALUE(value,'$.amountCovered')AS DECIMAL))  AS price FROM #benefitTransDetails )
		SET @existingOrderAmountData = (SELECT orderAmountData FROM orders.Orders WHERE orderId =@orderId)
		SET @existingOrderAmountData  = JSON_MODIFY(@existingOrderAmountData,'$.price',@price)
		SET @existingOrderAmountData  = JSON_MODIFY(@existingOrderAmountData,'$.amountCovered',@price)
		SET @existingOrderAmountData  = JSON_MODIFY(@existingOrderAmountData,'$.outOfPocket',0.0)
		SET @existingOrderAmountData  = REPLACE(JSON_MODIFY(@existingOrderAmountData,'$.benefitTransactions',JSON_QUERY(@benefitTransactionDetails)),'\','')

	 IF (SELECT count(*) FROM #benefitTransDetails)>0
		   BEGIN
		INSERT INTO orders.Orders (memberChartDataId
		  ,OrderType ,MemberData,OrderAmountData,ShippingData,ProviderData ,Status,Source  ,Amount ,NHMemberid ,RefOrderId  ,DateOrderReceived ,DateOrderInitiated
		  ,SpecialInstructions, EarmoldInstructions, CreateUser, CreateDate, ModifyUser, ModifyDate, IsActive,OrderStatusCode,  IPAddress, BenefitsData
		 )
		  SELECT   memberChartDataId ,OrderType ,MemberData ,@existingOrderAmountData ,ShippingData ,ProviderData ,Status,Source ,Amount,NHMemberid ,@orderId ,DateOrderReceived,DateOrderInitiated,SpecialInstructions,
		  EarmoldInstructions, CreateUser,  GETDATE(), ModifyUser,  GETDATE(),
		  IsActive,
		  'SHI',
		  IPAddress,
		  BenefitsData
		  FROM orders.orders WHERE orderid  =@orderId
		  DECLARE @IDDEN BIGINT = SCOPE_IDENTITY()

		INSERT INTO Orders.OrderItems
		(
		orderId,ItemCode,Quantity,Amount,status,unitPrice,PairPrice,
		ItemData,ItemType,createUser,modifyUser,createDate,ModifyDate,isActive
		)
		VALUES(
		   @IDDEN,'NB_VOUCHER',1,@price,'ACTIVE',@price,2*@price,'','OTC',@createUser,@createUser,GETDATE(),GETDATE(),1
		      )
	END
  
  COMMIT
 END TRY      
 BEGIN CATCH        
	  DECLARE @ErrorMessage NVARCHAR(4000);        
	  DECLARE @Severity INT;        
	  DECLARE @ErrorState INT;        
        
	  SELECT @ErrorMessage = ERROR_MESSAGE()        
	   ,@Severity = ERROR_SEVERITY()        
	   ,@ErrorState = ERROR_STATE()        
        
	  RAISERROR (        
		@ErrorMessage        
		,@Severity        
		,@ErrorState        
		)        
        
	  PRINT (@ErrorMessage)        
	  PRINT (@Severity)        
	  PRINT (@ErrorState)        
        
      ROLLBACK        
 END CATCH    
 END
