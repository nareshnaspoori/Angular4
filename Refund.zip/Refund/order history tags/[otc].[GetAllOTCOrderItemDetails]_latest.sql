/****** Object:  StoredProcedure [otc].[GetAllOTCOrderItemDetails]    Script Date: 18-03-2021 14:40:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/* =============================================                          
  Author:                                 
  Updated Date: 05-MARCH-2021                          
  Description: OTC get  all orders  itemd details , refundended and reshipped quantity .                          
                        
  update History:                        
  Author: Naresh Naspoori                        
  Description: updated for refund and reship                          
  =============================================                          
  exec  [otc].[GetAllOTCOrderItemDetails_SHIVA] 200269798                         
*/                          
ALTER PROC [otc].[GetAllOTCOrderItemDetails_SHIVA] @OrderId BIGINT                            
AS                              
BEGIN                     
 DECLARE @nhMemberId NVARCHAR(40) =(SELECT nhmemberId FROM Orders.Orders WHERE orderId =@OrderId)              
    DECLARE @isFullRequest BIT               
              
 DROP TABLE IF EXISTS #PartialTempTbl                      
 CREATE TABLE #PartialTempTbl                       
  (                      
   isFullRequest BIT,                       
   orderId  BIGINT                      
  )               
                
 INSERT INTO  #PartialTempTbl                       
 EXEC [Orders].[GetRequestPartialOrderStatus]  @nhMemberId               
 SET  @isFullRequest =(SELECT isFullRequest FROM #PartialTempTbl WHERE orderId =@OrderId)               
              
SELECT DISTINCT oi.OrderId                                    
  ,oo.CreateDate AS 'OrderCreateDate'                                    
  ,(                                    
   SELECT DISTINCT oi.ItemCode AS 'ItemCode'                                    
    ,oim.ItemName                                    
    ,oi.Quantity                                    
    ,oi.STATUS ItemStatus                                    
    ,cast(oi.UnitPrice AS DECIMAL(18, 2)) 'UnitPrice'                                    
    ,CONCAT (                                    
     '/'                                    
     ,oim.NationsId                                    
     ,'/'                                    
     ,oim.NationsId                                    
     ,'_Front.jpg'                                    
     ) AS 'ItemMedialUrl'                                    
    ,oim.NationsId AS 'ItemAttributeValue' -- NationsID source changed from ItemMasterAttributeValue to otccatalog.ItemMaster                                            
    ,ISNULL(JSON_VALUE(oi.ItemData, '$.catalogName'), '') AS [CatalogName]                                    
 ,oi.OrderItemId                                  
 ,(SELECT TOP 1  orc.status FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId AND orc.OrderItemId = oi.OrderItemId AND IsActive=1 ORDER BY  orc.OrderChangeRequestItemId DESC) AS ChangeRequestItemStatus                 
  
    
                 
 ,(SELECT TOP 1  orc.Comments  FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId AND orc.OrderItemId = oi.OrderItemId AND IsActive=1 ORDER BY  orc.OrderChangeRequestItemId DESC) AS ChangeRequestItemComment             
  
    
                    
 ,(SELECT TOP 1  orc.Quantity  FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId AND orc.OrderItemId = oi.OrderItemId AND IsActive=1 ORDER BY  orc.OrderChangeRequestItemId DESC) AS ChangeRequestItemQuantity            
  
    
                    
 ,(SELECT TOP 1  ocr.changeType FROM [Orders].[OrderChangeRequests] ocr WITH (NOLOCK) LEFT JOIN  [Orders].[OrderChangeRequestItems]  ocri  WITH (NOLOCK) ON ocri.orderid = ocr.orderId AND ocri.OrderChangeRequestID = ocr.OrderChangeRequestID                
  
    
      
  WHERE  ocr.orderid = @OrderId  AND ocri.OrderItemid =oi.orderItemId AND ocr.IsActive=1  ORDER BY ocri.OrderChangeRequestID  DESC) AS ChangeType                            
  ,(SELECT TOP 1 OrderChangeRequestId FROM [Orders].[OrderChangeRequestItems] WITH (NOLOCK) WHERE orderid = @OrderId and OrderItemId = oi.OrderItemId  AND IsActive=1 ORDER BY OrderChangeRequestItemId desc) as OrderChangeRequestId                          
                          
 ,(CAST((ISNULL(JSON_VALUE(oi.ItemData,'$.refApprovedCount'),0 )) AS INT)                  
 -- CAST((ISNULL(JSON_VALUE(oi.ItemData,'$.refRejectedCount'),0))AS INT)                  
 )AS ChangeRequestedQuantity                 
 ,cast(ISNULL(JSON_VALUE(oi.ItemData, '$.isGAFoodIssueReported'), 0) as bit) AS isGAFoodIssueReported                            
 FROM orders.orderItems oi WITH (NOLOCK)                                    
   LEFT JOIN [otccatalog].[itemmaster] oim WITH (NOLOCK) --Modified Inner Join to Left Join                                    
    ON oi.ItemCode = oim.ItemCode AND oi.IsActive=1                                    
   LEFT JOIN cms.ItemmasterContent ic WITH (NOLOCK) ON oi.ItemCode = ic.ItemCode AND ic.IsActive=1 LEFT JOIN [catalog].[ItemMasterAttributeValues] ia WITH (NOLOCK) ON oi.ItemCode = ia.ItemCode  AND ia.IsActive=1                                    
   WHERE oi.OrderId = @OrderId        
   AND oi.ItemCode <> 'NB_VOUCHER_REFUND'      
   --AND ia.AttributeCode='NATIONS_ID'                                             
   FOR JSON PATH                                    
   ) ItemDetails                                    
  ,oo.OrderAmountData 'benefitTransactions'                                    
  ,oo.MemberData                                    
  ,oo.ShippingData                                    
  ,tr.OrderTransactionData                                    
  ,JSON_VALUE(tr.OrderTransactionData, '$.transactions[0].paymentType') 'Payment_Mode'                                    
  ,(                                    
   SELECT isnull((OrderTransactionData), 0)                                    
   FROM Orders.OrderTransactionDetails WITH (NOLOCK)                                   
   WHERE OrderId = @OrderId                                    
    AND OrderStatusCode = 'SHI' AND IsActive=1                                    
   ) AS 'TrackingNumber'                                    
  ,CAST(CASE                                     
    WHEN oo.STATUS = 'CANCELLED'                                    
     THEN 1                                    
    ELSE 0                                    
    END AS BIT) AS [IsCancelled]                                    
  ,CAST(ISNULL((                                    
     SELECT TOP 1 IsComplete                                    
     FROM Orders.OrderTransactionDetails otd WITH (NOLOCK)                                    
     WHERE otd.OrderID = oi.OrderId                                    
      AND otd.OrderStatusCode = 'REF' AND otd.IsActive=1                                    
     ), 0) AS BIT) AS [IsComplete]                                    
  ,CAST(CASE                                     
    WHEN oo.OrderStatusCode = 'INI'                                    
     THEN 1                                    
    ELSE 0                                    
    END AS BIT) AS [IsEditable]                                    
  ,oo.OrderStatusCode AS OrderStatusCode                                    
 ,(SELECT TOP 1  orc.changeType FROM [Orders].[OrderChangeRequests] orc WITH (NOLOCK) WHERE orc.orderid =oo.orderid AND IsActive=1 ORDER BY orc.OrderChangeRequestID  DESC) AS ChangeType                                
 ,(SELECT TOP 1  orc.status FROM [Orders].[OrderChangeRequests] orc WITH (NOLOCK) WHERE orc.orderid =oo.orderid AND IsActive=1 ORDER BY orc.OrderChangeRequestID  DESC) AS OrderChangeRequestStatus                               
    ,(SELECT TOP 1 JSON_QUERY(RequestData, '$.paymentDetails')                  
  FROM [Orders].[OrderChangeRequests] where orderid =oo.orderid AND IsActive = 1 AND Status != 'REJECTED' AND ChangeType = 'REFUND'  ORDER BY OrderChangeRequestID  DESC) AS RequestData                                             
 -- ,(SELECT TOP 1 CONCAT('[', string_agg(JSON_QUERY(RequestData, '$.paymentDetails'),','),']')              
 --FROM [Orders].[OrderChangeRequests] where orderid =oo.orderid AND IsActive = 1 AND Status != 'REJECTED' AND ChangeType = 'REFUND') AS RequestData             
  ,oo.RefOrderId AS 'RefOrderId'               
  ,CAST((ISNULL(@isFullRequest,0))AS BIT)  AS isFullRequest             
  ,[otc].[getIsRefAllowed](oo.OrderID) AS isRefAllowed              
  ,oo.source              
  ,CASE WHEN oo.OrderStatusCode IN ('INI','ACK','EMI') THEN 'ACTIVE'  WHEN (SELECT COUNT(*) FROM Orders.OrderChangeRequests WHERE OrderId=oo.orderId and IsActive=1 and Status= 'Pending') >            
 0 THEN 'ACTIVE' ELSE 'PAST' END AS 'OrderStatusCategory'                
 ,(SELECT TOP 1 orc.OrderChangeRequestId FROM [Orders].[OrderChangeRequests] orc WITH (NOLOCK) WHERE  orc.orderid =oo.orderid AND IsActive=1 ORDER BY  orc.OrderChangeRequestID DESC) as OrderChangeRequestId            
 ,cast(ISNULL(JSON_VALUE(oi.ItemData, '$.isMealKit'), 0) as bit) AS isMealKit     
 FROM orders.orderItems oi WITH (NOLOCK)                                    
 LEFT JOIN [otccatalog].[itemmaster] oim WITH (NOLOCK) ON oi.ItemCode = oim.ItemCode AND oim.IsActive=1 AND oi.IsActive=1                                    
 INNER JOIN orders.orders oo WITH (NOLOCK) ON oi.OrderId = oo.OrderId  AND oo.IsActive=1                                    
 LEFT JOIN Orders.OrderTransactionDetails tr WITH (NOLOCK) ON tr.OrderID = oo.OrderID AND tr.IsActive=1                   
 AND tr.OrderStatusCode = 'PAY'                                      
 AND oo.OrderType = 'OTC'                                    
 WHERE oi.OrderId = @OrderId        
 AND oi.ItemCode <> 'NB_VOUCHER_REFUND'      
END 