/****** Object:  StoredProcedure [otc].[GetAllMemberOTCOrders]    Script Date: 08-03-2021 19:22:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

  
      
/* =============================================          
                 
  Updated Date: 05-MARCH-2021          
  Description: OTC get all member orders details.       
        
 Update History:      
      
 Author: Naresh Naspoori        
 [Orders].[GetRequestPartialOrderStatus] ,orc table  updated for refund and reship      
  =============================================          
   exec sp_helptext  otc.GetAllMemberOTCOrders 'NH202106672212'          
*/        
CREATE PROC [otc].[GetAllMemberOTCOrders] @NHMemberId NVARCHAR(max)        
AS        
BEGIN        
   SET NOCOUNT ON;       
       
 DROP TABLE IF EXISTS #PartialTempTbl      
 CREATE TABLE #PartialTempTbl       
 (      
  isFullRequest bit,       
  orderId  bigint      
 )      
 INSERT INTO  #PartialTempTbl       
 EXEC [Orders].[GetRequestPartialOrderStatus] @NHMemberId      
      
  SELECT DISTINCT oo.OrderID AS 'OrderID'        
  ,oo.CreateDate AS 'OrderDate'        
  ,JSON_VALUE(oo.OrderAmountData, '$.price') AS 'TotalPrice'        
  ,JSON_QUERY(oo.OrderAmountData, '$.benefitTransactions') AS 'benefitTransactions'        
 ,CAST(JSON_VALUE(oo.OrderAmountData, '$.outOfPocket') AS decimal(7,2)) AS 'MemberResponsibility'       
  ,CASE         
   WHEN oo.OrderStatusCode IN ('INI')        
    THEN CAST(1 AS BIT)        
   ELSE CAST(0 AS BIT)        
   END AS 'IsEditable'        
  ,CASE         
   WHEN oo.OrderStatusCode IN (        
     'INI'        
     ,'ACK'        
     ,'EMI'        
     )        
    THEN 'ACTIVE'    
 WHEN (select Count(*) from Orders.OrderChangeRequests      
 where OrderId=oo.orderId and IsActive=1 and Status= 'Pending') > 0 THEN 'ACTIVE'    
   ELSE 'PAST'        
   END AS 'OrderStatusCategory'        
  ,oo.OrderStatusCode AS 'OrderStatusCode'        
  ,oo.Source        
  ,(        
   SELECT DISTINCT oi.ItemCode AS 'ItemCode'        
    ,CONCAT (        
     '/'        
     ,ia.ModelAttributeValue        
     ,'/'        
     ,ia.ModelAttributeValue        
     ,'_Front.jpg'        
     ) AS 'ItemMedialUrl'        
    ,ia.ModelAttributeValue AS 'ItemAttributeValue'        
   FROM Orders.OrderItems oi        
   INNER JOIN [catalog].[ItemMasterAttributeValues] ia WITH (NOLOCK) ON oi.ItemCode = ia.ItemCode        
   WHERE orderid = oo.OrderID        
    AND ia.AttributeCode = 'NATIONS_ID'        
   FOR JSON PATH        
   ) AS ItemDetails        
  ,oo.STATUS AS OrderStatus        
  ,orcData.ChangeType        
  ,orcData.OrderChangeRequestStatus        
  ,orcData.RequestData        
  , (CASE WHEN temp.isFullRequest IS NULL THEN CAST(0 AS BIT) ELSE temp.isFullRequest END)  AS isFullRequest      
  ,oo.RefOrderId AS 'RefOrderId'        
 FROM orders.Orders oo WITH (NOLOCK)        
 LEFT JOIN [Orders].[OrderItems] oi ON oo.OrderID = oi.OrderID        
 LEFT JOIN #PartialTempTbl temp ON temp.orderid = oo.orderid      
 OUTER APPLY (        
  SELECT TOP 1 orc.changeType        
   ,orc.STATUS AS OrderChangeRequestStatus        
   ,orc.RequestData        
  FROM [Orders].[OrderChangeRequests] orc WITH (NOLOCK)        
  WHERE orc.orderid = oo.orderid        
  ORDER BY orc.OrderChangeRequestID DESC        
  ) AS orcData        
 WHERE oo.NHMemberId = @NHMemberId        
  AND oo.OrderType = 'OTC'        
  AND oo.IsActive = 1        
 ORDER BY 1 DESC        
END 