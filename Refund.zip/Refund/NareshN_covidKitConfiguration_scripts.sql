


declare @nationsId bigint=9995
declare @itemCode nvarchar(100)='1934890282042'
declare @itemName nvarchar(1000)='BinaxNOW� COVID-19 Ag Card Home Test'
declare @standardPrice decimal =25.00
declare @stockStatusCode varchar(100)='Stock'
--declare @category nvarchar(100)='First Aid & Medical Supplies'

-- GET RECENT ITEMCODE AND SET NEW itemcode to @itemCode 
SELECT TOP 1 *FROM [catalog].[ItemMasterList]  ORDER BY 1 DESC

 --STEP:1- add  Item to catalog and otccatalog schema tables 
INSERT INTO [catalog].[ItemMasterList] (ItemCode,ItemType,BrandCode,IsActive,CreateDate,CreateUser,ModifyDate,ModifyUser)
VALUES(@itemCode,'OTC','OTC',1,getdate(),'mnanduri',getdate(),'mnanduri')

-- STEP:2 Add Item  to Otccatalog.ItemMaster
INSERT INTO OTCCATALOG.ITEMMASTER (NationsId,ItemCode,ItemName,StandardPrice,StockStatusCode,DisplayOrder,IsItemFree,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
VALUES(@nationsId, @itemCode,@itemName,@standardPrice,@stockStatusCode,1,0,1,'mnanduri',getdate(),'mnanduri',getdate())


 -- Wallet ids inserts
---STEP:3- Add to  nations wallets

drop table #tempTbl
drop table #tempTbl2

-- insert into #tempTbll for walletIds
select  '9995' as NationsId ,* INTO #tempTbl 
 from(
select distinct walletId,walletSource from otccatalog.wallets where isactive=1 and  WalletCode IN ('Alignment 009 Medicare','Alignment Apple','Alignment Medicare','Alignment MedicarePlus','Alignment Medicare Grocery')
)as x

SELECT * FROM  #tempTbl

 select top 1  *from otccatalog.wallets order by 1 desc
-- insert into #tempTbl2 for actual columns
select NationsId,WalletId,'mnanduri' as CreateUser,getdate() as CreateDate, 1 as IsActive,'mnanduri' as ModifyUser,getdate()as ModifyDate
INTO #tempTbl2 FROM #tempTbl

SELECT * FROM  #tempTbl2

--STEP:4 -- INSERT Wallet items from #tempTbl2

INSERT INTO [otccatalog].[walletitems] (NationsId,WalletId,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
SELECT  NationsId,walletId,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate  FROM  #tempTbl2


-- STEP: 5  -- otccatalog.walletplans
  DROP TABLE #temptbl3

 DECLARE @InsuranceCarrierID bigint
 SET @InsuranceCarrierID = (SELECT InsuranceCarrierID FROM insurance.InsuranceCarriers where InsuranceCarrierName = 'Alignment Health Plan')
 PRINT concat('WalletsCount:',@InsuranceCarrierID)
 

 SELECT @InsuranceCarrierID as InsuranceCarrierID,NULL AS InsuranceHealthPlanID ,WalletId,1 as IsActive,'mnanduri' as CreateUser,getdate() as CreateDate, 'mnanduri' as ModifyUser,getdate()as ModifyDate
 INTO #temptbl3 
 FROM #tempTbl WHERE  WalletSource NOT IN ('NATIONS') 
 
 SELECT * FROM  #temptbl3

 -- inserts into otccatalog.walletplans IF InsuranceHealthPlanID is null , WalletId,InsuranceCarrierId not null  RECORDS NOT EXISTS  
 INSERT INTO otccatalog.walletplans(InsuranceCarrierId,InsuranceHealthPlanID,WalletId,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
 SELECT InsuranceCarrierID AS InsuranceCarrierId,InsuranceHealthPlanID, WalletId AS WalletId ,1 AS IsActive, CreateUser AS CreateUser,CreateDate, ModifyUser AS ModifyUser, ModifyDate
 FROM #temptbl3 
 WHERE NOT EXISTS (
 SELECT * FROM otccatalog.walletplans WHERE InsuranceCarrierId = #temptbl3.InsuranceCarrierId AND
 WalletId =#temptbl3.WalletId 
 )

  ---SELECT top  * FROM otccatalog.walletplans   order by 1 desc 
 
   



 