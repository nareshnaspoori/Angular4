SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/* =============================================    
  Author: Naresh Naspoori           
  Create Date: 13-MARCH-2021    
  Description: OTC get  checkout address  for checkout page.    
  =============================================    
  exec  [otc].[GetMasterMemberInfoForOTCCheckout] 'NH202106672288'    
*/    
  
CREATE PROCEDURE [otc].[GetMasterMemberInfoForOTCCheckout] @NHMemberId NVARCHAR(max)  
AS   
BEGIN  
 --DECLARE @NHMemberId NVARCHAR(max) ='NH202106672387'-- 'NH202106672288'  
 SET NOCOUNT ON;    
 DECLARE @memberId BIGINT = (SELECT memberId FROM  [Master].[Members] WHERE nhMemberId =@NHMemberId)  
   
 DROP TABLE IF EXISTS #masterCurrentLocation  
 DROP TABLE IF EXISTS #masterCurrentPhoneNumber  
  
 SELECT  * INTO #masterCurrentLocation FROM [Master].[Addresses]  WHERE  memberId =@memberId AND  AddressTypeCode = CASE 
 WHEN (SELECT  1  FROM  [Master].[Addresses] WHERE  memberId =@memberId AND  AddressTypeCode ='ship' AND isActive=1) =1 THEN 'ship' 
 WHEN (SELECT  1  FROM [Master].[Addresses]  WHERE  memberId =@memberId AND  AddressTypeCode ='perm' AND isActive=1) =1 THEN 'perm'
 WHEN (SELECT  1  FROM [Master].[Addresses]  WHERE  memberId =@memberId AND  AddressTypeCode ='home' AND isActive=1) =1 THEN 'home' END   
  
SELECT  *INTO #masterCurrentPhoneNumber FROM [Master].[PhoneNumbers] WHERE  MemberId =@memberId AND  phoneTypeCode = CASE
WHEN (SELECT  1  FROM [Master].[PhoneNumbers] WHERE  memberId =@memberId AND  phoneTypeCode ='mob' AND isActive=1) =1 THEN 'mob' 
WHEN (SELECT  1  FROM [Master].[PhoneNumbers]  WHERE  memberId =@memberId AND  phoneTypeCode ='home' AND isActive=1) =1 THEN 'home' END    
  
 SELECT mp.FirstName,mp.LastName,mcl.Address1,mcl.Address2  
 ,mcl.City,mcl.State,mcl.ZipCode, mcpn.PhoneNbr  
 ,(SELECT TOP 1 EmailAddress FROM [Master].[Emails] WHERE  memberId =@memberId AND IsActive=1)AS EmailAddress  
 ,mp.NHMemberId  
 FROM [Master].[Members] mp  
 LEFT JOIN   #masterCurrentPhoneNumber mcpn ON mp.memberId =mcpn.memberId  
 --INNER JOIN  [provider].[MemberInsurances] mi on  mp.MemberProfileId =mi.MemberProfileId  
 LEFT JOIN #masterCurrentLocation mcl  ON  mp.memberId =mcl.memberId  
 --INNER JOIN [provider].[MemberInsuranceDetails] mid  ON  mp.MemberProfileId =mid.MemberProfileId  
 WHERE mp.nhmemberId =@NHMemberId   
 AND mp.isActive =1 AND  mcpn.IsActive =1 AND mcl.IsActive =1   
 END  