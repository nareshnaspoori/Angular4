SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/* =============================================  
  Author: Naresh Naspoori         
  Create Date: 13-MARCH-2021  
  Description: OTC get  checkout address for checkout page.  
  =============================================  
  exec  [otc].[GetMemberCheckoutAddress] 'NH202106672428'  

*/  
 
ALTER PROCEDURE [otc].[GetMemberCheckoutAddress] @NHMemberId NVARCHAR(max)
AS 
BEGIN
 --DECLARE @NHMemberId NVARCHAR(max) ='NH202106672428'-- 'NH202106672288'
 SET NOCOUNT ON;  
 DECLARE @memberProfileId BIGINT = (SELECT memberProfileId FROM  [provider].[MemberProfiles] WHERE nhMemberId =@NHMemberId)
 
 DROP TABLE IF EXISTS #memberCurrentLocation
 DROP TABLE IF EXISTS #memberCurrentPhoneNumber
 DROP TABLE IF EXISTS  #providerMemberDetails 
 
 SELECT  * INTO #memberCurrentLocation FROM [provider].[MemberLocations]  WHERE  MemberProfileId =@memberProfileId and  AddressTypeCode = CASE
WHEN (SELECT  1  FROM [provider].[MemberLocations]  WHERE  MemberProfileId =@memberProfileId and  AddressTypeCode ='ship' and isActive=1) =1 THEN 'ship'
WHEN (SELECT  1  FROM [provider].[MemberLocations]  WHERE  MemberProfileId =@memberProfileId and  AddressTypeCode ='perm' and isActive=1) =1 THEN 'perm'
WHEN (SELECT  1  FROM [provider].[MemberLocations]  WHERE  MemberProfileId =@memberProfileId and  AddressTypeCode ='home' and isActive=1) =1 THEN 'home'
WHEN (SELECT  1  FROM [provider].[MemberLocations]  WHERE  MemberProfileId =@memberProfileId and  AddressTypeCode ='work' and isActive=1) =1 THEN 'work'END



SELECT  * into #memberCurrentPhoneNumber FROM [provider].[MemberPhoneNumbers]  WHERE  MemberProfileId =@MemberProfileId and  phoneTypeCode = CASE
WHEN (SELECT  1  from [provider].[MemberPhoneNumbers]  where  MemberProfileId =@MemberProfileId and  phoneTypeCode ='mob' and isActive=1) =1 THEN 'mob'
WHEN (SELECT  1  from [provider].[MemberPhoneNumbers]  where  MemberProfileId =@MemberProfileId and  phoneTypeCode ='home' and isActive=1) =1 THEN 'home' END

SELECT *INTO #providerMemberDetails FROM (

 SELECT mp.FirstName,mp.LastName,mcl.Address1,mcl.Address2
 ,mcl.City,mcl.State,mcl.ZipCode, mcpn.PhoneNumber
 ,(SELECT TOP 1 EmailAddress FROM [provider].[MemberEmails] WHERE  MemberProfileId =@memberProfileId  AND IsActive=1)AS EmailAddress
 ,mp.MemberProfileId,mp.NHMemberId
 FROM [provider].[MemberProfiles] mp
 LEFT JOIN   #memberCurrentPhoneNumber mcpn ON mp.MemberProfileId =mcpn.MemberProfileId
 --INNER JOIN  [provider].[MemberInsurances] mi on  mp.MemberProfileId =mi.MemberProfileId
 LEFT JOIN #memberCurrentLocation mcl  ON  mp.MemberProfileId =mcl.MemberProfileId
 --INNER JOIN [provider].[MemberInsuranceDetails] mid  ON  mp.MemberProfileId =mid.MemberProfileId
 WHERE mp.nhmemberId =@NHMemberId 
 and mp.isactive =1  --AND  mcpn.IsActive =1 AND mcl.IsActive =1 
 ) AS P
  
 IF((SELECT COUNT(*) FROM  #providerMemberDetails) =0)
   BEGIN
    EXEC [otc].[GetMasterMemberInfoForOTCCheckout] @NHMemberId
   END
ELSE 
	SELECT *FROM #providerMemberDetails 
 END
