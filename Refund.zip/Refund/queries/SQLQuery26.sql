select top 20 * from orders.orders WHERE OrderAmountData like '%eon%' order by 1 desc
select top 20 * from orders.orderTransactiondetails  WHERE OrderStatusCode ='bep' -- 200266426
select top 20 * from orders.orderTransactiondetails  WHERE OrderStatusCode ='pay' 
select top 10 * from [Orders].[OrderChangeRequests]order by 1 desc
select top 10 * from [Orders].[OrderChangeRequests] where orderId = 200266560 --200266553 --200266544  --200266439--200266438
select top 20 * from orders.orders where orderId =   200266623 --200266553--00266544  --200266518    --200266439--200266438
update orders.orders
set isactive =1
 where orderid=200266439
 select top 20 * from orders.orders order by 1 desc
  select top 20 * from orders.orderitems order by 1 desc
  OrderTransactionData
[{"orderDate":"04-19-2021","carrier":"General Shipping","serviceType":"FEDEX2","orderId":200266623,"trackingNumber":"784060507186","trackingUrl":"http://www.fedex.com/Tracking?action=track&tracknumbers=784060507186","shipDate":"02-24-2021","shippingCost":"15.34","taxCost":"0.0","itemTracking":[{"itemNumber":"5459","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5130","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5047","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5121","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5091","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5500","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5438","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5447","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5505","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5168","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5543","trackingNumber":"784060507186","weight":"6.0","units":"Pound"}]},{"orderDate":"04-19-2021","carrier":"General Shipping","serviceType":"FEDEX2","orderId":200266623,"trackingNumber":"784060507186","trackingUrl":"http://www.fedex.com/Tracking?action=track&tracknumbers=784060507186","shipDate":"02-24-2021","shippingCost":"15.34","taxCost":"0.0","itemTracking":[{"itemNumber":"5459","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5130","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5047","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5121","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5091","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5500","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5438","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5447","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5505","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5168","trackingNumber":"784060507186","weight":"6.0","units":"Pound"},{"itemNumber":"5543","trackingNumber":"784060507186","weight":"6.0","units":"Pound"}]}]
select top 10 * from [Orders].[OrderChangeRequestiTEMS]order by 1 desc

select top 20 * from orders.orderTransactiondetails 
where orderid =200266623 and isACtive=1 and orderstatuscode ='shi' order by 1 desc 

select top 20 * from orders.orderTransactiondetails order by 1 desc
  
SELECT TOP 10 JSON_value(OrderTransactionData,'strict $.trackingNumber') FROM orders.OrderTransactionDetails 
where orderid =200266623 and isACtive=1 and orderstatuscode ='shi' order by 1 desc 

select OrderTransactionData from  orders.OrderTransactionDetails 
where orderid =200266623 and isACtive=1 and orderstatuscode ='shi' order by 1 desc 
select * from openJson(OrderTransactionData)
with(
trackingNumber Nvarchar(50) '$.trackingNumber'
)






DECLARE @OrderTransactionData NVARCHAR(4000) =(SELECT TOP 1 JSON_QUERY (OrderTransactionData, '$.benefitTransactions')
FROM ORDERS.ORDERS where orderid=@orderid and isactive=1 )


delete from orders.ordertransactiondetails where orderid in (200266578,200266579) and orderstatuscode ='REF'
OrderChangeRequestI

 ---     [otc].[InsertChangeRequestOrderTranasactionDetails_New]  need to change to 
 --[otc].[InsertChangeRequestOrderTranasactionDetails]

UPDATE  [Orders].[OrderChangeRequests]

SET  status ='PENDING'--Createuser ='GailFran' ,ModifyUser ='GailFran',CreateDate =GetDate(), MODIFYDATE =GETDATE() ,ApproveUserProfileId =12868 
WHERE OrderchangeRequestid in (1805, 1804)

sp_helptext '[otc].[InsertChangeRequestOrderTranasactionDetails_New]'
