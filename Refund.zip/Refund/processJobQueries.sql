SELECT TOP 10 * from  [jobs].[Events] WHERE [eventcode]='PR038' ORDER BY 1 DESC -- WHERE [eventcode]='PR038'


INSERT INTO  [jobs].[Events]  VALUES
(
'NA',
GETDATE(),
'System',
'PR040',
'Claim Satus Update',
'PAGE',
1,
GETDATE(),
'System',
null
)



--SELECT * FROM [jobs].[PageEvents] -- where isprocessed=0
SELECT * from  [jobs].[EventActions]   ORDER BY ACTIONCODE ASC--WHERE actioncode ='ACT705'

SELECT * from  [jobs].[Actions]
INSERT INTO  [jobs].[EventActions]
VALUES (
GETDATE(),
'System',
1,
GETDATE(),
'System',
'PR040',
'ACT707'
)



INSERT INTO  [jobs].[Actions]
VALUES(
'Claim Status update', getdate(),'System', 1,Getdate(),'System', 'ACT707'
)


 SELECT TOP 10  * FROM [jobs].[PageEvents]   ORDER BY 1 DESC

-- after run pageEventProcessor_NET461

	SELECT TOP 10  * FROM [jobs].[PageActionProcessQueue] ORDER BY 1 DESC
	[jobs].[PageActionProcessQueue]
	----- EVEN JOB -END

	 ---     PageActionProcessor_NET461
	PAGE


SELECT PageActionProcessQueueId, ActionCode, [jobs].[PageEvents].[ReferenceData], [jobs].[PageEvents].CreateUser, [jobs].[PageEvents].ModifyUser 
 FROM [jobs].[PageActionProcessQueueHistory] LEFT OUTER JOIN [jobs].[PageEvents] on [jobs].[PageEvents].PageEventId = [jobs].[PageActionProcessQueueHistory].PageEventId 
	  WHERE [jobs].[PageEvents].[IsActive]=1 and [jobs].[PageActionProcessQueueHistory].[ProcessStatus]=1 and
	   [jobs].[PageActionProcessQueueHistory].[IsActive]=1   and [jobs].[PageActionProcessQueueHistory].actioncode ='ACT715'

	   "SELECT PageActionProcessQueueId, ActionCode, [jobs].[PageEvents].[ReferenceData], [jobs].[PageEvents].CreateUser, [jobs].[PageEvents].ModifyUser  FROM [jobs].[PageActionProcessQueue] " +
                    "LEFT OUTER JOIN [jobs].[PageEvents] on [jobs].[PageEvents].PageEventId = [jobs].[PageActionProcessQueue].PageEventId " +
                      "WHERE [jobs].[PageEvents].[IsActive]=1 and [jobs].[PageActionProcessQueue].[ProcessStatus]=0 and [jobs].[PageActionProcessQueue].[IsActive]=1 and [jobs].[PageActionProcessQueue].[IsContinuous] <> 1 AND [jobs].[PageActionProcessQueue].actionCode IN ('ACT721','ACT722')";



					  exec [otc].[ReturnLoginAuthenticationResponse_16dec] 'eon',

'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6363011091041958606","SerialNumber":"122281485","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"LIP65+","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":"","SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
,'NH202107380102'