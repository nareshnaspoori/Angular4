/****** Object:  StoredProcedure [otc].[insertChangeRequestTranasactionDetails]    Script Date: 08-03-2021 19:22:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO
            
            
          
/* =============================================              
  Author: Naresh Naspoori                     
  Updated Date: 05-MARCH-2021              
  Description: OTC insert refunds change request order transacation details.              
  =============================================              
   exec [otc].[InsertChangeRequestOrderTranasactionDetails] 200266423,'systemUser'             
*/          
          
 
alter PROC [otc].[InsertChangeRequestOrderTranasactionDetails]   
  @orderId BIGINT            
 ,@OrderTransactionData NVARCHAR(MAX) = NULL  
 ,@IsComplete bit  
 ,@createUser NVARCHAR(100) = NULL            
AS            
BEGIN            
 BEGIN TRY            
  BEGIN TRAN            
  INSERT INTO [Orders].[OrderTransactionDetails] (            
    OrderID            
   ,OrderStatusCode            
   ,OrderTransactionData            
   ,CreateDate            
   ,ModifyDate            
   ,CreateUser            
   ,ModifyUser            
   ,IsActive            
   ,IsComplete            
   )            
  VALUES (            
   @orderId            
   ,'REF'            
   ,@OrderTransactionData            
   ,GETDATE()            
   ,GETDATE()            
   ,@createUser            
   ,@createUser            
   ,1            
   ,@IsComplete           
   )            
            
  COMMIT            
 END TRY            
            
 BEGIN CATCH            
  DECLARE @ErrorMessage NVARCHAR(4000);            
  DECLARE @Severity INT;            
  DECLARE @ErrorState INT;            
            
  SELECT @ErrorMessage = ERROR_MESSAGE()            
   ,@Severity = ERROR_SEVERITY()            
   ,@ErrorState = ERROR_STATE()            
            
  RAISERROR (            
    @ErrorMessage            
    ,@Severity            
    ,@ErrorState            
    )            
            
  PRINT (@ErrorMessage)            
  PRINT (@Severity)            
  PRINT (@ErrorState)            
            
  ROLLBACK            
 END CATCH            
END