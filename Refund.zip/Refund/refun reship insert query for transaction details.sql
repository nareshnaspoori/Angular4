    DECLARE @action NVarchar(max) ='Refund'
	DECLARE @refundAmtType NVarchar(max) ='Member Responsibility'
	DECLARE @transData1 NVARCHAR(MAX)
	DECLARE @transData2 NVARCHAR(MAX)	
	DECLARE @orderId bigint = 200265202 --200265594     --200265510
	
	DROP TABLE IF EXISTS #ordrTrnsTempTbl
	DROP TABLE IF EXISTS #RequestDataTrnsTempTbl
	DROP TABLE IF EXISTS #TempTrans

    DECLARE @RequestData nvarchar(max) =(SELECT TOP 1 RequestData from   [Orders].[OrderChangeRequests] Where OrderId  =@orderId and ChangeType='Refund' ORDER BY CreateDate DESC )
 
 SELECT *, @orderId as orderId INTO #RequestDataTrnsTempTbl from (
SELECT
JSON_Value (c.value, '$.purseName') as purseName
,JSON_Value (c.value, '$.amountReturnToPocket') as refundAmount
,JSON_Value (c.value, '$.amountToReturn') as amountToReturn
,JSON_Value (c.value, '$.paymentType') as paymentType
,JSON_Value (c.value, '$.benefitsToReturn') as benefitsToReturn
	
FROM OPENJSON (@RequestData, '$.paymentDetails') as c

)t
SELECT *from  #RequestDataTrnsTempTbl
	
	--DECLARE @refundAmtType NVarchar(max) ='Member Responsibility'
	SET  @refundAmtType =CASE WHEN (SELECT  ISNULL(paymentType,0) FROM #RequestDataTrnsTempTbl) ='0' THEN '' ELSE 'Member Responsibility' END
SELECT DISTINCT
 @transData1  = 
	(SELECT 	 DISTINCT
	--, refTransactions.orderChangeRequestItemId 
	  (SELECT JSON_VALUE(OrderTransactionData,'$.transactions[0].transactionId') FROM  [Orders].[OrderTransactionDetails]  WHERE orderId = @orderId AND OrderStatusCode='PAY')  AS transactionId 
	,tempTrans.paymentType 
    ,(SELECT GETDATE()) AS refundDate
	, tempTrans.refundAmount
	,tempTrans.amountToReturn
	,tempTrans.purseName
	,tempTrans.benefitsToReturn
	,@action  AS action
	,@refundAmtType AS refundAmtType
	,'Pending' as status
	,CASE WHEN (ISNULL(tempTrans.paymentType,0)) ='0' THEN '' ELSE otcc.CardNumber END AS cardNumber
	 FROM  #RequestDataTrnsTempTbl tempTrans 
	 LEFT  JOIN  [Orders].[OrderTransactionDetails] otd ON otd.OrderId=tempTrans.OrderId  and otd.OrderStatusCode = 'PAY'
	  INNER JOIN [Orders].[OrderChangeRequests] OCR   ON tempTrans.orderId =OCR.OrderId
	  LEFT JOIN [otc].[cards] otcc ON OCR.NHMemberId =otcc.NHMemberId
	  WHERE   --otd.OrderStatusCode =  case when LEN(tempTrans.paymentType)>0 then 'PAY' end AND
	 OCR.changeType = 'REFUND'  
	 
	   and ocr.OrderId IN (@orderId)   
    FOR JSON  AUTO 
  )
   -- PRINT @transData1
	
	CREATE TABLE #TempTrans 
	(
	  transData1 nvarchar(max)
	);

	INSERT  INTO #TempTrans(transData1)VALUES(@transData1)
	select *from  #TempTrans
	
	--DECLARE @outOfPocketZeroCount BIGINT = (SELECT COUNT(*) FROM #benefitTrnsTempTbl WHERE outOfPocket in( '0.0 ' , '' ,null) )
 --PRINT @outOfPocketZeroCount
	--IF( CAST (@outOfPocketZeroCount  AS INT )> 0) 
	--PRINT 'DD'
	--SELECT @transData2 =
	--	(

	--	SELECT  transactionId
	--	,(NULL)AS paymentType
	--	,refundAmount
	--	,(SELECT GETDATE()) AS refundDate
	--	,@refundAmtType AS refundAmtType
	--	,'Pending' as status  
	--	FROM #benefitTrnsTempTbl OCR1  for json  PATH 
	
	--	) 	
	--INSERT  INTO #TempTrans(transData1)VALUES(@transData2)
 --  UPDATE #TempTrans 
	--SET transData1 = JSON_MODIFY(transData1,'append $',@transData2)
	--select *from  #TempTrans


   --select *from  #RequestDataTrnsTempTbl

--SELECT *FROM #benefitTrnsTempTbl
	





--DECLARe @transData1 NVARCHAR(MAX) =( select *From #ordrTrnsTempTbl)

--PRINT @transData1

--DECLARE @json1 NVARCHAR(500)='[{"id": 1, "data": "One"}, {"id": 2, "data": "Two"}]';
--DECLARE @json2 NVARCHAR(500)='[{"id": 3, "data": "Three"}, {"id": 4, "data": "Four"}]';


--SELECT t.id, t.[data]
--FROM
--(
--    SELECT * FROM OPENJSON(@json1) WITH(id int,[data] NVARCHAR(MAX)) 
--    UNION ALL
--    SELECT * FROM OPENJSON(@json2) WITH(id int,[data] NVARCHAR(MAX))
--) t
--FOR JSON PATH;

--DECLARE @info NVARCHAR(500)='[{"id": 1, "data": "One"}, {"id": 2, "data": "Two"}]';

--PRINT @info;

--SET @info = JSON_MODIFY(@info, 'append $', JSON_QUERY('{"id": 3, "data": "Three"}'))
--SET @info = JSON_MODIFY(@info, 'append $', JSON_QUERY('{"id": 4, "data": "Four"}'))

--PRINT @info;

--select * from [Orders].[OrderTransactionDetails] where Orderid=@orderId
--select *from  #RequestDataTrnsTempTbl
--select * from [otc].[cards] WHERE NHMemberId ='NH202106672101'


 [otc].[GetAllMemberOTCOrders_Shiva] 'NH202106672204'

 SELECT STRING_ESCAPE('\"999":"\"TEST\""', 'json') AS escapedText;  
 
 DECLARE @orderId bigint =200265931
 
     SELECT TOP 1 * FROM [Orders].[OrderChangeRequestItems] ocri WITH (NOLOCK) 
																					--INNER JOIN orders.orderitems oi ON ocri.OrderId =oi.OrderId
																					WHERE ocri.orderid = @OrderId  ORDER BY  ocri.OrderChangeRequestItemId DESC
																	
(SELECT TOP 1  orc.Quantity  FROM [Orders].[OrderChangeRequestItems] orc WITH (NOLOCK) WHERE orc.orderid = @OrderId AND orc.OrderItemId = oi.OrderItemId

ORDER BY  orc.OrderChangeRequestItemId DESC) AS ChangeRequestItemQuantity 

select *from  [Orders].[OrderChangeRequestItems] where orderId =200265931 order by 1 desc



SELECT TOP 10 * FROM ORDERS.ORDERITEMS WHERE ORDERID  =200266093
SELECT TOP 10* FROM [Orders].[OrderChangeRequestItems] 


 SELECT oo.OrderID, SUM(oi.Quantity) as TotalQuantity, ISNULL(sum(ocri.Quantity), 0) AS ReqQuantity    
, CASE WHEN SUM(oi.Quantity) <= ISNULL(sum(ocri.Quantity), 0)    
THEN 1 ELSE 0 END AS isFullOrder    
FROM Orders.Orders oo WITH (NOLOCK)  
INNER JOIN Orders.OrderItems oi  WITH (NOLOCK) ON oi.OrderId = oo.OrderID AND oo.IsActive = 1
LEFT JOIN Orders.OrderChangeRequestItems ocri  WITH (NOLOCK) ON ocri.OrderId = oo.OrderID  AND oi.orderitemid = ocri.orderitemid   
   AND (SELECT changeType FROM Orders.OrderChangeRequests  WITH (NOLOCK) WHERE IsActive = 1 AND    
     OrderChangeRequestID = ocri.OrderChangeRequestId) = 'REFUND'    
     AND ocri.ItemCode = oi.ItemCode    
   AND ocri.IsActive = 1    
WHERE oo.NHMemberId = 'NH202106672045' AND OO.ORDERID = 200266093
AND oo.IsActive = 1 
GROUP BY oo.OrderID  