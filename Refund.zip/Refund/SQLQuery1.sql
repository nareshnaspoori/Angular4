  
BEGIN TRY 
	BEGIN TRAN 
 PRINT 'Execution started..'

 DECLARE @MEMBERPORTALLOGIN NVARCHAR(MAX) ='MEMBERPORTALLOGIN'
 DECLARE @ConfigType NVARCHAR(MAX)

 SELECT @ConfigType=ConfigType FROM insurance.InsuranceConfigTypes  WHERE ConfigType=@MEMBERPORTALLOGIN 
  PRINT CONCAT('ConfigType:',ISNULL(@ConfigType,''));
  IF(@ConfigType IS NULL)
   BEGIN
	  -- Insert MEMBERPORTALLOGIN Configy type 
	  INSERT INTO  Insurance.InsuranceConfigTypes (ConfigType,ConfifDescription,isActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
	  VALUES(@MEMBERPORTALLOGIN,
	  @MEMBERPORTALLOGIN,
	  1,'Mnanduri',getDate(),'Mnanduri',getDate()
	  )
	  SELECT TOP 1 *FROM Insurance.InsuranceConfigTypes WHERE configType =@MEMBERPORTALLOGIN ORDER BY 1 DESC
	  PRINT 'succefully executed.'
	 END
ROLLBACK TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH


  