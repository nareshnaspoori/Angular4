SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/* =============================================  
  Author: Naresh Naspoori         
  Create Date: 05-MARCH-2021  
  Description: OTC get  Refund or reship orders requests for admin portal.  
  =============================================  
  exec  [orders].[GetOrderChangeRequests] 'PENDING'  
*/  
  
ALTER PROCEDURE [Orders].[GetOrderChangeRequests]    
 @Status VARCHAR(20) ='PENDING'      
AS    
BEGIN  
 SELECT DISTINCT ocr.OrderId    
    ,ocr.OrderChangeRequestId    
  ,ocr.NHMemberId AS NHMemberId    
    --    ,(select oci1.ItemData from orders.OrderChangeRequestItems  oci1 where oci1.OrderChangeRequestId=ocr.OrderChangeRequestID  FOR JSON AUTO) ItemData    
  ,(    
  SELECT  oim1.ItemName, oci.Quantity, JSON_VALUE(oci.ItemData,'$.unitPrice') as UnitPrice,(oci.Quantity * CAST(JSON_VALUE(oci.ItemData,'$.unitPrice') As DECIMAL(18, 2))    
  )AS TotalPrice, oci.OrderItemId,oci.Comments from Orders.OrderChangeRequestItems oci
  JOIN [otccatalog].[itemmaster] oim1 WITH (NOLOCK)  ON oim1.ItemCode = oci.ItemCode AND oci.IsActive=1  
  where oci.OrderChangeRequestId=ocr.OrderChangeRequestID   for json path) as _ItemDetails    
  ,(    
  SELECT   oci.OrderItemId,oci.Comments,JSON_VALUE(oci.ItemData,'$.Reason') as Reason  from Orders.OrderChangeRequestItems oci where oci.OrderChangeRequestId=ocr.OrderChangeRequestID   for json path    
  ) AS _ItemComments    
 ,(CASE 
   WHEN (up.UserName IS NOT NULL) THEN up.UserName
    ELSE (SELECT CONCAT (firstName,' ', lastName) FROM master.members WHERE nhmemberid =ocr.NHMemberId)   
  END  
) AS UserName
,aup.UserName as [SubmittedBy]    
  ,CAST(ocr.SubmitDate AS VARCHAR) AS [RequestedDate]    
  ,ocr.ChangeType AS [RequestType]    
  ,LOWER(ocr.STATUS) AS  Status  
  ,ocr.AdminComments  
 FROM orders.OrderChangeRequests AS ocr    
 inner JOIN orders.OrderChangeRequestItems AS oci ON ocr.OrderChangeRequestId = oci.OrderChangeRequestId    
 LEFT JOIN otc.userprofiles up ON up.NHMemberId = ocr.NHMemberId  AND up.isActive = 1  
 INNER JOIN orders.orderItems oi ON oi.orderItemId =oci.orderItemId    
 LEFT JOIN [otccatalog].[itemmaster] oim WITH (NOLOCK) --Modified Inner Join to Left Join          
 ON oi.ItemCode = oim.ItemCode AND oi.IsActive=1         
 INNER JOIN auth.UserProfiles aup on aup.UserProfileId=ocr.SubmitUserProfileId    
  WHERE ocr.IsActive = 1    
  AND oci.IsActive = 1    
  --AND up.isActive = 1    
  AND ocr.OrderType = 'OTC'       
  AND ocr.STATUS = @Status    
  AND aup.IsActive=1   
  GROUP BY ocr.OrderId, ocr.OrderChangeRequestId
  ,ocr.NHMemberId,ocr.SubmitDate
  ,oim.ItemName,aup.USERNAME
  ,up.UserName,ocr.ChangeType
  ,ocr.STATUS ,ocr.AdminComments 
  ORDER BY RequestedDate ASC  
END  
  



  
  
	
