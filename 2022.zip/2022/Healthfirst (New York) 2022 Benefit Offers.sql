BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
--------------------------------------STEP:1- Create Carrier HealthFirst and configure OTCAPP for new offers required configurations-------------------------------------------------------------------------------------------------

DECLARE @carrierName NVARCHAR(100)='Healthfirst (New York)'
DECLARE @carrierConfig NVARCHAR(MAX)
DECLARE @carrierId BIGINT  
DECLARE @otcAppConfig NVARCHAR(MAX) 
DECLARE @OTCAPP VARCHAR(50) ='OTCAPP'
DECLARE @updateOTCConfigForOffers NVARCHAR(MAX) ='{"templateName":"newOffers","title":"2022 Benefits","isTemplateEnable":true }'
DECLARE @modifyCreateUser VARCHAR(50) ='script'
DECLARE @offersInserted NVARCHAR(MAX)



SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName  AND IsActive =1
PRINT CONCAT('@carrierId:',ISNULL(@carrierId,0))

SELECT @otcAppConfig =ConfigData FROM Insurance.insuranceconfig WHERE InsuranceCarrierID=@carrierid AND ConfigType=@OTCAPP AND IsActive =1
--PRINT CONCAT('otcAppConfig:',@otcAppConfig)

SET @otcAppConfig =JSON_MODIFY(@otcAppConfig,'$.offers',JSON_QUERY(@updateOTCConfigForOffers))
--PRINT CONCAT('updated otcAppConfig:',@otcAppConfig)


IF(ISNULL(@carrierId,0)>0)
BEGIN
---INSERTING CONFIGURATIONS('OTCAPP',planCode in ConfigData ) 
IF NOT EXISTS(select * from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid AND ConfigType=@OTCAPP AND ISNULL(InsuranceHealthPlanId, 0)=0)
	BEGIN
		INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
		VALUES
		(@OTCAPP,@otcAppConfig,@carrierid,GETDATE(),@modifyCreateUser,GETDATE(),@modifyCreateUser,1)
	END

ELSE
	BEGIN
		UPDATE Insurance.insuranceconfig
		SET ConfigData=IIF(ISNULL(ConfigData,'')='', @otcAppConfig, JSON_MODIFY(ConfigData,'$.offers',JSON_QUERY(@updateOTCConfigForOffers))), 
		ModifyDate=GETDATE(), ModifyUser=@modifyCreateUser
		WHERE InsuranceCarrierID=@carrierid and ConfigType=@OTCAPP  AND InsuranceHealthPlanId IS NULL AND IsActive =1
	END
	
	SELECT @offersInserted =JSON_QUERY(ConfigData,'$.offers') from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid AND ConfigType=@OTCAPP AND InsuranceHealthPlanId IS NULL
IF(@offersInserted IS NOT NULL)
PRINT  CONCAT('succefully executed. offers:',@offersInserted)
END
COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH

