BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
--------------------------------------STEP:1- Create Carrier HealthFirst and configure OTCAPP for new offers required configurations-------------------------------------------------------------------------------------------------

DECLARE @carrierName NVARCHAR(100)='Healthfirst (New York)'
DECLARE @carrierConfig NVARCHAR(MAX)='{"subdomain":"healthfirst","carrierCode":"healthfirst","dhePhone":"877-236-7027","isTeleAudiologyEnabled":true,"benefitValueSource":"incomm","isManaged":false,"clientLogoPlace":"Left"}'
DECLARE @carrierId BIGINT  

DECLARE @otcAppConfig NVARCHAR(MAX) ='{"canSubscribe":false,"isHealthProfileDisabled":false,"alwaysViewCatalog":false,"disablePromotions":false,"expressOrderEnabled":true,"Preferences":{"OrderUpdates" :{"sendEmail": false, "sendSMS": false}},"offers":{"templateName":"newOffers","title":"2022 Benefits","isTemplateEnable":true }}'
DECLARE @OTCAPP VARCHAR(50) ='OTCAPP'
DECLARE @updateOTCConfigForOffers NVARCHAR(MAX) ='{"templateName":"newOffers","title":"2022 Benefits","isTemplateEnable":true }'
DECLARE @modifyCreateUser VARCHAR(50) ='script'
DECLARE @carrierCode NVARCHAR(50)= JSON_VALUE(@carrierConfig,'$.carrierCode')
DECLARE @offersInserted NVARCHAR(MAX)


SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
PRINT CONCAT('@carrierId:',ISNULL(@carrierId,0));

IF(ISNULL(@carrierId,0)>0)
BEGIN
----Update Config {"subdomain":"healthfirst","carrierCode":"healthfirst"}
UPDATE Insurance.InsuranceCarriers
SET CarrierConfig = IIF(ISNULL(CarrierConfig,'') ='',@carrierConfig, JSON_MODIFY(JSON_MODIFY(CarrierConfig,'$.subdomain',@carrierCode),'$.carrierCode',@carrierCode)),
ModifyDate=GETDATE(),ModifyUser=@modifyCreateUser
WHERE InsuranceCarrierID=@carrierId
END
ELSE
BEGIN
 -- INSERTING CARRIER 
 INSERT INTO insurance.insurancecarriers (CreateDate,CreateUser,InsuranceCarrierName,IsActive,IsContracted,IsDiscountProgram,MemberDataFileProvided,ModifyDate,ModifyUser,IsAutoSendPaymentReceipt,CarrierConfig,IsNHDiscount,AllowAdditionalServices)
 VALUES (getdate(),@modifyCreateUser,@carrierName,1,1,0,0,getdate(),@modifyCreateUser,0,@carrierConfig,0,0)

 --SELECT INSERTED CARRIERID
 SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
 PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));
END

---INSERTING CONFIGURATIONS('OTCAPP',planCode in ConfigData ) 
IF NOT EXISTS(select * from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid and ConfigType=@OTCAPP AND ISNULL(InsuranceHealthPlanId, 0)=0)
	BEGIN
		INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
		VALUES
		(@OTCAPP,@otcAppConfig,@carrierid,GETDATE(),@modifyCreateUser,GETDATE(),@modifyCreateUser,1)
	END

ELSE
	BEGIN
		UPDATE Insurance.insuranceconfig
		SET ConfigData=IIF(ISNULL(ConfigData,'')='', @otcAppConfig, JSON_MODIFY(ConfigData,'$.offers',JSON_QUERY(@updateOTCConfigForOffers))), 
		ModifyDate=GETDATE(), ModifyUser=@modifyCreateUser
		WHERE InsuranceCarrierID=@carrierid and ConfigType=@OTCAPP  AND InsuranceHealthPlanId IS NULL
	END
	
	SELECT @offersInserted =JSON_QUERY(ConfigData,'$.offers') from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid AND ConfigType=@OTCAPP AND InsuranceHealthPlanId IS NULL
IF(@offersInserted IS NOT NULL)
PRINT  CONCAT('succefully executed. offers:',@offersInserted)
COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH

