EXEC [dbo].[GetAllCarriersBenefitURLs]



select *from otc.MemberEligibility

select top 1 *from master.memberInsurances order by 1 desc

--Health First Health Plans (AdventHealth)
select *from insurance.InsuranceCarriers where InsuranceCarrierID = 7 -- 380 --277 -- 138 -- 363

select top 10 *from insurance.InsuranceCarriers where InsuranceCarrierName ='Healthfirst (New York)' --277
select InsuranceHealthPlanId,configData  from insurance.InsuranceConfig where InsuranceHealthPlanId is not null and configType='FISCONFIGURATION'
group by InsuranceHealthPlanId,configData

{"ClientID": "610915","SubProgID": "796357","CarrierPlanlogourl":"https://nationscdn.azureedge.net/nb-container/NBBenefits/8/mi-mmp-logo.png"}
{"ClientID": "610915","SubProgID": "796357","CarrierPlanlogourl":"https://nationscdn.azureedge.net/nb-container/NBBenefits/molina-logos/mi-mmp-logo.png"}
{"ClientID": "610915","SubProgID": "796357",   "CarrierPlanlogourl":"https://nationscdn.azureedge.net/nb-container/NBBenefits/molina-logos/molina-logo.png"}

select top 10 *From  [member].[loginactivitylog] order by 1 desc
select top 10  *from  master.MemberInsuranceDetails order by 1 desc
select *from insurance.InsuranceConfig where InsuranceCarrierID = 277 order by 1 desc
select *from insurance.InsuranceCarriers where InsuranceCarrierID = 274 order by ModifyDate desc  --394   -- 138  --7--  277 7  --138 --363
select top 20  *from  insurance.insurancehealthplans WHERE  InsuranceCarrierID=380
select top 10 * from insurance.insurances order by 1 desc
SELECT configdata from Insurance.insuranceconfig where InsuranceCarrierID=7 AND ConfigType='OTCAPP' AND InsuranceHealthPlanId IS NULL
select top 20  *from  insurance.insurancehealthplans WHERE  InsuranceCarrierID=380

--H5454_004 Clear Spring Health Essential Plus HMO Illinois 2554 274 oh-mmp-logo.png
-- H2020_004 Clear Spring Health Essential Plus PPO Colorado 2556 274 mi-mmp-logo.png

--H5454_001 Clear Spring Health Essential HMO Illinois 2561 274 passport-logo.png

-- H5454_002 Clear Spring Health Essential HMO Illinois 2560 274 mi-mmp-logo.png
--  H6379_001 Clear Spring Health Essential HMO Colorado   2563 oh-mmp-logo.png

-- alignmentpartners
-- Alignment Partners Plan   --4012  379  oh-mmp-logo.png




"offers":{"templateName":"2022Offers","title":"New 2022 Offers" }
--delete from   insurance.InsuranceConfig where configId =403


-- HEALTH FIRST NEW 2022 OFFERS UPDATE 
======================================



UPDATE insurance.InsuranceConfig
SET ConfigData = JSON_MODIFY(ConfigData,'$.displayOfferBenefitPage',null )
where  InsuranceCarrierID = 277 and configId =579

 --JSON_MODIFY(@OriginalJSON,'$.Quantity',10)
 
 -- HEALTH FIRST NEW 2022 OFFERS PAGE AND BANNER 
 select top 10 *from insurance.InsuranceCarriers order by 1 desc
select top 10 *from insurance.InsuranceCarriers where InsuranceCarrierName like'%alignment %' --277
UPDATE insurance.InsuranceConfig
SET ConfigData = JSON_MODIFY(ConfigData,'$.offers', null)
where configid =404

select top 10* from otc.userProfiles where subdomain ='healthfirst' order by 1 desc 
select top 10* from 

select top 10 *from insurance.InsuranceConfig where InsuranceCarrierID = 379  and InsuranceHealthPlanId=15  order by ModifyDate desc 
select *from insurance.InsuranceCarriers where InsuranceCarrierID = 277 order by ModifyDate desc  
---------------------- 

select top 10  *From otccatalog.wallets where walletcode like '%apple%'
select JSON_QUERY(ConfigData,'$.offers') from Insurance.insuranceconfig where InsuranceCarrierID=7 AND ConfigType='OTCAPP' AND ISNULL(InsuranceHealthPlanId, 0)=0

SELECT TOP 10  *from Insurance.insuranceconfig  WHERE InsuranceHealthPlanId=0;
-- dynamic log0
UPDATE insurance.InsuranceConfig 
SET ConfigData = JSON_MODIFY(ConfigData,'$.planCode', 'mi-mmp-logo')   
 WHERE configId =943



 ----mi-mmp-logo.png oh-mmp-logo.png  passport-logo.png   sc-mmp-logo.png  swh-logo.png tx-mmp-logo.png



 select top 10 * from otc.userProfiles where subDomain ='vibra'order by 1 desc
 
--{"canSubscribe":false,"isHealthProfileDisabled":false,"alwaysViewCatalog":false,"disablePromotions":false,"expressOrderEnabled":true,"Preferences":{"OrderUpdates" :{"sendEmail": false, "sendSMS": false}}}


--InsuranceHealthPlanId
{"ClientID": "610915","SubProgID": "796357",   "CarrierPlanlogourl":"https://nationscdn.azureedge.net/nb-container/NBBenefits/molina-logos/molina-logo.png"}
4019

415

sp_helptext '[otc].[GetLoginRedirect]'


sp_helptext  '[otc].[ReturnLoginAuthenticationResponse]'   --'[otc].[AuthenticateOTCFlexStandardLogin]'  --'[otc].[LoginAuthentication]'

INSERT INTO insurance.InsuranceConfig  (ConfigType,configData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,isActive,InsuranceHeaLthPlanId)
values('OTCAPP','{"canSubscribe":true,"isHealthProfileDisabled":false,"alwaysViewCatalog":false,"disablePromotions":false,"expressOrderEnabled":true,"Preferences":{"OrderUpdates" :{"sendEmail": true, "sendSMS": true}},"benefitExpiration":{"showBenefitExpiration":true, "expireInDays":20},"planCode":125}',
7,GETDATE(),'Mnanduri',GETDATE(),'Mnanduri',1,21
)



---      molina user insert
select top 10*from [Master].[MemberInsuranceDetails] where insurancenbr='molina3635'
select top 10*from [provider].[MemberInsuranceDetails] where insurancenbr='molina3635'
select top 10* from master.members where nhmemberId ='NH202107082771'

update [Master].[MemberInsuranceDetails] set OTCSerialNumber='0355007683448' where insurancenbr='molina3635'
update [provider].[MemberInsuranceDetails] set OTCSerialNumber='0355007683448' where insurancenbr='molina3635'
select top 10 *From otc.userprofiles where nhmemberId ='NH202107082771'

select top 50 *from  insurance.insurancehealthplans where healthPlanName like '%partners%'  order by healthPlanName asc

ORDERS.ORDERS
select top 

-- Eon Choice PPO H9589 -----  14   7   -mi-mmp-logo.png 
-- Eon Deluxe HMO  H6672 --15   7    oh-mmp-logo.png
-- Eon Choice PPO H2334  --2045   7 passport-logo.png testjeonfour 
--Eon Gold Plus PPO H2334  --3450  7   sc-mmp-logo.png

SELECT TOP 20 *from Insurance.insuranceconfig  order by createdate desc
----mi-mmp-logo.png oh-mmp-logo.png  passport-logo.png   sc-mmp-logo.png  swh-logo.png tx-mmp-logo.png
--delete from  Insurance.insuranceconfig  where configId = 563
--- HEALTH FIRST CONFIGURATION Eon Select HMO H9403
-- Eon Select HMO H9403

SELECT   *from Insurance.insuranceconfig WHEre insuranceCarrierId =7
SELECT *FROM [ORDERS].[ORDERS] WHERE ORDERID = 200443403
SELECT *FROM [ORDERS].[ORDERITEMS] WHERE ORDERID = molina0010

UPDATE [ORDERS].[ORDERS] SET OrderAmountData = JSON_MODIFY(OrderAmountData,'$.isProcessedAsSupply',CAST(0 as bit)) WHERE ORDERID = 200443403

 


update provider.MemberInsuranceDetails set OTCSerialNumber = '0035036240511' where InsuranceNBR = 'testjmolinaone'

SELECT TOP 10 *fROM member.membercards where INsuranceCarrierId =277 order by 1 desc

SELECT TOP 10 *fROM member.membercards  order by 1 desc 

select top 10 *from insurance.insuranceCarriers   where INsuranceCarrierId = 277 order by 1 desc
select top 10 *from insurance.insuranceCarriers   where INsuranceCarrierId =281 order by 1 desc


select top 10 *from insurance.insuranceConfig   where INsuranceCarrierId =258 order by 1 desc

select  *from insurance.insuranceCarriers   where JSON_VALUE(CarrierConfig, '$.benefitValueSource') ='incomm'

select top 10 *from  member.membercards where nhmemberId= '6103803071020637621'   --NH202107380582
select top 10 *from  member.membercards where cardNumber ='6363012631045970807'
delete from   member.membercards where cardNumber ='6363012631045970807'
select top 10 *From [Master].[MemberInsurances] order by 1 desc 
-CarrierConfig
{"subdomain":"healthfirst","carrierCode":"healthfirst","dhePhone":"877-236-7027","isTeleAudiologyEnabled":true,"benefitValueSource":"incomm","isManaged":false,"clientLogoPlace":"Left","parentCarrierId":258}

partialManaged:

exec [otc].[LoginAuthentication]  'healthfirst2',
'{"Key":0,"MemberFirstName":"health","MemberLastName":"healthyu","MemberDOB":"2000-01-01T00:00:00","NHMemberId":"NH202108560899","CarrierId":0,"PlanId":0,"CardNumber":"6103803071020637621","SerialNumber":null,"InsuranceNumber":"dfd123","UserName":"dcooper","LoginUserName":null,"LoginPassword":null,"ProgramCode":null,"CVV":"XXX","ExpirationMonth":"","ExpirationYear":"","IpAddress":"122.185.109.90","HealthPlanCode":null,"GroupNo":null,"SubDomain":null,"BenefitSource":null,"SSN":null,"IsAgentAccess":false}'
,1


[otc].[ReturnLoginAuthenticationResponse]  'healthfirst2',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6363012631045970807","SerialNumber":"124741215","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"P29-3953","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":null,"SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
,'NH202107380400' 

sp_helptext '[otc].[ReturnLoginAuthenticationResponse]'

sp_helptext '[otc].[LoginAuthentication]'

 [otc].[AuthenticateOTCIncomm2FALogin] 'healthfirst2',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6363012631045970807","SerialNumber":"124741215","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"P29-3953","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":null,"SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
,0,'incomm',0  

EXECUTE [otc].[AuthenticateOTCIncomm2FALogin] @domain,@loginData,@isManaged,@benefitSource,@isSSO  
 
sp_helptext '[otc].[AuthenticateOTCIncomm2FALogin]'
SELECT TOP 1 InsuranceHealthPlanID          
     FROM Insurance.InsuranceHealthPlans          
     WHERE IsActive = 1          
      AND InsuranceCarrierID =258         
      AND PlanConfigData IS NULL 



	  exec [otc].[LoginAuthentication]  'healthfirst2',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6363012641038727148","SerialNumber":"110151451","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"P29-3953","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":null,"SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
,false


[otc].[ReturnLoginAuthenticationResponse]  'healthfirst2',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6363012631045970807","SerialNumber":"124741215","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"P29-3953","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":null,"SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
,'NH202107380400' 


 [otc].[ReturnLoginAuthenticationResponse] 'healthfirst2',
 '{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6363012631045970807","SerialNumber":"124741215","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"P29-3953","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":null,"SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
, 'NH202107380585'

[otc].[ReturnLoginAuthenticationResponse]  'healthfirst2',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6103803071018425310","SerialNumber":"122209635","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"P29-3739","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":null,"SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
  ,NULL

  SELECT *        
     FROM Insurance.InsuranceHealthPlans          
     WHERE IsActive = 1          
      AND InsuranceCarrierID = 277  and InsuranceHealthplanId =2433        
      AND PlanConfigData IS NULL          
     )   

	 SELECT *        
     FROM Insurance.InsuranceHealthPlans          
     WHERE IsActive = 1          
      AND InsuranceCarrierID = 258  and InsuranceHealthplanId =2433        
      AND PlanConfigData IS NULL          
     )  
  
  2433
   SELECT  TOP 10 *        
     FROM member.MemberCards   WHERE InsuranceCarrierID = 277  order by modifydate desc
	   SELECT  TOP 10 *   from  member.MemberCards where cardNumber = 6103803071020637621    6363012631045970807
	   SELECT  TOP 10 *        
     FROM  [Master].[MemberInsurances]  WHERE InsuranceCarrierID = 258  and InsuranceHealthPlanID =2433 
	 --and memberId = 
	 --7380585

	  SELECT  TOP 10 *        
     FROM  [Master].[MemberInsurances]  WHERE InsuranceCarrierID = 277  and InsuranceHealthPlanID =2433 
	 

	   SELECT  TOP 10 *        
     FROM  [Master].[MemberInsurances]  order by 1 desc 


	 and memberId = 7380585
	 7380585

	 sp_helptext '[otc].[ReturnLoginAuthenticationResponse]'


	 exec [otc].[LoginAuthentication]  'healthfirst2',
 '{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6103803071020637621","SerialNumber":"122207658","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"P29-3739","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":"CC1000","SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
 ,false



 [otc].[ReturnLoginAuthenticationResponse]  'healthfirst2',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6103803071020637621","SerialNumber":"122207658","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"P29-3739","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":"CC1000","SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
  ,NULL



   [otc].[AuthenticateOTCIncomm2FALogin] 'healthfirst2',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6103803071020637621","SerialNumber":"122207658","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":"P29-3739","CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":"H29","GroupNo":"CC1000","SubDomain":null,"BenefitSource":null,"IsAgentAccess":false}'
,0,'incomm',0  


DELETE FROM DBO.Sessions