 BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'

 
 DECLARE @subdomain NVARCHAR(100)='capitalbluecross'
 DECLARE @carrierId BIGINT
 DECLARE @walletId BIGINT
 DECLARE @flexGroceryWalletId BIGINT
 DECLARE @systemUser VARCHAR(100)='mnanduri';
 DECLARE @walletAttributeId BIGINT
 DECLARE @walletCode VARCHAR(100)='CB02FIS22'


SELECT @carrierId= InsuranceCarrierId from  insurance.InsuranceCarriers where JSON_VALUE(CarrierConfig,'$.subdomain') = @subdomain
SELECT @carrierId AS carrierId

SELECT @walletId = WalletId FROM otccatalog.WalletPlans where  InsuranceCarrierID =@carrierId and walletId IN ( SELECT  walletId FROM otccatalog.Wallets where walletCode = @walletCode)
SELECT @walletId as walletId


   SELECT @walletAttributeId =  walletAttributeId FROM   otccatalog.WalletAttributeMaster WHERE name ='SSBCIWallet' AND Description like '%opt-in%'
   SELECT @walletAttributeId AS walletAttributeId

 IF(ISNULL(@walletAttributeId,0)!=0)
   BEGIN
	    UPDATE otccatalog.WalletPlans
        SET WalletStandardData='['+CAST (@walletAttributeId AS VARCHAR(100))+']',
        modifyDate =GETDATE()
        WHERE WalletId = @walletId 
	  
 SELECT *FROM otccatalog.WalletPlans  WHERE ISNULL(InsuranceHealthPlanID,0) =0 AND InsuranceCarrierID =@carrierId AND walletId = @walletId
 
	END

 	COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH


