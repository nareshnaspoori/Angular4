BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
--------------------------------------STEP:1- Create Carrier and configure OTCAPP AND for plan level logo MOLINA required configurations-------------------------------------------------------------------------------------------------

DECLARE @carrierName NVARCHAR(100)='Clear Spring'
DECLARE @carrierId BIGINT
DECLARE @carrierConfig NVARCHAR(MAX)='{"subdomain":"clearspring","benefitValueSource":"nations","isManaged":true,"carrierCode":"clearspring","isTeleAudiologyEnabled":"true","languages":["English"],"dhePhone":"877-221-4321","clientLogoPlace":"Left"}'

DECLARE @otcConfig NVARCHAR(MAX) ='{"canSubscribe":true,"isHealthProfileDisabled":false,"alwaysViewCatalog":false,"disablePromotions":false,"expressOrderEnabled":true,"Preferences":{"OrderUpdates" :{"sendEmail": true, "sendSMS": false}},"planCode":"passport-logo"}'
DECLARE @planCode NVARCHAR(MAX) ='passport-logo' 
DECLARE @OTCAPP VARCHAR(50) ='OTCAPP'
DECLARE @insuranceHealthPlanId BIGINT =2561
DECLARE @planCodeInserted NVARCHAR(MAX)
DECLARE @carrierCode  VARCHAR(50) ='clearspring'



SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));

IF(ISNULL(@carrierId,0)>0)
 BEGIN
------Update Config {"subdomain":"molina","carrierCode":"molina"}
 UPDATE Insurance.InsuranceCarriers
 SET CarrierConfig = IIF(ISNULL(CarrierConfig,'') ='',@carrierConfig, JSON_MODIFY(JSON_MODIFY(CarrierConfig,'$.subdomain',@carrierCode),'$.carrierCode',@carrierCode)),ModifyDate=GETDATE(),ModifyUser='mnanduri'
 WHERE InsuranceCarrierID=@carrierId
 END
ELSE
 BEGIN
 --INSERTING CARRIER
 INSERT INTO insurance.insurancecarriers (CreateDate,CreateUser,InsuranceCarrierName,IsActive,IsContracted,IsDiscountProgram,MemberDataFileProvided,ModifyDate,ModifyUser,IsAutoSendPaymentReceipt,CarrierConfig,IsNHDiscount,AllowAdditionalServices)
 VALUES (getdate(),'script',@carrierName,1,1,0,0,getdate(),'script',0,@carrierConfig,0,0)

 --SELECT INSERTED CARRIERID
 SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
 PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));
END


---INSERTING CONFIGURATIONS('OTCAPP',planCode in ConfigData ) 
IF NOT EXISTS(select * from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid and ConfigType=@OTCAPP and InsuranceHealthPlanId =@insuranceHealthPlanId)
	BEGIN
		INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive,InsuranceHealthPlanId)
		VALUES
		(@OTCAPP,@otcConfig,@carrierid,GETDATE(),'mnanduri',GETDATE(),'mnanduri',1,@insuranceHealthPlanId)
	END

ELSE
	BEGIN
		UPDATE Insurance.insuranceconfig
		SET ConfigData=IIF(ISNULL(ConfigData,'')='', @otcConfig, JSON_MODIFY(ConfigData,'$.planCode',@planCode)), 
		ModifyDate=GETDATE(), ModifyUser='mnanduri'
		WHERE InsuranceCarrierID=@carrierid and ConfigType=@OTCAPP and InsuranceHealthPlanId = @insuranceHealthPlanId
	END

	SELECT  @planCodeInserted =  JSON_VALUE(ConfigData,'$.planCode') from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid AND ConfigType=@OTCAPP and InsuranceHealthPlanId = @insuranceHealthPlanId
IF(@planCodeInserted IS NOT NULL)
BEGIN
PRINT  CONCAT('succefully executed. PlanCode:',@planCodeInserted)
END
COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH

