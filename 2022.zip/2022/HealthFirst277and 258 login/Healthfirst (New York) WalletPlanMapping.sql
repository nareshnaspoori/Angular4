 BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
 

DECLARE @cId BIGINT = (SELECT TOP 1 InsuranceCarrierID FROM Insurance.InsuranceCarriers WHERE JSON_VALUE(CarrierConfig,'$.subdomain') like '%healthfirst%')

DROP TABLE IF EXISTS  #healthWalletPlans

SELECT *INTO #healthWalletPlans
FROM (
SELECT @cId as InsuranceCarrierId,WalletId,BenefitValueSource,IsActive
FROM otccatalog.WalletPlans
WHERE InsuranceCarrierId = 258
)AS F



UPDATE hw SET IsActive=0
FROM #healthWalletPlans hw
INNER JOIN otccatalog.WalletPlans otw ON hw.WalletId =otw.WalletId
WHERE otw.InsuranceCarrierId =@cId

--select *from #healthWalletPlans

INSERT INTO otccatalog.WalletPlans
(InsuranceCarrierId,WalletId,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate,EffectiveFrom,BenefitValueSource)
SELECT @cId, WalletId,1,'mnanduri',GETDATE(),'mnanduri',GETDATE(),GETDATE(),BenefitValueSource
FROM #healthWalletPlans
WHERE  IsActive =1

COMMIT TRAN
END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH



