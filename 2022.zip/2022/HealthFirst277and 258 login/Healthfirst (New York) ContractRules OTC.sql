 BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
 
 DECLARE @carrierId BIGINT
 DECLARE @systemUser VARCHAR(100)='mnanduri';
 DECLARE @carrierName NVARCHAR(100)='Healthfirst (New York)'
 DECLARE @benefitValueSrc  NVARCHAR(100) ='INCOMM'
 DECLARE @benefitRuleDataId BIGINT

 SET @carrierId= (SELECT TOP 1 insurancecarrierId FROM insurance.insurancecarriers  WHERE JSON_VALUE(CarrierConfig,'$.subdomain') like '%healthfirst%' )
 SET @benefitRuleDataId = (SELECT TOP 1 BenefitRuleDataId FROM rulesengine.BenefitRulesData WHERE JSON_VALUE(BenefitRuleData ,'$.BENVALUESRC')= @benefitValueSrc AND IsActive =1)

DROP TABLE IF EXISTS  #healthPlnCntrctTbl

SELECT *INTO #healthPlnCntrctTbl 
FROM (
SELECT hp.HealthPlanContractId, ihp.* FROM Insurance.HealthPlanContracts hp 
INNER JOIN insurance.insurancehealthplans ihp ON ihp.insuranceHealthPlanID =hp.insuranceHealthPlanID
WHERE  ihp.InsuranceCarrierId =@carrierId

)AS F


UPDATE hc SET IsActive =0
FROM #healthPlnCntrctTbl hc
INNER join Insurance.ContractRules cr ON hc.healthPlanContractID =cr.healthPlanContractID 
WHERE cr.BenefitRuleDataId =@benefitRuleDataId



 INSERT INTO Insurance.ContractRules (BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,ModifyUser,CreateDate,ModifyDate,IsActive)
                               SELECT @benefitRuleDataId,hp.HealthPlanContractId,GETDATE(),'2099-12-31 00:00:00.000',@systemUser,@systemUser,getdate(),getdate(),1
FROM #healthPlnCntrctTbl HP
WHERE hp.IsActive =1 

 	COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH



