﻿
--     OTC SUPLY ORDERS QUERIES --------------

SELECT OrderId,MemberData,OrderAmountData,ShippingData FROM [ORDERS].[ORDERS] WHERE JSON_VALUE(OrderAmountData,'$.warehouseCode')='adi' 
AND orderType ='otc' ORDER BY CreateDate asc

SELECT top 10 * FROM [ORDERS].[ORDERS] WHERE JSON_VALUE(OrderAmountData,'$.warehouseCode')='ADT' AND JSON_VALUE(OrderAmountData,'$.isProcessedAsSupply')='false'
AND OrderStatusCode='ACK' ORDER BY ModifyDate asc

-- PERS JOB GET ORDERS FOR INSERT SUPLY ORDERS


 -- ORDERS FROM  OTC ORDERS.

SELECT  OrderId
                    FROM [ORDERS].[ORDERS]  
                    WHERE JSON_VALUE(OrderAmountData,'$.warehouseCode')='ADT'  AND  JSON_VALUE(OrderAmountData,'$.isProcessedAsSupply') IS  NULL
                    AND OrderStatusCode='ini' AND IsActive=1  
					
					-- suply orders orders inserts
DECLARE @OrderId BIGINT =200783800 
DECLARE @TotalAmount DECIMAL =32.50
DECLARE @OrderData NVARCHAR(MAX)   
  DECLARE @ItemData NVARCHAR(MAX)  
  DECLARE @systemUser VARCHAR(40)='systemUser'  
   DECLARE @memberData NVARCHAR(MAX) = (SELECT JSON_MODIFY(oo.MemberData,'$.insCarrierName',iic.insuranceCarrierName) FROM [ORDERS].[ORDERS] oo 
                                             INNER JOIN  insurance.insurancecarriers iic ON iic.InsuranceCarrierId =CAST(JSON_VALUE(oo.MemberData,'$.clientCarrierId')AS BIGINT)
											  WHERE oo.orderId=@orderId)
  SET @memberData = (SELECT JSON_MODIFY(@memberData,'$.insPlanName',iip.healthPlanName) FROM [ORDERS].[ORDERS] oo 
                                             INNER JOIN  insurance.insurancehealthplans iip ON iip.InsuranceHealthPlanId =CAST(JSON_VALUE(oo.MemberData,'$.clientPlanId')AS BIGINT)
											  WHERE oo.orderId=@orderId) 
DECLARE @orderAmountData NVARCHAR(MAX) ='{}'
SET @orderAmountData =(select JSON_MODIFY(@orderAmountData,'$.memberResponsibility',JSON_VALUE(orderAmountData,'$.outOfPocket')) FROM [ORDERS].[ORDERS] WHERE orderId =@orderId)
SET @orderAmountData =(select JSON_MODIFY(@orderAmountData,'$.productPrice',JSON_VALUE(orderAmountData,'$.price')) FROM [ORDERS].[ORDERS] WHERE orderId =@orderId)

SET @
SELECT @orderAmountData

DECLARE @orderAmountData NVARCHAR(MAX) 


INSERT INTO [SupplOrders].[ordershistory] 
	(OrderId
	,OrderDate
	,NHMemberId
	,InsuranceCarrierID
	,InsuranceHealthPlanID
	,ShippingAddress
	,Status
	,OrderType
	,Amount
	,CreateUser
	,CreateDate
	,ModifyUser
	,ModifyDate
	,IsActive
	,MemberData
	,OrderAmountData
	,OrderData
	,Action)
	
	SELECT 
	 OrderId 
	,GETDATE()
	,NHMemberId
	,InsuranceCarrierID
	,InsuranceHealthPlandID
	,ShippingAddress
	,Status
	,OrderType
    ,Amount 
	@systemUser AS CreateUser
	,GETDATE() AS CreateDate
	,@systemUser AS ModifyUser
	,GETDATE() AS ModifyDate
	,1
	,MemberData
	,OrderAmountData
    ,OrderData
	,'Updated on Status'
	FROM [SupplOrders].[Orders]	WHERE refOrderId =@OrderId 



											  
	  INNER JOIN insurance.insurancehealthplans iip ON iip.InsuranceHealthPlanId =CAST(JSON_VALUE(oo.MemberData,'$.clientPlanId')AS BIGINT)
 SELECT           
    GETDATE() AS OrderDate,        
    oo.NHMemberId                
   ,CAST(JSON_VALUE(oo.MemberData,'$.clientCarrierId')AS BIGINT)AS InsuranceCarrierID                 
   ,CAST(JSON_VALUE(oo.MemberData,'$.clientPlanId')AS BIGINT)AS InsuranceHealthPlanID                
   ,JSON_MODIFY(oo.ShippingData,'$.additionalShippingInfo',NULL) As ShippingAddress              
   ,'DOC_Pending' AS Status             
   ,'PERS' AS OrderType          
   ,(CAST(JSON_VALUE(oo.OrderAmountData,'$.amountCovered')AS DECIMAL(9,2))+CAST(JSON_VALUE(OrderAmountData,'$.outOfPocket') AS DECIMAL(9,2))) AS Amount               
   ,GETDATE() AS CreateDate    
   ,@systemUser AS CreateUser    
   ,@systemUser AS ModifyUser    
   ,GETDATE() AS ModifyDate    
   ,1 AS isActive    
   ,JSON_Modify(oo.MemberData,'$','"insCarrierName":'+iic.insuranceCarrierName +',"insPlanName":'+ iip.healthPlanName) AS MemberData 
   ,oo.OrderAmountData    
   ,@OrderData AS OrderData    
   ,oo.Source AS OrderSource    
   ,oo.OrderId AS RefOrderId    
  FROM [ORDERS].[ORDERS] oo    
      INNER JOIN  insurance.insurancecarriers iic ON iic.InsuranceCarrierId =CAST(JSON_VALUE(oo.MemberData,'$.clientCarrierId')AS BIGINT)
	  INNER JOIN insurance.insurancehealthplans iip ON iip.InsuranceHealthPlanId =CAST(JSON_VALUE(oo.MemberData,'$.clientPlanId')AS BIGINT)
  WHERE orderId =@OrderId 

  select top 1 *from insurance.insurancecarriers order by 1 desc
					----- SUPLY ORDERitEMS INSERTS
sp_helptext '[otc].[InsertPersSuplyOrdersFromOtcOrders]'
select top 100 *From   [ORDERS].[ORDERS]where orderId =200784041 --200783757
select top 100 *from [ORDERS].[ORDERITEMS] where orderId =200784025
SELECT  TOP 1 CAST(JSON_VALUE(MemberData,'$.clientCarrierId')AS BIGINT) 
   FROM [ORDERS].[ORDERS] where orderId =200783800 
   SELECT TOP 1 *FROM insurance.insurancehealthplans ORDER BY 1 DESC

select top 100 *from [SupplOrders].[Orders] where orderId =48581 45304 --48581 --45304
sp_helptext [SupplOrders].[sp_ManagePerOrders] 'pending'

select top 100 *From   [ORDERS].[ORDERS]where orderId =200784041 --200783757
select top 100 *from [ORDERS].[ORDERITEMS] where orderId =200784041

   select top  10  *From  [SupplOrders].[Orders]  order by 1 desc
  select top 2  *From  SupplOrders.ordershistory  order by 1 desc
   select top 2 *From [SupplOrders].[OrderItems]  order by 1 desc
     select top 2 *From  [SupplOrders].[DocumentTransaction] order by 1 desc  

	[SupplOrders].[sp_ManagePerOrders] 'all'
   DECLARE @insCarrierName NVARCHAR(MAX)  
  SELECT  @insCarrierName =  InsuranceCarrierName FROM insurance.insurancecarriers WHERE InsuranceCarrierId IN
   (SELECT  TOP 1 CAST(JSON_VALUE(MemberData,'$.clientCarrierId')AS BIGINT) 
   FROM [ORDERS].[ORDERS] where orderId =200783800 
   )
   select @insCarrierName
   DECLARE @insPlanName NVARCHAR(MAX) =
   SE
   SELECT * FROM  [SupplOrders].[Orders]  WHERE RefOrderId = 200783800
   SELECT * FROM  [SupplOrders].[Orders] WHERE refOrderId =[ORDERS].[ORDERS]
     SELECT TOP 10  * FROM  [SupplOrders].[Orders]  ORDER BY 1 DESC
   [otc].[InsertPersSuplyOrdersFromOtcOrders] 200784041  

   DECLARE @orderId bigint =200784106
   200784106
   200784161
  
   update  [SupplOrders].[Orders] set RefOrderId =null
   WHERE refOrderId =@orderId 
    update  [SupplOrders].[Orders] set IsActive =1
   WHERE refOrderId =@orderId 


   UPDATE [ORDERS].[ORDERS] SET OrderAmountData = JSON_MODIFY(OrderAmountData,'$.isProcessedAsSupply',null) WHERE ORDERID = @orderId

   UPDATE [ORDERS].[ORDERS] SET OrderStatusCode ='ini',IsActive =1 WHERE ORDERID = @orderId
     --UPDATE [ORDERS].[ORDERS]  set IsActive =1 WHERE ORDERID = @orderId
	  
SELECT TOP 1 * from [SupplOrders].[Orders] where orderId =200783814  order by 1 desc
SELECT TOP 4 * from  [SupplOrders].[OrderItems] where orderId =200783814  order by 1 desc


 


 sp_helptext '[otc].[ReturnLoginAuthenticationResponse_09Nov]'
 DECLARE @orderId bigint =200784041
  DECLARE @systemUser VARCHAR(40)='systemUser'  
--DROP TABLE IF EXISTS #orderItemsForsuplyOrderItems 
 SELECT       
   (SELECT orderId FROM  [SupplOrders].[Orders] WHERE refOrderId =@OrderId ) AS OrderId      
  ,im.itemCode      
  ,im.itemType      
  ,oi.amount AS Price      
  ,oi.Quantity      
  ,@systemUser AS CreateUser      
  ,GETDATE() AS CreateDate      
  ,@systemUser AS ModifyUser      
  ,GETDATE()AS ModifyDate      
  ,1 AS isActive      
  ,('{"itemName":"'+ im.itemDisplayName +'"}')as  ItemData      
   FROM [ORDERS].[ORDERITEMS] oi INNER JOIN [ORDERS].[ORDERS] oo ON oo.orderId=oi.orderId       
  INNER JOIN [SupplOrders].[ItemMaster] im ON  JSON_VALUE(oi.ItemData,'$.nationsId')  = JSON_VALUE(im.ItemAdditionalData,'$.nationsId')      
  WHERE  oo.orderId =@OrderId AND JSON_VALUE(oo.OrderAmountData,'$.warehouseCode')='ADT'        
  AND JSON_VALUE(oo.OrderAmountData,'$.isProcessedAsSupply') IS  NULL       
  AND oo.OrderStatusCode='INI' AND oo.IsActive =1  AND oi.IsActive=1 AND  im.IsActive=1      
  order by oo.orderId asc      
      
select  * from #orderItemsForsuplyOrderItems ORDER BY orderId asc
select top 10 *From  [SupplOrders].[ItemMaster] where ItemAdditionalData is not null  order by 1 desc
--select top 100 *From   [ORDERS].[ORDERS]where orderId =200784041 --200783757
select top 100 *from [ORDERS].[ORDERITEMS] where orderId =200784041

INSERT INTO [SupplOrders].[OrderItems] (OrderId,ItemCode,ItemType,Price,Quantity,CreateUser,CreateDate,ModifyUser,ModifyDate,IsActive,ItemData)

SELECT TOP 2  orderId,itemCode,itemType,amount,quantity,'systemUser' AS CreateUser,GETDATE() AS CreateDate,'systemUser'AS ModifyUser,GETDATE()AS ModifyDate,1,itemData FROM   #orderItemsForsuplyOrderItems
order by orderId asc



INSERT INTO 
[SupplOrders].[ordershistory] 
(OrderId
,OrderDate
,NHMemberId
,InsuranceCarreriID
,InsuranceHealthPlandID
,ShippingAddress
,Status
,OrderType
,Amount
,CreateUser
,CreateDate
,ModifyUser
,ModifyDate
,IsActive
,MemberData
,OrderAmountData
,OrderData
,Action)

VALUES(

)


select  *From [SupplOrders].[ItemMaster] im  where itemType like '%pers%'order by 1 desc
SELECT TOP 1 JSON_VALUE(OrderAmountData)
-- INSERTS   

select *From   [ORDERS].[ORDERS]  where orderId =200802431 --200783757

UPDATE [ORDERS].[ORDERS] SET IsActive =0
where orderId =200802431
select *from [ORDERS].[ORDERITEMS] where orderId =200802431   
SELECT TOP 10 * FROM  [SupplOrders].[Orders]   where NHMemberId = 'NH202107379379' order by 1 desc    --orderType= 'pers' order by 1 desc   200802431 
 SELECT TOP 10 * FROM  [SupplOrders].[OrderItems]  order by createdate desc
SELECT TOP 10 * FROM[SupplOrders].[DocumentTransaction] order by 1 desc
SELECT TOP 10 * FROM [SupplOrders].[ordershistory] where NHMemberId = 'NH202107379379' order by 1 desc
select top 10 * from otc.UserProfiles where NHMemberId = 'NH202107379379'
select * from Orders.Orders 

SELECT TOP 10 * FROM  [SupplOrders].[Orders] where orderId =49689
SELECT TOP 10 * FROM [SupplOrders].[ordershistory] where orderId =49689 order by 1 desc

SELECT TOP 1 * FROM  [SupplOrders].[Orders]   where NHMemberId = 'NH202107379379' order by 1 desc   --200802438

SELECT TOP 100 *FROM  [SupplOrders].[Orders] WHERE STATUS  LIKE '%Approval%'
SP_HELPTEXT  '[SupplOrders].[sp_ManagePerOrders]' 'pending'

 UPDATE [SupplOrders].[Orders] SET Status ='Approval' WHERE OrderId =49714
 UPDATE [SupplOrders].[ordershistory] SET Status ='Approval' WHERE OrderId =49714
  

where NHMemberId='NH202107354635' order by 1 desc

UPDATE  [SupplOrders].[Orders]  ISACTIVE =0
WHERE ORDERiD IN()



 select top 1 *From  [ORDERS].[ORDERS] where orderId =200783766 order by 1 desc
   select top 1 *From  [SupplOrders].[DocumentTransaction] order by 1 desc
   select top 10 *From  [SupplOrders].[Orders]  order by 1 desc
   select top 2 *From [SupplOrders].[OrderItems]  order by 1 desc

   select top 2 *From  SupplOrders.ordershistory ORDER BY 1 DESC
   
--delete from [SupplOrders].[Orders] where orderid =48542
--delete from [SupplOrders].[OrderItems]  where orderid =48542

INSERT INTO [SupplOrders].[Orders]
	(OrderDate,NHMemberId,InsuranceCarreriID,InsuranceHealthPlanID,ShippedDate,ShippingAddress,Status,OrderType,Amount,CreateDate,CreateUser,ModifyUser,ModifyDate,IsActive,RemarksData) 
	VALUES()

UPDATE  [SupplOrders].[DocumentTransaction]
SET orderId =@orderId
WHERE DocumentId =

DECLARE @contactDetails nvarchar(max)='
			{
				"firstName": "eonmember1",
				"relationshipToMember": "Daughter1",
				"keyHolder": "Yes",
				"phoneNbr": "917-747-6169"
			}'
update  Orders.Orders
set ShippingData =JSON_MODIFY(ShippingData,'append $.additionalShippingInfo.emegencyContactsDetails',JSON_QUERY(@contactDetails))

WHERE ORDERiD =200783798



DECLARE @OrderData NVARCHAR(MAX)
DECLARE @ShippingData NVARCHAR(MAX) ='{"additionalShippingInfo": {
		"userInfo": {
			"douHaveATService": "Yes",
			"douHaveADTPERSDevice": "",
			"douWantToSwitchExistingDevice": "",
			"lifestyleHome": "5-7x per week",
			"lifestyleAloneOrPpl": "Senior Community",
			"activeLifestyle": "No",
			"exercise": "5-7x per week",
			"lifestyleFallen": "Yes"
		},
		"emegencyContactsDetails": [
			{
				"firstName": "Dignity️️",
				"relationshipToMember": "Domestic Partner",
				"keyHolder": "Yes",
				"phoneNbr": "917-747-6169"
			},
			{
				"firstName": "eonmember1",
				"relationshipToMember": "Daughter1",
				"keyHolder": "Yes",
				"phoneNbr": "917-747-6169"
			}
		]
	}}'
set @OrderData =(SELECT JSON_QUERY(@ShippingData,'$.additionalShippingInfo.userInfo')  )
select @OrderData


  SET @OrderData= JSON_MODIFY(@OrderData,'$.emergencyContactsDetails ',  (SELECT JSON_QUERY(@ShippingData,'$.additionalShippingInfo.emegencyContactsDetails')))
  select @OrderData


select * from Orders.Orders WHERE ORDERiD =200783798
where NHMemberId='NH202107354397'

select top 20 * from [SupplOrders].[Orders] WHERE ORDERTYPE = 'PERS'

 select top 20 JSON_QUERY(OrderData,'$.emergencyContact') from [SupplOrders].[Orders] WHERE orderid =573

select top 20 * from insurance.InsuranceConfig where insuranceCarrierId =7      healthplandID 14


select * from SupplOrders.ItemMaster
where ItemType like '%Pers%'

select top 10  * from SupplOrders.ItemMaster where JSON_VALUE(ItemAdditionalData,'$.nationsId')='8023' 

UPDATE  SupplOrders.ItemMaster SET ItemAdditionalData =JSON_MODIFY(ItemAdditionalData,'$.nationsId','8023' )  WHERE ItemMasterId =35


SELECT *FROM [ORDERS].[ORDERS] WHERE ORDERID =200783767    and JSON_VALUE(OrderAmountData,'$.documentId')='false'    --200783757
and JSON_VALUE(OrderAmountData,'$.warehouseCode')='ADT'

SELECT top 10 *FROM [ORDERS].[ORDERITEMS] WHERE ORDERID = 200783767  --200783757

UPDATE [ORDERS].[ORDERS] SET OrderAmountData = JSON_MODIFY(OrderAmountData,'$.documentId',135) WHERE ORDERID = 200783767


UPDATE [ORDERS].[ORDERS] SET OrderStatusCode = 'INI' WHERE ORDERID in (200783767,200783757)

----
--order items nations id update for suply itm master forpers

UPDATE [ORDERS].[ORDERITEMS] SET ItemData = JSON_MODIFY(ItemData,'$.nationsId','8023') WHERE OrderItemId = 4658242




               SELECT TOP 10   * FROM  SupplOrders.ItemMaster 

SELECT TOP 10   * FROM [ORDERS].[ORDERITEMS]  where orderId =200443403  ORDER BY 1 DESC
INSERT INTO 

select TOP 1 * from [SupplOrders].[Orders]  ORDER BY 1 DESC


SELECT * FROM [jobs].[PageActionProcessQueue] 
                    WHERE [jobs].[PageActionProcessQueue].[IsActive] = 1 
                    AND [jobs].[PageActionProcessQueue].[ActionCode] IN ('OTCOrders') 
                    AND [jobs].[PageActionProcessQueue].[IsContinuous] = 

					INSERT INTO [jobs].[PageActionProcessQueue]  (ActionCode,ProcessStatus,IsActive,CreateDate,CreateUser,ModifyDate,ModifyUser,IsContinuous)
					VALUES ('SpmOrders',0,1,GETDATE(),'System',GETDATE(),'System',1)

					SELECT  *FROM jobs.Actions WHERE ActionCode='SpmOrders'
					SELECT * FROM [jobs].[PageActionProcessQueue]  WHERE ActionCode='SpmOrders'

					INSERT INTO [jobs].[Actions] (ActionName,ActionCode,CreateDate,CreateUser,ModifyDate,ModifyUser)
					 VALUES('GET OTC pers orders process to suplyOrders tables',GETDATE(),'System',GETDATE(),'System')


					 DELETE FROM jobs.Actions WHERE ActionCode='SpmOrders'
					 DELETE FROM [jobs].[PageActionProcessQueue]  WHERE ActionCode='SpmOrders'


					 update [Master].[MemberInsuranceDetails] set OTCSerialNumber='0059139500797' where insurancenbr='34563465'
update [provider].[MemberInsuranceDetails] set OTCSerialNumber='0059139500797' where insurancenbr='34563465'


update provider.MemberInsuranceDetails set OTCSerialNumber = '0242312452313' where InsuranceNBR = 'testjmolinaone'

sp_helptext '[SupplOrders].[sp_GetPersEligibleInsurances]'