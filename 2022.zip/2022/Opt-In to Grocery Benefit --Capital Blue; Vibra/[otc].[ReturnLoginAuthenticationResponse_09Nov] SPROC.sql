  
            
            
            
-- Returning correct config based on Client Plan Id returned from authentication procedures (Plan level config issue fix)            
-- exec [otc].[ReturnLoginAuthenticationResponse]  'alignment','{"CardNumber": "6102812311017894038", "SerialNumber": "2434"}','NH202005647599' --            
--'NH202005647510'            
            
/*            
Modified By: Satish Kumar Lakkimsetti            
Modified Date: 20/04/2021            
Comments: Get Only active healthconditins from MemberHealthConditions            
*/            
            
-- =============================================            
-- Modified By: Harika Bommareddy            
-- Modified Date: 03/2/2021            
--Comments: Added condition to get Effective Insurance health plan id.            
-- =============================================       
-- Modified By : Naresh Naspoori  
-- Modified Date: 10-Nov-2021    
--Comments: Added benefitRequest to get Opt-in wallets requests.      
            
CREATE OR ALTER PROCEDURE [otc].[ReturnLoginAuthenticationResponse] (            
 -- Add the parameters for the stored procedure here            
  @domain VARCHAR(100)            
 ,@envelopJson VARCHAR(2000)            
 ,@nhMemberId VARCHAR(100)            
)            
AS            
BEGIN            
 -- Global Variables             
 BEGIN            
  DECLARE @InsuranceCarrierID BIGINT            
  DECLARE @InsuranceHealthPlanID BIGINT            
  DECLARE @Status VARCHAR(100)            
  DECLARE @StatusNotEnabled VARCHAR(100) = 'NotEnabled'            
  DECLARE @StatusLoginEnabled VARCHAR(100) = 'LoginEnabled'            
  DECLARE @StatusRedirect VARCHAR(100) = 'Redirect'            
  DECLARE @StatusMessage VARCHAR(1000)            
  DECLARE @CarrierConfig VARCHAR(2000)            
  DECLARE @otcContentConfig VARCHAR(2000)            
  DECLARE @otcLoginConfig VARCHAR(2000)            
  DECLARE @otcAppConfig VARCHAR(2000)            
  DECLARE @fieldValidationConfig VARCHAR(2000)            
  DECLARE @fieldname VARCHAR(1000)            
  DECLARE @LoginTemplate VARCHAR(500)            
  DECLARE @MemberId BIGINT --refering master schema            
  DECLARE @cardNumber NVARCHAR(50)            
  DECLARE @msg51500 BIGINT = 51500 --errorStatus code for any exception occure while excuting            
  DECLARE @errorMsg NVARCHAR(1000)            
  DECLARE @errorSeverity INT            
  DECLARE @insuranceNbr NVARCHAR(100)            
  DECLARE @clientPlanId BIGINT            
  DECLARE @programCode NVARCHAR(100)             
  DECLARE @serialNumber NVARCHAR(100)            
  DECLARE @groupNo varchar(50)            
  DECLARE @healthPlanCode varchar(50)      
    
  
 END            
 PRINT @nhMemberId            
 PRINT '--------------'            
 SET @StatusMessage = NULL;            
 SET @clientPlanId = JSON_VALUE(@envelopJson, '$.PlanId')            
 SET @cardNumber = JSON_VALUE(@envelopJson, '$.CardNumber')            
 SET @insuranceNbr = JSON_VALUE(@envelopJson, '$.InsuranceNumber')            
 SET @programCode =JSON_VALUE(@envelopJson, '$.ProgramCode')            
 SET @serialNumber = JSON_VALUE(@envelopJson, '$.SerialNumber')            
 SET @groupNo  =JSON_VALUE(@envelopJson,'$.GroupNo')            
 SET @healthPlanCode =JSON_VALUE(@envelopJson,'$.HealthPlanCode')            
 BEGIN TRY            
  -- Extract Configs by using domain             
  BEGIN            
   --Make empty as NULL            
            
   IF(@clientPlanId=0)SET @clientPlanId=NULL            
   IF(LEN(ISNULL(@groupNo,''))=0) SET @groupNo=NULL            
   IF(LEN(ISNULL(@healthPlanCode,''))=0) SET @healthPlanCode=NULL            
            
               
   SELECT TOP 1 @InsuranceCarrierID = InsuranceCarrierID            
   FROM Insurance.InsuranceCarriers            
   WHERE IsActive = 1            
    AND JSON_VALUE(CarrierConfig, '$.subdomain') = @domain            
   ORDER BY InsuranceCarrierId            
               
   PRINT CONCAT('@clientCarrId', @InsuranceCarrierID)      
   PRINT CONCAT('@clientPlanId', @clientPlanId)            
            
  END            
            
  -- SSO FLOWS             
  BEGIN            
            
   SET @otcLoginConfig = (            
        SELECT TOP 1 ConfigData            
        FROM Insurance.InsuranceConfig            
        WHERE IsActive = 1            
         AND InsuranceCarrierID = @InsuranceCarrierID             
         AND InsuranceHealthPlanId IS NULL            
         AND ConfigType = 'OTCLOGIN'            
        ORDER BY InsuranceHealthPlanId DESC            
       );            
            
   DECLARE @benefitSource NVARCHAR(40) = json_value(@otcLoginConfig, '$.benefitValueSource');            
   DECLARE @isManaged BIT = Cast(json_value(@otcLoginConfig, '$.isManaged') AS BIT)            
               
   DECLARE @otcCarrierId BIGINT = (            
     SELECT TOP 1 InsuranceCarrierID            
     FROM Insurance.InsuranceCarriers            
     WHERE IsActive = 1            
      AND JSON_VALUE(CarrierConfig, '$.subdomain') = 'otcnetwork'            
     )            
   DECLARE @otcPlanId BIGINT = (            
     SELECT TOP 1 InsuranceHealthPlanID            
     FROM Insurance.InsuranceHealthPlans            
     WHERE IsActive = 1            
      AND InsuranceCarrierID = @otcCarrierId            
      AND PlanConfigData IS NULL            
     )            
            
               
   --Updating Client CarrierId             
   IF(@cardNumber IS NOT NULL AND (@programCode IS NOT NULL OR @InsuranceCarrierID <> @otcCarrierId))            
   BEGIN            
    UPDATE otc.Cards            
      SET ClientCarrierId=@InsuranceCarrierID            
      ,ProgramCode=@programCode            
      ,ModifyDate = getdate()            
      ,ModifyUser = 'script'            
      WHERE CardNumber = @cardNumber            
      AND ClientCarrierId IS  NULL            
   END            
            
   IF (@nhMemberId IS NOT NULL)            
   BEGIN            
    SELECT @MemberId = MemberId            
    FROM master.Members            
    WHERE NHMemberId = @nhMemberId AND IsActive=1            
            
    PRINT concat('@NHMemberId - ', @nhMemberId)            
    PRINT concat('@MemberId - ', @MemberId)            
    PRINT concat('@InsuranceNbr - ', @insuranceNbr)            
    PRINT concat('@@benefitSource - ', @benefitSource)            
    PRINT concat('@@isManaged - ', @isManaged)            
    PRINT concat('@@otcCarrierId - ', @otcCarrierId)            
    PRINT concat('@@InsuranceCarrierID - ', @InsuranceCarrierID)            
                
           -- NARESH NASPOORI  get wallets prompt indicator requests purpose moved query data to temp table.  
            
     DROP TABLE IF EXISTS #queryTempTbl_1;            
      
 SELECT *INTO #queryTempTbl_1 FROM (SELECT (            
       SELECT TOP 1 ConfigData            
       FROM Insurance.InsuranceConfig            
       WHERE IsActive = 1            
        AND InsuranceCarrierID = @InsuranceCarrierID             
        AND (InsuranceHealthPlanId=ISNULL(@clientPlanId,0) OR ISNULL(InsuranceHealthPlanId,0)=0)            
        AND ConfigType = 'OTCLOGIN'            
       ORDER BY InsuranceHealthPlanId DESC            
      ) AS otcLoginConfig            
      ,(            
       SELECT TOP 1 ConfigData            
       FROM Insurance.InsuranceConfig            
       WHERE IsActive = 1            
        AND InsuranceCarrierID = @InsuranceCarrierID             
        AND (InsuranceHealthPlanId=ISNULL(@clientPlanId,0) OR ISNULL(InsuranceHealthPlanId,0)=0)            
        AND ConfigType = 'OTCAPP'            
       ORDER BY InsuranceHealthPlanId DESC            
      ) AS otcAppConfig            
      ,(            
       SELECT @insuranceNbr AS MemberId            
        ,m.NHMemberId            
        ,@cardNumber AS CardNumber            
        ,JSON_VALUE(@envelopJson, '$.SerialNumber') AS SerialNumber            
        ,(            
         CASE             
       WHEN pm.FirstName IS NULL            
           THEN m.FirstName            
          ELSE pm.FirstName            
          END            
         ) AS FirstName            
        ,(            
         CASE             
          WHEN pm.LastName IS NULL            
           THEN m.LastName            
          ELSE pm.LastName            
          END            
         ) AS LastName            
        ,cast((            
          CASE             
           WHEN pm.DateOfBirth IS NULL            
            THEN m.DateOfBirth            
           ELSE pm.DateOfBirth            
           END            
          ) AS DATE) AS DateOfBirth            
       FROM master.Members m            
       LEFT JOIN PROVIDER.MEMBERPROFILES pm ON pm.NHMemberId = m.NHMemberId            
        AND pm.IsActive = 1            
       WHERE m.IsActive = 1            
        AND m.MemberId = @MemberId            
       FOR JSON PATH            
        ,WITHOUT_ARRAY_WRAPPER            
       ) AS memberInfo            
       ,(            
       SELECT TOP 1 @InsuranceNbr AS MemberId            
      ,(            
         CASE             
          WHEN @benefitSource = 'incomm' or @benefitSource='visa' or @benefitSource='wex'              
           THEN @otcCarrierId            
          ELSE mi.InsuranceCarrierID            
          END            
         ) AS InsuranceCarrierID            
        ,(            
         CASE             
          WHEN @benefitSource = 'incomm' or @benefitSource='visa' or @benefitSource='wex'              
     THEN @otcPlanId            
          ELSE mi.InsuranceHealthPlanID            
          END            
         ) AS InsuranceHealthPlanID            
        ,InsuranceEffectiveDate            
        ,@InsuranceCarrierID AS ClientCarrierId -- Added by suneetha            
        ,(            
         CASE            
          WHEN @clientPlanId IS NOT NULL THEN @clientPlanId            
          WHEN (@benefitSource = 'incomm' or @benefitSource='visa' or @benefitSource='wex')  AND @isManaged = 0 THEN NULL            
          ELSE mi.InsuranceHealthPlanID            
         END            
        ) AS ClientPlanId -- Added by suneetha        
    ,mi.SSBCIIndicator        
       FROM [Master].[MemberInsurances] mi            
       INNER JOIN [Master].[MemberInsuranceDetails] mid ON mi.ID = mid.MemberInsuranceID            
        AND mid.IsActive = 1            
        AND (            
         @insuranceNbr IS NULL            
         OR @insuranceNbr = mid.InsuranceNbr            
         )            
       WHERE mi.IsActive = 1            
        AND MemberId = @MemberId            
        AND InsuranceType IN (            
         'primary'            
         ,'discount'            
         )            
        AND mi.insurancecarrierId IN (            
         CASE             
          WHEN ( @benefitSource = 'incomm' or @benefitSource='visa' or @benefitSource='wex')            
           AND @isManaged = 0            
           THEN @otcCarrierId            
          ELSE @InsuranceCarrierID            
          END            
         )            
                            AND (@clientPlanId IS NULL OR mi.InsuranceHealthPlanID = @clientPlanId)  --Added by Harika - 03/02/2021            
       --AND GETDATE() BETWEEN InsuranceEffectiveDate            
       -- AND InsuranceEndDate              
       ORDER BY InsuranceEndDate DESC            
       FOR JSON PATH            
        ,WITHOUT_ARRAY_WRAPPER            
       ) AS insuranceInfo            
      ,(            
       SELECT distinct CONCAT('[',STRING_AGG( CONCAT('"', md.Category,'"'),','),']')            
       FROM [otc].[MemberDiseaseStates] md            
       INNER JOIN healthcare.ICD10Categories cat ON cat.Category=md.Category AND cat.IsActive=1 --Inner Join Added by Satish Kumar Lakkimsetti on 19th April 2021            
        WHERE md.IsActive = 1 AND md.NHMemberId = @nhMemberId            
       ) AS memberHealthProfile            
      ,(            
       SELECT MemberId            
        ,Address1            
        ,Address2            
        ,City            
        ,STATE            
        ,ZipCode            
       FROM [Master].[Addresses]            
       WHERE IsActive = 1            
        AND MemberId = @MemberId            
       FOR JSON PATH            
       ) memberAddress            
      ,NULL AS benefits            
      ,          
   --[Mohan 9/13] Handing Null - Begin          
    ISNULL(          
   (            
       SELECT TOP 1 CAST((            
          CASE             
           WHEN GETDATE() BETWEEN InsuranceEffectiveDate            
             AND InsuranceEndDate            
            THEN 1            
           ELSE 0            
           END            
          ) AS BIT)            
       FROM [Master].[MemberInsurances] mi          
       INNER JOIN [Master].[MemberInsuranceDetails] mid ON mi.ID = mid.MemberInsuranceID            
        AND mid.IsActive = 1            
        AND (            
         @insuranceNbr IS NULL            
         OR @insuranceNbr = mid.InsuranceNbr            
         )            
       WHERE mi.IsActive = 1            
        AND MemberId = @MemberId            
        AND InsuranceType IN (            
         'primary'            
         ,'discount'            
         )            
        AND insurancecarrierId IN (            
         CASE             
          WHEN (@benefitSource = 'incomm' or @benefitSource='visa' or @benefitSource='wex')            
           AND @isManaged = 0            
           THEN @otcCarrierId            
          ELSE @InsuranceCarrierID            
          END            
         )            
         -- below line added 2021/1/29            
        and (@clientPlanId is null or InsuranceHealthPlanID = @clientPlanId)            
       ORDER BY InsuranceEndDate DESC            
    )          
    --[Mohan 9/13] Handing Null - End          
    ,cast(0 as BIT))          
    AS isAccountActive            
       , @envelopJson as envelop    
    )t  
  
     -- NARESH NASPOORI get wallets prompt indicator requests   
    SELECT *,   
    (SELECT  requestId,JSON_VALUE(RequestData,'$.walletCode')AS walletCode ,isProcessed, ISNULL(UserPromptIndicator,0)AS userPromptIndicator,createDate  FROM [benefitcard].[changeRequest]   
    WHERE InsuranceCarrierID = CAST (JSON_VALUE(qt.insuranceInfo,'$.InsuranceCarrierID')AS BIGINT) AND InsuranceHealthPlanId = CAST (JSON_VALUE(qt.insuranceInfo,'$.InsuranceHealthPlanID')AS BIGINT)  
    AND NHMemberId =JSON_VALUE(qt.memberInfo,'$.NHMemberId') AND isActive =1 FOR JSON PATH )as benefitRequest   
    FROM  #queryTempTbl_1 qt      
  
   END            
   ELSE --return if member not yet register             
   BEGIN            
 DECLARE @memberDetails NVARCHAR(2000) = NULL            
            
    IF (@envelopJson IS NOT NULL)            
    BEGIN            
     SET @memberDetails = JSON_MODIFY(ISNULL(@memberDetails, '{}'), '$.FirstName', JSON_VALUE(@envelopJson, '$.MemberFirstName'));            
     SET @memberDetails = JSON_MODIFY(@memberDetails, '$.LastName', JSON_VALUE(@envelopJson, '$.MemberLastName'));            
     SET @memberDetails = JSON_MODIFY(@memberDetails, '$.DateOfBirth', JSON_VALUE(@envelopJson, '$.MemberDOB'));            
     SET @memberDetails = JSON_MODIFY(@memberDetails, '$.CardNumber', @cardNumber);            
     SET @memberDetails = JSON_MODIFY(@memberDetails, '$.SerialNumber', JSON_VALUE(@envelopJson, '$.SerialNumber'));            
     SET @memberDetails = JSON_MODIFY(@memberDetails, '$.MemberId', @InsuranceNbr);            
    END      
   
 -- NARESH NASPOORI  get wallets prompt indicator requests purpose moved query data to temp table.  
     DROP TABLE IF EXISTS #queryTempTbl_2;  
  
  SELECT *INTO #queryTempTbl_2 FROM (    
  
    SELECT @otcLoginConfig AS otcLoginConfig            
     ,@otcAppConfig AS otcAppConfig            
     ,@memberDetails AS memberInfo           
     ,(            
      SELECT @otcCarrierId AS InsuranceCarrierID            
       ,@otcPlanId AS InsuranceHealthPlanID            
       ,@InsuranceCarrierID AS ClientCarrierId -- Added by suneetha            
       ,@clientPlanId AS ClientPlanId -- Added by suneetha            
      FOR JSON PATH            
       ,WITHOUT_ARRAY_WRAPPER            
      ) insuranceInfo            
     ,NULL AS memberHealthProfile            
     ,NULL AS memberAddress            
     ,NULL AS benefits            
     ,CAST(1 AS BIT) AS isAccountActive            
     ,@envelopJson as envelop    
  ) tt  
          
    
   -- NARESH NASPOORI grocery benefits join  
    SELECT *,   
    (SELECT requestId, JSON_VALUE(RequestData,'$.walletCode')AS walletCode,isProcessed, ISNULL(UserPromptIndicator,0)AS userPromptIndicator,createDate FROM [benefitcard].[changeRequest]   
    WHERE InsuranceCarrierID = CAST (JSON_VALUE(otctt.insuranceInfo,'$.InsuranceCarrierID')AS BIGINT) AND InsuranceHealthPlanId = CAST (JSON_VALUE(otctt.insuranceInfo,'$.InsuranceHealthPlanID')AS BIGINT)  
    AND NHMemberId =JSON_VALUE(otctt.memberInfo,'$.NHMemberId') AND isActive =1 FOR JSON PATH )as benefitRequest   
    From  #queryTempTbl_2 otctt  
  
   END            
  END            
 END TRY            
            
 BEGIN CATCH    SELECT @errorMsg = ERROR_MESSAGE()            
   ,@errorSeverity = ERROR_SEVERITY();            
            
  THROW @msg51500            
   ,@errorMsg            
   ,@errorSeverity            
 END CATCH            
END   