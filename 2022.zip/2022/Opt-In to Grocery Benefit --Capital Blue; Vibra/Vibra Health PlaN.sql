-- 'Vibra Health PlaN

DECLARE @otcLoginConfig NVARCHAR(MAX) ='{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"allowAgentAccess":false,"benefitValueSource":"fis","loginTemplate":"OTCFlexStandard","ReplaceWallets":[],"AddWallets":[],"MapWallets":{"02":"GROCERYBENEFITS"},"tags":[]}'
DECLARE @OTCAPP VARCHAR(50) ='OTCLOGIN'
DECLARE @carrierId BIGINT
DECLARE @carrierName NVARCHAR(100)='Vibra Health Plan'
DECLARE @systemUser VARCHAR(100)='scripts';
DECLARE @otcContent NVARCHAR(MAX) ='{"phone":"877-240-8232","showOTCGuidelines":false}'
DECLARE @otcConfigType  NVARCHAR(MAX)  ='OTCCONTENT'
DECLARE @ClientConfigData nvarchar(max)='{"ClientID": "644963","SubProgID": "797605"}'
DECLARE @FISCONFIGURATION nvarchar(max) ='FISCONFIGURATION'
SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 


IF EXISTS (select *From  insurance.insuranceConfig WHERE  InsuranceCarrierId =@carrierId AND configType ='OTCLOGIN' AND  ISNULL(JSON_VALUE(ConfigData,'$.splashTemplate'),'')!=''  AND IsActive=1 )
BEGIN
	--UPDATE insurance.insuranceConfig SET IsActive =0
	--WHERE  InsuranceCarrierId =@carrierId AND configType ='OTCLOGIN' AND  ISNULL(JSON_VALUE(ConfigData,'$.splashTemplate'),'')!='' 

	--INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
	--VALUES (@OTCAPP,@otcLoginConfig,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1)
	
	SELECT *FROM  Insurance.insuranceconfig where   InsuranceCarrierId =@carrierId AND configType ='OTCLOGIN' AND isActive =1 order by 1 desc
END


--IF EXISTS (select  *From  insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType ='CARRIERCONFIG' AND IsActive=1 order by 1 desc)
-- BEGIN
      --UPDATE insurance.insuranceConfig SET configData =JSON_MODIFY(configData,'append  $.benefitTypes','OTC') 
	 -- WHERE   InsuranceCarrierId =@carrierId AND configType ='CARRIERCONFIG'  AND IsActive =1 AND ModifyDate =GETDATE()
 --END

 
-- select  *From  insurance.insuranceConfig where     InsuranceCarrierId =267 AND configType ='CARRIERCONFIG' AND JSON_VALUE(ConfigData,'$.benefitTypes[1]') ='OTC' order by 1 desc
			select  *From  insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType ='OTCCONTENT' AND IsActive=1 order by 1 desc


--IF NOT EXISTS (select  *From  insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType ='OTCCONTENT' AND IsActive=1)
-- BEGIN
--       INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
--		VALUES (@otcConfigType,@otcContent,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1)
-- END
--ELSE 
-- BEGIN
--      - UPDATE Insurance.insuranceconfig SET ConfigData =JSON_MODIFY(ConfigData,'$.phone','877-240-8232') where InsuranceCarrierId =@carrierId AND configType =@otcConfigType AND IsActive=1 
-- END
select  *From  insurance.insuranceConfig where InsuranceCarrierId =@carrierId 
	
--IF NOT EXISTS (select  *From  insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType =@FISCONFIGURATION AND IsActive=1)	
--BEGIN
--       INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
--	   VALUES (@FISCONFIGURATION,@ClientConfigData,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1)
--END

	
		--UPDATE  Insurance.insuranceconfig SET  ConfigData =@ConfigData where InsuranceCarrierID =271  and ConfigType ='FISCONFIGURATION'



  select  *from insurance.insurancehealthplans where InsuranceCarrierId =267 order by 1 desc 

  -- 2467 Capital Blue Cross

 
 -- ======================> HealthPlanContracts <==============================================
 DECLARE @healthPlanName NVARCHAR(MAX)= (SELECT healthPlanName From  insurance.insurancehealthplans where InsuranceHealthPlanID =2593)
 SELECT @healthPlanName
  DECLARE @EffectivetToDate NVARCHAR(MAX) ='2099-12-31 00:00:00.000'
 DECLARE @insuranceHealthPlanId BIGINT =2593


   --INSERT INTO Insurance.HealthPlanContracts (ContractName,Description,EffectiveFromDate,EffectiveToDate,InsuranceCarrierID,InsuranceHealthPlanID,IsActive,ModifyDate,ModifyUser,CreateDate,CreateUser)
	--	 VALUES(@healthPlanName,@healthPlanName,GETDATE(),@EffectivetToDate,@carrierId,@insuranceHealthPlanId,1,GETDATE(),@systemUser,GETDATE(),@systemUser)
		
		select top 10  *from Insurance.HealthPlanContracts   where InsuranceCarrierId =267 and InsuranceHealthPlanID =2593 order by 1 desc

		
		-- wallets

		
		SELECT  TOP 20 * FROM otccatalog.Wallets    where walletId in (60,61)
		SELECT * FROM otccatalog.WalletPlans where InsuranceCarrierId =271 
		
		INSERT INTO otccatalog.WalletPlans (InsuranceCarrierId,insuranceHealthPlanId,WalletId,IsActive,CreateUser,CreateDate,ModifyDate,ModifyUser,EffectiveFrom )
values(@carrierId,2593 ,149,1,'systemUser',getdate(),getdate(),'systemUser',GETDATE())     

 UPDATE otccatalog.WalletPlans
 SET walletStandardData ='[13]'
 WHERE InsuranceHealthPlanID =2593 AND InsuranceCarrierID =267



--INSERT INTO otccatalog.Wallets  (walletName,DisplayOrder,ShowonWeb,WalletCode,WalletSource,DisplayWalletName,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate,ColorCode,EffectiveDate,BenefitSpendingType)
--VALUES('GROCERYBENEFITS',1,1,'GROCERYBENEFITS','FIS','GROCERYBENEFITS',1,'systemUser',getdate(),'systemUser',getdate(),'#08E8DE',getdate(),'GROCERY')



		SELECT  TOP 20 * FROM otccatalog.Wallets order by 1 desc

		select top 10 *from rulesengine.BenefitRulesData order by 1 desc  --275

		 select top 10 *From otccatalog.WalletPlans where  InsuranceCarrierID =267
 
 select top 10 *From otccatalog.WalletPlans where  InsuranceHealthPlanID =2593 AND InsuranceCarrierID =267

 UPDATE otccatalog.WalletPlans set BenefitValueSource='fis' where WalletPlanId =254
 






--	INSERT INTO rulesengine.BenefitRulesData (benefitRuleId,BenefitRuleData,CreateUser,CreateDate,ModifyUser,ModifyDate,isActive)
--values(2,'{"BENCAT":"Amount","BENCATVALUE":100,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":12,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"GROCERYBENEFITS"}',
--'systemUser',getdate(),'systmerUser',getdate(),1)

  -- ContractRules ----------------------------

select top 10 *from Insurance.ContractRules order by 1 desc

 INSERT INTO Insurance.ContractRules
(BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,ModifyUser,CreateDate,ModifyDate)
VALUES(294,1593,GETDATE(),'2099-12-31 00:00:00.000','systemUser','systemUser',getdate(),getdate()) 


--delete from master.memberinsurancedetails where id =6248857
 
 
 

 exec [otc].[AuthenticateOTCNationsStandardLogin]  'eon',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":null,"SerialNumber":null,"InsuranceNumber":"cap00111","UserName":null,"LoginUserName":null,"LoginPassword":"Nations@123","ProgramCode":null,"CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":null,"GroupNo":null,"SubDomain":null,"BenefitSource":null}'
,false
{"walletCode":"Grocery"}



select top 10*from  master.memberinsurancedetails where  insurancenbr='vibra'
update master.memberinsurancedetails set otcserialnumber='4949819083483'
where insurancenbr='vibra1312'



update provider.memberinsurancedetails set otcserialnumber='4949819083483'
where insurancenbr='vibra1312'

[otc].[LoginAuthentication] 'brighthealthcare',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":"12-27-1963","NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":null,"SerialNumber":null,"InsuranceNumber":500100989,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":null,"CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":null,"GroupNo":null,"SubDomain":null,"BenefitSource":null}'
,false