-- capital blue cross config

DECLARE @otcLoginConfig NVARCHAR(MAX) ='{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"allowAgentAccess":false,"benefitValueSource":"fis","loginTemplate":"OTCFlexStandard","ReplaceWallets":[],"AddWallets":[],"MapWallets":{"02":"GROCERYBENEFITS"},"tags":[]}'
DECLARE @OTCAPP VARCHAR(50) ='OTCLOGIN'
DECLARE @carrierId BIGINT
DECLARE @carrierName NVARCHAR(100)='Capital Blue Cross'
DECLARE @systemUser VARCHAR(100)='scripts';


SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));


select top 20 *From  insurance.insuranceConfig where   InsuranceCarrierId =271 AND configType ='OTCLOGIN' order by 1 desc


--INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
--			VALUES
--			(@OTCAPP,@otcLoginConfig,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1)



			select top 20 *From  insurance.insuranceConfig where     InsuranceCarrierId =271 AND configType ='CARRIERCONFIG' order by 1 desc

				--UPDATE insurance.insuranceConfig SET configData =
				--'{"programType":"Funded","benefitTypes":["HA","OTC"]}'
				--WHERE  InsuranceCarrierId =271 AND configType ='CARRIERCONFIG'

				--delete from  Insurance.insuranceconfig  where configId =1079
				-- OTC CONTENT  INSERT
				DECLARE @otcContent NVARCHAR(MAX) ='{"phone":"877-228-0943","showOTCGuidelines":false}'

				INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
			VALUES
			('OTCCONTENT',@otcContent,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1)


				


				DECLARE @ConfigData nvarchar(max)='{"ClientID": "644961","SubProgID": "797604"}'

      -- INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
		--VALUES
		--('FISCONFIGURATION',@ConfigData,271,GETDATE(),'systemUser',GETDATE(),'systemUser',1)
		 
		--UPDATE  Insurance.insuranceconfig SET  ConfigData =@ConfigData where InsuranceCarrierID =271  and ConfigType ='FISCONFIGURATION'

			select  *from	Insurance.insuranceconfig  where InsuranceCarrierId =271 order by 1 desc 

  select  *from insurance.insurancehealthplans where InsuranceCarrierId =271 order by 1 desc 

  --delete from insurance.insurancehealthplans where InsuranceHealthPlanID =4171


 -- 2467 Capital Blue Cross

 DECLARE @healthPlanName NVARCHAR(MAX)= (SELECT healthPlanName From  insurance.insurancehealthplans where InsuranceHealthPlanID =2467)
 SELECT @healthPlanName AS healthPlanName

 DECLARE @EffectivetToDate NVARCHAR(MAX) ='2099-12-31 00:00:00.000'
 DECLARE @insuranceHealthPlanId BIGINT =2467
 DECLARE @systemUser1 VARCHAR(100)='scripts';
 DECLARE @carrierName1 NVARCHAR(100)='Capital Blue Cross'
 DECLARE @carrierId1 BIGINT
 SELECT @carrierId1=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName1 
 PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId1,0));
 -- ======================> HealthPlanContracts <==============================================


   --INSERT INTO Insurance.HealthPlanContracts (ContractName,Description,EffectiveFromDate,EffectiveToDate,InsuranceCarrierID,InsuranceHealthPlanID,IsActive,ModifyDate,ModifyUser,CreateDate,CreateUser)
		-- VALUES(@healthPlanName,@healthPlanName,GETDATE(),@EffectivetToDate,@carrierId1,@insuranceHealthPlanId,1,GETDATE(),@systemUser1,GETDATE(),@systemUser1)
		
		select top 1   *from Insurance.HealthPlanContracts   where InsuranceCarrierId =271 order by 1 desc

		
		 select top 10 *From otccatalog.WalletPlans where  InsuranceCarrierID =271
		-- wallets

		SELECT  TOP 20 * FROM otccatalog.Wallets  where WalletCode ='FISGROCERY' order by 1 desc

		SELECT  TOP 20 * FROM otccatalog.Wallets  where WalletCode ='GROCERYBENEFITS' order by 1 desc
		SELECT * FROM otccatalog.WalletPlans where  walletId =146

		DELETE FROM   otccatalog.Wallets where walletId =146
INSERT INTO otccatalog.Wallets  (walletName,DisplayOrder,ShowonWeb,WalletCode,WalletSource,DisplayWalletName,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate,ColorCode,EffectiveDate,BenefitSpendingType)
VALUES('GROCERYBENEFITS',1,1,'GROCERYBENEFITS','FIS','GROCERYBENEFITS',1,'systemUser',getdate(),'systemUser',getdate(),'#08E8DE',getdate(),'GROCERY')




		SELECT  TOP 20 * FROM otccatalog.Wallets order by 1 desc
			select top 30 *from rulesengine.BenefitRules order by 1 desc  --275

		select top 30 *from rulesengine.BenefitRulesData order by 1 desc  --275

	INSERT INTO rulesengine.BenefitRulesData (benefitRuleId,BenefitRuleData,CreateUser,CreateDate,ModifyUser,ModifyDate,isActive)
values(2,'{"BENCAT":"Amount","BENCATVALUE":100,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":12,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"GROCERYBENEFITS"}',
'systemUser',getdate(),'systmerUser',getdate(),1)

  -- ContractRules ----------------------------

select top 10 *from Insurance.ContractRules order by 1 desc

 INSERT INTO Insurance.ContractRules
(BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,ModifyUser,CreateDate,ModifyDate)
VALUES(294,4381,GETDATE(),'2099-12-31 00:00:00.000','systemUser','systemUser',getdate(),getdate()) 


--delete from master.memberinsurancedetails where id =6248857
 
 
 select top 10 *From otccatalog.WalletPlans where  InsuranceCarrierID =380
 
 select top 10 *From otccatalog.WalletPlans where  InsuranceHealthPlanID =2467 AND InsuranceCarrierID =271
 select  *From otccatalog.WalletPlans where  InsuranceCarrierID =271 and walletId IN ( SELECT  walletId FROM otccatalog.Wallets where walletCode IN ('FLEXOTC','FLEXGROCERY'))
INSERT INTO otccatalog.WalletPlans (InsuranceCarrierId,insuranceHealthPlanId,WalletId,IsActive,CreateUser,CreateDate,ModifyDate,ModifyUser,EffectiveFrom )
values(271,2467 ,149,1,'systemUser',getdate(),getdate(),'systemUser',GETDATE())     

 UPDATE otccatalog.WalletPlans
 SET walletStandardData ='[13]'
 WHERE InsuranceHealthPlanID =2467 AND InsuranceCarrierID =271

 SELECT *From  insurance.insurancehealthplans where insuranceHealthPlanId =2467

 exec [otc].[AuthenticateOTCNationsStandardLogin]  'eon',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":null,"SerialNumber":null,"InsuranceNumber":"cap00111","UserName":null,"LoginUserName":null,"LoginPassword":"Nations@123","ProgramCode":null,"CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":null,"GroupNo":null,"SubDomain":null,"BenefitSource":null}'
,false
{"walletCode":"Grocery"}



--select top 10*from  master.memberinsurancedetails where  insurancenbr='nnaspoori'
--update master.memberinsurancedetails set otcserialnumber='0662658637620'
--where insurancenbr='molina00100'



--update provider.memberinsurancedetails set otcserialnumber='0662658637620'
--where insurancenbr='molina00100'