

 DECLARE @carrierId BIGINT
 DECLARE @systemUser VARCHAR(100)='scripts';
 DECLARE @carrierName NVARCHAR(100)='Vibra Health Plan'
 DECLARE @groceryWalletCode NVARCHAR(100) ='FLEXGROCERY'
 DECLARE @benefitRuleDataId BIGINT
 DECLARE @flexGroceryWalletId BIGINT


 -- benefitRuleData THIS IS FOR STAGE TESTING
 DECLARE @benefitRuleData NVARCHAR(MAX) ='{"BENCAT":"Amount","BENCATVALUE":10,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":12,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"FLEXGROCERY"}'

 --SELECT @flexGroceryWalletId =   walletId FROM otccatalog.Wallets where walletCode IN ('FLEXGROCERY')

 SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
-- select  *from insurance.insuranceConfig  WHERE insuranceCarrierID=@carrierId 
 select  * from  insurance.insurancehealthplans where InsuranceCarrierId =@carrierId

 select *From otccatalog.WalletPlans where InsuranceCarrierId =@carrierId AND ISNULL(InsuranceHealthPlanID, 0)=0  AND walletId IN (@flexGroceryWalletId)

 SELECT hp.HealthPlanContractId, ihp.* FROM Insurance.HealthPlanContracts hp 
INNER JOIN insurance.insurancehealthplans ihp ON ihp.insuranceHealthPlanID =hp.insuranceHealthPlanID
WHERE  ihp.InsuranceCarrierId =@carrierId

select *From benefitcard.ChangeRequest order by 1 desc

select top 20  *from master.MemberInsurances order by 1 desc 


select  * from master.MemberInsurances  WHERE InsuranceCarrierId=  271 order by 1 desc 





--UPDATE   master.MemberInsurances SET  SSBCIIndicator =1
--WHERE ID =10894388  AND InsuranceCarrierId=  267





 ---    fis card mapping to member =================================================================

insert into member.MemberCards(InsuranceCarrierID,InsuranceHealthPlanID,NHMemberID,CardReferenceNumber,CardVendor,CardReferenceNumberType,CardType,[Source],CreateUser,CreateDate,ModifyUser,
ModifyDate,IsActive)
values(271,2533,'NH202107380121','4004583747840','fis','ProxyId','BenefitCard','Script','mnaduri',GETDATE(),'mnanduri',GETDATE(),1)



select top 10 *from otc.userProfiles  -- order by 1 desc 
where nhMemberId ='NH202107380122'

select top 20 *from otc.userProfiles   order by 1 desc

UPDATE otc.userProfiles set subdomain ='capitalbluecross2'  WHEre userProfileID = 38067

select  *From [auth].[ServiceProviders] order by 1 desc 
select  *From  [auth].[SSOConfigurations] order by 1 desc 
[ "EON2", "OTCNETWORK2", "ULTIMATE2", "BANNERHEALTH2", "BMCHP2", "CCA2", "GEISINGER2", "PRESBYTERIANHEALTH2", "VILLAGECARE2", "CCAI2", "CLEARSPRINGAGW2", "HEALTHFIRST2", "OPTIMAHEALTH2", "TROY2", "CONNECTICARE2", "FIDELISCARE2", "PROMINENCE2", "ALIGNMENT2", "ICARE2", "ZING2", "HFHP2", "IBX2", "MOLINA2", "CAREOREGONADVANTAGE2", "ALIGNMENTPARTNERS2", "AETNA2", "HEALTHX2","CAPITALBLUECROSS2", "VIBRA2"]

[ "EON", "OTCNETWORK", "ULTIMATE", "BANNERHEALTH", "BMCHP", "CCA", "GEISINGER", "PRESBYTERIANHEALTH", "VILLAGECARE", "CCAI", "CLEARSPRINGAGW", "HEALTHFIRST", "OPTIMAHEALTH", "TROY", "CONNECTICARE", "FIDELISCARE", "PROMINENCE", "ALIGNMENT", "ICARE", "ZING", "HFHP", "IBX", "MOLINA", "CAREOREGONADVANTAGE", "ALIGNMENTPARTNERS", "AETNA", "HEALTHX","CAPITALBLUECROSS", "VIBRA","BCBSKC"]