 DECLARE @carrierId BIGINT
 DECLARE @systemUser VARCHAR(100)='scripts';
 DECLARE @carrierName NVARCHAR(100)='Capital Blue Cross'
 DECLARE @groceryWalletCode NVARCHAR(100) ='FLEXGROCERY'
 DECLARE @benefitRuleDataId BIGINT
 -- benefitRuleData THIS IS FOR STAGE TESTING
 DECLARE @benefitRuleData NVARCHAR(MAX) ='{"BENCAT":"Amount","BENCATVALUE":10,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":12,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"FLEXGROCERY"}'



 SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
-- select  *from insurance.insuranceConfig  WHERE insuranceCarrierID=@carrierId 

  --select  * from  insurance.insurancehealthplans where InsuranceCarrierId =@carrierId
  SELECT @benefitRuleDataId = BenefitRuleDataId FROM rulesengine.BenefitRulesData WHERE JSON_VALUE(BenefitRuleData ,'$.WALCODE')= @groceryWalletCode AND IsActive =1 
  SELECT @benefitRuleDataId
  SELECT TOP 10 *FROM rulesengine.BenefitRulesData  WHERE JSON_VALUE(BenefitRuleData ,'$.WALCODE')= @groceryWalletCode AND IsActive =1 

 DROP TABLE IF EXISTS  #healthPlnCntrctTbl
 SELECT *INTO #healthPlnCntrctTbl 
FROM (
 SELECT hp.HealthPlanContractId,ihp.* FROM Insurance.HealthPlanContracts hp 
INNER JOIN insurance.insurancehealthplans ihp ON ihp.insuranceHealthPlanID =hp.insuranceHealthPlanID
WHERE  ihp.InsuranceCarrierId =@carrierId 
)AS G

UPDATE hc SET IsActive =0
FROM #healthPlnCntrctTbl hc
INNER join Insurance.ContractRules cr ON hc.healthPlanContractID =cr.healthPlanContractID 
WHERE cr.BenefitRuleDataId =@benefitRuleDataId


SELECT *FROM #healthPlnCntrctTbl
select * from Insurance.ContractRules WHERE benefitRuleDataId =262 AND healthPlanContractId IN (SELECT healthPlanContractId FROM #healthPlnCntrctTbl)  
select top 10 * from Insurance.HealthPlanContracts where insuranceHealthPlanID =2527
--SELECT TOP 10 *FROM rulesengine.BenefitRulesData WHERE JSON_VALUE(BenefitRuleData ,'$.WALCODE')= 'FLEXGROCERY' AND IsActive =1

select top 20  *from master.MemberInsurances WHERE InsuranceCarrierId=  271 order by 1 desc 
262

2527
--UPDATE   master.MemberInsurances SET  SSBCIIndicator =1
--WHERE ID =10894412  AND InsuranceCarrierId=  271

  select  * from  insurance.insurancehealthplans where InsuranceCarrierId =@carrierId


  select top 10 *From otccatalog.walletplans where InsuranceCarrierId =271 order by 1 desc

  UPDATE otccatalog.walletplans SET benefitValueSource ='fis'
  where WalletPlanId =196
2527


