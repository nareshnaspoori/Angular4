 BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
 
 DECLARE @carrierId BIGINT
 DECLARE @systemUser VARCHAR(100)='scripts';
 DECLARE @carrierName NVARCHAR(100)='Capital Blue Cross'
 DECLARE @groceryWalletCode NVARCHAR(100) ='FLEXGROCERY'
 DECLARE @benefitRuleDataId BIGINT
 -- benefitRuleData THIS IS FOR STAGE TESTING
 DECLARE @benefitRuleData NVARCHAR(MAX) ='{"BENCAT":"Amount","BENCATVALUE":10,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":12,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"FLEXGROCERY"}'

 SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
 

 IF NOT EXISTS (SELECT TOP 1 * FROM rulesengine.BenefitRulesData where JSON_VALUE(BenefitRuleData ,'$.WALCODE')= @groceryWalletCode AND IsActive =1 ORDER BY 1 DESC)
	BEGIN
	   INSERT INTO rulesengine.BenefitRulesData (benefitRuleId,BenefitRuleData,CreateUser,CreateDate,ModifyUser,ModifyDate,isActive)
											    VALUES(2,@benefitRuleData,@systemUser,getdate(),@systemUser,getdate(),1)
      SELECT @benefitRuleDataId = BenefitRuleDataId FROM rulesengine.BenefitRulesData WHERE JSON_VALUE(BenefitRuleData ,'$.WALCODE')= @groceryWalletCode AND IsActive =1
    END
ELSE
   BEGIN
    SELECT @benefitRuleDataId = BenefitRuleDataId FROM rulesengine.BenefitRulesData WHERE JSON_VALUE(BenefitRuleData ,'$.WALCODE')= @groceryWalletCode AND IsActive =1
	--SELECT  @benefitRuleDataId AS benefitRuleDataId
   END
	
	--SELECT  @benefitRuleDataId AS benefitRuleDataId

DROP TABLE IF EXISTS  #healthPlnCntrctTbl

SELECT *INTO #healthPlnCntrctTbl 
FROM (
SELECT hp.HealthPlanContractId, ihp.* FROM Insurance.HealthPlanContracts hp 
INNER JOIN insurance.insurancehealthplans ihp ON ihp.insuranceHealthPlanID =hp.insuranceHealthPlanID
WHERE  ihp.InsuranceCarrierId =@carrierId

)AS F


--SELECT *FROM   #healthPlnCntrctTbl  where isactive =0
--SELECT *FROM Insurance.ContractRules WHERE BenefitRuleDataId =@benefitRuleDataId 

UPDATE hc SET IsActive =0
FROM #healthPlnCntrctTbl hc
INNER join Insurance.ContractRules cr ON hc.healthPlanContractID =cr.healthPlanContractID 
WHERE cr.BenefitRuleDataId =@benefitRuleDataId


 INSERT INTO Insurance.ContractRules (BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,ModifyUser,CreateDate,ModifyDate,IsActive)
                               SELECT @benefitRuleDataId,hp.HealthPlanContractId,GETDATE(),'2099-12-31 00:00:00.000',@systemUser,@systemUser,getdate(),getdate(),1
FROM #healthPlnCntrctTbl HP
WHERE hp.IsActive =1

 	COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH



