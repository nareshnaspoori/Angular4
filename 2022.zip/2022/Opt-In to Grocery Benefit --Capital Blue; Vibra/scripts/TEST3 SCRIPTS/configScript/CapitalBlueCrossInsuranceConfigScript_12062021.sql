
BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'

DECLARE @carrierId BIGINT
DECLARE @otcLoginConfigType VARCHAR(50) ='OTCLOGIN'
DECLARE @carrierName NVARCHAR(100)='Capital Blue Cross'
--@otcLoginConfigData THIS ONLY FOR STAGE 
DECLARE @otcLoginConfigData NVARCHAR(MAX) ='{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"allowAgentAccess":false,"loginTemplate":"OTCFlexStandard","ReplaceWallets":[],"AddWallets":[],"MapWallets":{"01":"FLEXOTC","02":"FLEXGROCERY","03":"FLEXREWARDS"},"tags":[]}'
DECLARE @systemUser VARCHAR(100)='scripts';

DECLARE @carrierConfigConfigType  NVARCHAR(100) ='CARRIERCONFIG' 

DECLARE @otcContentConfigType NVARCHAR(100) ='OTCCONTENT'
DECLARE @otcContent NVARCHAR(MAX) ='{"phone":"877-228-0943","showOTCGuidelines":false}'
DECLARE @phoneNumber VARCHAR(100) ='877-228-0943'

DECLARE @fisConfigType nvarchar(max) ='FISCONFIGURATION'
DECLARE @fisConfigData nvarchar(max)='{"ClientID": "644961","SubProgID": "797604"}'
DECLARE @fisClientID VARCHAR(MAX) ='644961'
DECLARE @SubProgID VARCHAR(MAX) ='797604'

--memberPortalContent this is for benefitportal login for stage only
DECLARE @memberPortalContent  NVARCHAR(MAX) ='{"phone":"877-228-0943","showOTCGuidelines":false,"civilRightsDisclaimer":"Testing civil right disclaimer","hoursOfOperation":"Seven days a week 8:00 a.m. to 11:00 p.m. ET","expiryMsgTimePeriodInMonths":"12"}'
DECLARE @memberPortalContentConfigType NVARCHAR(MAX) ='MEMBERPORTALCONTENT'

SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
--SELECT @carrierId AS carrierID

-- OTC LOGIN TEMPLATE INSERTS ----

IF EXISTS (SELECT *FROM  insurance.insuranceConfig WHERE  InsuranceCarrierId =@carrierId AND configType =@otcLoginConfigType  AND IsActive=1 )
BEGIN
	UPDATE insurance.insuranceConfig SET ConfigData =@otcLoginConfigData , modifyUser =@systemUser,modifydate =GETDATE()
	WHERE  InsuranceCarrierId =@carrierId AND configType =@otcLoginConfigType 
	--SELECT *FROM  Insurance.insuranceconfig WHERE   InsuranceCarrierId =@carrierId AND configType =@otcLoginConfigType AND isActive =1 
END

IF NOT EXISTS (SELECT *FROM  insurance.insuranceConfig WHERE  InsuranceCarrierId =@carrierId AND configType =@otcLoginConfigType AND  IsActive=1)
    BEGIN 
	     INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
	     VALUES (@otcLoginConfigType,@otcLoginConfigData,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1)
	END


-- CARRIERCONFIG -------- INSERTS OR UPDATES

--select  *From  insurance.insuranceConfig WHERE InsuranceCarrierId =@carrierId AND configType =@carrierConfigConfigType AND IsActive=1 

IF NOT EXISTS (SELECT *FROM   insurance.insuranceConfig WHERE InsuranceCarrierId =@carrierId AND configType =@carrierConfigConfigType AND JSON_QUERY(ConfigData,'$.benefitTypes') LIKE '%OTC%' AND IsActive=1)
 BEGIN
      UPDATE insurance.insuranceConfig SET configData =JSON_MODIFY(configData,'append  $.benefitTypes','OTC') ,ModifyDate = GETDATE(),modifyUser =@systemUser
	  WHERE   InsuranceCarrierId =@carrierId AND configType =@carrierConfigConfigType  AND IsActive =1 
	  
	--  SELECT *FROM  Insurance.insuranceconfig WHERE InsuranceCarrierId=@carrierId AND configType=@carrierConfigConfigType AND isActive =1 
 END


 -- OTC CONTENT -- INSERTS OR UPDATES 
 --SELECT *FROM insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType =@otcContentConfigType AND IsActive=1

 IF NOT EXISTS (SELECT *FROM  insurance.insuranceConfig WHERE InsuranceCarrierId =@carrierId AND configType =@otcContentConfigType AND IsActive=1)
  BEGIN
        INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
	    VALUES (@otcContentConfigType,@otcContent,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1)

--	    SELECT *FROM insurance.insuranceConfig WHERE InsuranceCarrierId =@carrierId AND configType =@otcContentConfigType AND IsActive=1
  END
ELSE 
  BEGIN
        UPDATE Insurance.insuranceconfig SET ConfigData =JSON_MODIFY(ConfigData,'$.phone',@phoneNumber), ModifyDate =GETDATE() ,modifyUser =@systemUser
		WHERE InsuranceCarrierId =@carrierId AND configType =@otcContentConfigType  AND IsActive=1 
--	    SELECT *FROM insurance.insuranceConfig WHERE InsuranceCarrierId =@carrierId AND configType =@otcContentConfigType AND IsActive=1
  END


  -- FISCONFIGURATION  configType inserts or updates

  -- SELECT *FROM  insurance.insuranceConfig WHERE InsuranceCarrierId =@carrierId AND configType =@fisConfigType AND IsActive=1

IF NOT EXISTS (SELECT *FROM insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType=@fisConfigType AND IsActive=1)	
	BEGIN
		   INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
		   VALUES (@fisConfigType,@fisConfigData,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1)

--		   SELECT *FROM insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType=@fisConfigType AND IsActive=1
	END
ELSE
	BEGIN
	     DECLARE @updateFisConfigData NVARCHAR(MAX) 
		 SELECT @updateFisConfigData = ConfigData FROM   Insurance.insuranceconfig   WHERE InsuranceCarrierId =@carrierId AND configType =@fisConfigType AND IsActive=1 
		 SET @updateFisConfigData = JSON_MODIFY(@updateFisConfigData,'$.ClientID',@fisClientID) 
		 SET @updateFisConfigData = JSON_MODIFY(@updateFisConfigData,'$.SubProgID',@SubProgID) 
	     UPDATE Insurance.insuranceconfig SET ConfigData =@updateFisConfigData, ModifyDate =GETDATE(),modifyUser =@systemUser
		 WHERE InsuranceCarrierId =@carrierId  AND  configType =@fisConfigType AND IsActive=1 

--		 SELECT *FROM insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType=@fisConfigType AND IsActive=1
	END

	
	--  MEMBERPORTALCONTENT configType inserts -------------

IF NOT EXISTS (SELECT *FROM insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType=@memberPortalContentConfigType AND IsActive=1)	
	BEGIN
		   INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
		   VALUES (@memberPortalContentConfigType,@memberPortalContent,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1)

		  -- SELECT *FROM insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType=@memberPortalContentConfigType AND IsActive=1
	END
ELSE
	BEGIN
	     DECLARE @updateFisContentConfigData NVARCHAR(MAX) 
		 SELECT @updateFisContentConfigData = ConfigData FROM  Insurance.insuranceconfig   WHERE InsuranceCarrierId =@carrierId AND configType =@memberPortalContentConfigType AND IsActive=1 
		 SET @updateFisContentConfigData = JSON_MODIFY(@updateFisContentConfigData,'$.phone',@phoneNumber) 
	     UPDATE Insurance.insuranceconfig SET ConfigData =@updateFisContentConfigData , ModifyDate =GETDATE(),modifyUser =@systemUser
		 WHERE InsuranceCarrierId =@carrierId AND configType =@memberPortalContentConfigType AND IsActive=1

		-- SELECT *FROM insurance.insuranceConfig where InsuranceCarrierId =@carrierId AND configType=@memberPortalContentConfigType AND IsActive=1
	END

COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH
