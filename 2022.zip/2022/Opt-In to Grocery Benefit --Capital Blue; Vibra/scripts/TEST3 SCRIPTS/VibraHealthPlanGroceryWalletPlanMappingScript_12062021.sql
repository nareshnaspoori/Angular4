 BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'

 
 DECLARE @carrierName NVARCHAR(100)='Vibra Health Plan'
 DECLARE @carrierId BIGINT
 DECLARE @flexOTCWalletId BIGINT
 DECLARE @flexGroceryWalletId BIGINT
 DECLARE @systemUser VARCHAR(100)='scripts';
 DECLARE @walletAttributeId BIGINT


SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
SELECT @carrierId AS carrierId

SELECT @flexOTCWalletId =   walletId FROM otccatalog.Wallets where walletCode IN ('FLEXOTC')


SELECT @flexGroceryWalletId =   walletId FROM otccatalog.Wallets where walletCode IN ('FLEXGROCERY')


 IF NOT EXISTS (select *From otccatalog.WalletPlans where  InsuranceCarrierID =@carrierId and ISNULL(InsuranceHealthPlanID, 0)=0  AND walletId IN (@flexOTCWalletId))
	BEGIN
	     INSERT INTO otccatalog.WalletPlans (InsuranceCarrierId, WalletId,IsActive,CreateUser,CreateDate,ModifyDate,ModifyUser,EffectiveFrom )
         VALUES(@carrierId,@flexOTCWalletId,1,@systemUser,getdate(),getdate(),@systemUser,GETDATE())  
              
END

 IF NOT EXISTS (select *From otccatalog.WalletPlans where  InsuranceCarrierID =@carrierId and ISNULL(InsuranceHealthPlanID, 0)=0  AND walletId IN (@flexGroceryWalletId))
	BEGIN
	     INSERT INTO otccatalog.WalletPlans (InsuranceCarrierId, WalletId,IsActive,CreateUser,CreateDate,ModifyDate,ModifyUser,EffectiveFrom )
         VALUES (@carrierId,@flexGroceryWalletId,1,@systemUser,getdate(),getdate(),@systemUser,GETDATE())  
END


IF NOT EXISTS (SELECT *FROM otccatalog.WalletAttributeMaster WHERE name ='SSBCIWallet') 
  BEGIN
         INSERT INTO otccatalog.WalletAttributeMaster (name,Data,description, createUser,Createdate,Modifyuser,modifydate,isActive)
         VALUES('SSBCIWallet',JSON_QUERY('[{"indicator": true,"memberConsent": true}]'),'opt-in SSBCIWallet ',@systemUser,getdate(),@systemUser,getdate(),1) 
  END

   SELECT @walletAttributeId =  walletAttributeId FROM   otccatalog.WalletAttributeMaster WHERE name ='SSBCIWallet'
   SELECT @walletAttributeId AS walletAttributeId

 IF(ISNULL(@walletAttributeId,0)!=0)
   BEGIN
	  UPDATE otccatalog.WalletPlans
      SET walletStandardData ='['+CAST (@walletAttributeId AS VARCHAR(100))+']', modifyDate =GETDATE(), BenefitValueSource ='fis'
      WHERE ISNULL(InsuranceHealthPlanID,0) =0 AND InsuranceCarrierID =@carrierId AND walletId = @flexGroceryWalletId
	  
 SELECT *FROM otccatalog.WalletPlans  WHERE ISNULL(InsuranceHealthPlanID,0) =0 AND InsuranceCarrierID =@carrierId AND walletId = @flexGroceryWalletId
 SELECT *FROM  otccatalog.WalletPlans WHERE  InsuranceCarrierID =@carrierId and ISNULL(InsuranceHealthPlanID, 0)=0  AND walletId IN ( SELECT  walletId FROM otccatalog.Wallets WHERE walletCode IN ('FLEXOTC','FLEXGROCERY'))

	END

 	COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH


