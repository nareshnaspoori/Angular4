BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'


DECLARE @carrierId BIGINT
DECLARE @carrierName NVARCHAR(100)='Vibra Health Plan'
DECLARE @healthPlanName NVARCHAR(MAX)='Vibra Health Plan Retirees Platinum Plus (PPO)'
DECLARE @insuranceHealthPlanId BIGINT 
DECLARE @HealthPlanContractID BIGINT
DECLARE @walletAttributeId BIGINT
DECLARE @flexOTCWalletId BIGINT
DECLARE @flexGroceryWalletId BIGINT
DECLARE @walletStandardData VARCHAR(100)
DECLARE @systemUser VARCHAR(100)='scripts';

SELECT *From  insurance.insurancehealthplans where healthPlanName =@healthPlanName


 SELECT @insuranceHealthPlanId = insuranceHealthPlanId From  insurance.insurancehealthplans where healthPlanName= @healthPlanName
  PRINT CONCAT('insuranceHealthPlanId:',@insuranceHealthPlanId);

  SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
 PRINT CONCAT('carrierId:',ISNULL(@carrierId,0));

 select  @HealthPlanContractID =  HealthPlanContractID  FROM Insurance.HealthPlanContracts   where insuranceHealthPlanId =@insuranceHealthPlanId 
 SELECT @HealthPlanContractID AS HealthPlanContractID

 
 SELECT  TOP 30 * FROM otccatalog.Wallets where walletCode IN ('FLEXOTC','FLEXGROCERY')  order by 1 desc

 
	   --	select top 30 *from rulesengine.BenefitRules order by 1 desc  --275
		---select top 30 *from rulesengine.BenefitRulesData order by 1 desc  --275
		--select top 10 *from Insurance.ContractRules WHERE HealthPlanContractID =@HealthPlanContractID order by 1 desc
		--select top 30 *from rulesengine.BenefitRulesData WHERE BenefitRuleDataId IN (SELECT BenefitRuleDataId FROM Insurance.ContractRules WHERE HealthPlanContractID =@HealthPlanContractID )  
	
	select  *From otccatalog.WalletPlans where  InsuranceCarrierID =@carrierId AND insuranceHealthPlanId =@insuranceHealthPlanId AND walletId IN ( SELECT  walletId FROM otccatalog.Wallets where walletCode IN ('FLEXOTC','FLEXGROCERY'))

	     
	 -- wallet plans inserts if not exists.
IF NOT EXISTS (select *From otccatalog.WalletPlans where  InsuranceCarrierID =@carrierId and walletId IN ( SELECT  walletId FROM otccatalog.Wallets where walletCode IN ('FLEXOTC','FLEXGROCERY'))) 
	BEGIN
	    
		 
		 SELECT @flexOTCWalletId = WalletId FROM otccatalog.WalletPlans where  InsuranceCarrierID =@carrierId and walletId IN ( SELECT  walletId FROM otccatalog.Wallets where walletCode IN ('FLEXOTC'))
		 SELECT @flexOTCWalletId AS flexOTCWalletId

		 SELECT @flexGroceryWalletId = WalletId FROM otccatalog.WalletPlans where  InsuranceCarrierID =@carrierId and walletId IN ( SELECT  walletId FROM otccatalog.Wallets where walletCode IN ('FLEXGROCERY'))
		 SELECT @flexGroceryWalletId AS flexGroceryWalletId

	     INSERT INTO otccatalog.WalletPlans (InsuranceCarrierId,insuranceHealthPlanId,WalletId,IsActive,CreateUser,CreateDate,ModifyDate,ModifyUser,EffectiveFrom )
         VALUES(@carrierId,@insuranceHealthPlanId ,@flexOTCWalletId,1,@systemUser,getdate(),getdate(),@systemUser,GETDATE()),  
              (@carrierId,@insuranceHealthPlanId ,@flexGroceryWalletId,1,@systemUser,getdate(),getdate(),@systemUser,GETDATE())  
	END
ELSE
	BEGIN
	     SELECT @flexOTCWalletId = WalletId FROM otccatalog.WalletPlans where  InsuranceCarrierID =@carrierId and walletId IN ( SELECT  walletId FROM otccatalog.Wallets where walletCode IN ('FLEXOTC'))
		 SELECT @flexOTCWalletId AS flexOTCWalletId
		 SELECT @flexGroceryWalletId = WalletId FROM otccatalog.WalletPlans where  InsuranceCarrierID =@carrierId and walletId IN ( SELECT  walletId FROM otccatalog.Wallets where walletCode IN ('FLEXGROCERY'))
		 SELECT @flexGroceryWalletId AS flexGroceryWalletId
	END


 
  IF NOT EXISTS (SELECT *FROM otccatalog.WalletAttributeMaster WHERE name ='SSBCIWallet') 
  BEGIN
         INSERT INTO otccatalog.WalletAttributeMaster (name,Data,description, createUser,Createdate,Modifyuser,modifydate,isActive)
         VALUES('SSBCIWallet',JSON_QUERY('[{"indicator": true,"memberConsent": true}]'),'opt-in SSBCIWallet ',@systemUser,getdate(),@systemUser,getdate(),1) 
  END
 
 
   SELECT @walletAttributeId =  walletAttributeId FROM   otccatalog.WalletAttributeMaster WHERE name ='SSBCIWallet'
   IF(ISNULL(@walletAttributeId,0)!=0)
   BEGIN
	  UPDATE otccatalog.WalletPlans
      SET walletStandardData ='['+CAST (@walletAttributeId AS VARCHAR(100))+']', modifyDate =GETDATE()
      WHERE InsuranceHealthPlanID =@insuranceHealthPlanId AND InsuranceCarrierID =@carrierId AND walletId = @flexGroceryWalletId
	 
	 SELECT *FROM otccatalog.WalletPlans  WHERE InsuranceHealthPlanID = @insuranceHealthPlanId AND InsuranceCarrierID =@carrierId AND walletId = @flexGroceryWalletId
	 
	END
	
	COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH




