SELECT * FROM otccatalog.Wallets WHERE WalletCode = 'EON Health Plan' 

SELECT * FROM  otccatalog.WalletPlans order by 1 desc


SELECT * FROM otccatalog.WalletPlans WHERE InsuranceCarrierId = 7 AND InsuranceHealthPlanID = 20 --

SELECT * FROM rulesengine.BenefitRulesData where JSON_VALUE(BenefitRuleData,'$.WALCODE') = 'EON Health Plan'

UPDATE 






delete from dbo.sessions

DECLARE @healthPlanName NVARCHAR(MAX)='Capital Blue Cross OTC testing'
DECLARE @carrierId BIGINT =271
DECLARE @EffectivetToDate NVARCHAR(MAX) ='2099-12-31 00:00:00.000'
DECLARE @systemUser VARCHAR(100)='scripts';
DECLARE @insuranceHealthPlanId BIGINT =4171
DECLARE @benefitRuleDataId BIGINT 

 --INSERT INTO insurance.insurancehealthplans (HealthPlanName,InsuranceCarrierID,IsActive,IsDiscountProgram,CreateUser,CreateDate,ModifyUser,ModifyDate)
	--	 VALUES
	--	 (@healthPlanName,@carrierId,1,0,@systemUser,GETDATE(),@systemUser,GETDATE())
		
	
 select  *from insurance.insurancehealthplans where InsuranceCarrierId =271 order by 1 desc 

 UPDATE insurance.insurancehealthplans SET IsActive =1
 WHERE InsuranceHealthPlanID =2467
 
 select  *from Insurance.HealthPlanContracts  where InsuranceCarrierId =271 order by 1 desc 
 DELETE FROM  Insurance.HealthPlanContracts where HealthPlanContractId =4378
  --INSERT INTO Insurance.HealthPlanContracts (ContractName,Description,EffectiveFromDate,EffectiveToDate,InsuranceCarrierID,InsuranceHealthPlanID,IsActive,ModifyDate,ModifyUser,CreateDate,CreateUser)
		-- VALUES(@healthPlanName,@healthPlanName,GETDATE(),@EffectivetToDate,@carrierId,@insuranceHealthPlanId,1,GETDATE(),@systemUser,GETDATE(),@systemUser)
		

SELECT  TOP 20 * FROM otccatalog.Wallets  where WalletCode ='FISGROCERY' order by 1 desc
INSERT INTO otccatalog.Wallets  (walletName,DisplayOrder,ShowonWeb,WalletCode,WalletSource,DisplayWalletName,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate,ColorCode,EffectiveDate,BenefitSpendingType)
VALUES('FLEXGROCERY',1,1,'FISGROCERY','FIS','FISGROCERY',1,'systemUser',getdate(),'systemUser',getdate(),'#08E8DE',getdate(),'GROCERY')

SELECT * FROM otccatalog.WalletPlans where InsuranceCarrierId =271   --4171
otccatalog.WalletPlans
delete from  otccatalog.WalletPlans where WalletPlanId =246
--INSERT INTO otccatalog.WalletPlans (InsuranceCarrierId,insuranceHealthPlanId,WalletId,IsActive,CreateUser,CreateDate,ModifyDate,ModifyUser,EffectiveFrom )
--values(271,4171,146,1,'systemUser',getdate(),getdate(),'systemUser',GETDATE())     246
 
 UPDATE otccatalog.WalletPlans
 SET walletStandardData =null
 WHERE InsuranceHealthPlanID =4171 AND InsuranceCarrierID =271 AND walletId=146

 select top 10 *from rulesengine.BenefitRules order by 1 desc  --275
select top 10 *from rulesengine.BenefitRulesData order by 1 desc  --275

INSERT INTO rulesengine.BenefitRulesData (benefitRuleId,BenefitRuleData,CreateUser,CreateDate,ModifyUser,ModifyDate,isActive)
values(2,'{"BENCAT":"Amount","BENCATVALUE":10,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":12,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"FISGROCERY"}',
'systemUser',getdate(),'systmerUser',getdate(),1)

 select top 10 *from Insurance.ContractRules order by 1 desc

 INSERT INTO Insurance.ContractRules
(BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,ModifyUser,CreateDate,ModifyDate)
VALUES(293,4378,GETDATE(),'2099-12-31 00:00:00.000','systemUser','systemUser',getdate(),getdate()) 



delete from dbo.sessions

 select top 10 *from  insurance.insuranceConfig  order by 1 desc 
 select top 20 *from  insurance.insuranceConfig  where InsuranceCarrierId =271  order by 1 desc
 
 DECLARE @ConfigData nvarchar(max)='{"ClientID": "123456","SubProgID": "234567"}'

 INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
		VALUES
		('FISCONFIGURATION',@ConfigData,271,GETDATE(),'systemUser',GETDATE(),'systemUser',1)

 select top 10 * From  master.MemberInsuranceDetails order by 1 desc  


 --delete from Insurance.insuranceconfig where configid =625


 SELECT mm.NHMemberID, ic.InsuranceCarrierID, ic.InsuranceCarrierName, 
hp.InsuranceHealthPlanID, hp.HealthPlanName,
JSON_VALUE(br.BenefitRuleData,'$.WALCODE') AS [Wallet Code],
JSON_VALUE(br.BenefitRuleData,'$.BENCATVALUE') AS Amount, 
JSON_VALUE(br.BenefitRuleData,'$.BENFREQMONTHS') AS [Frequency Months], 
JSON_VALUE(br.BenefitRuleData,'$.BENVALUESRC') AS [Source], 
JSON_VALUE(br.BenefitRuleData,'$.BENTYPE') AS [Benefit Type] 
FROM master.Members mm
INNER JOIN master.MemberInsurances mi ON mm.MemberID = mi.MemberID
INNER JOIN Insurance.InsuranceHealthPlans hp ON hp.InsuranceHealthPlanID = mi.InsuranceHealthPlanID 
INNER JOIN Insurance.InsuranceCarriers ic ON ic.InsuranceCarrierID = mi.InsuranceCarrierID
INNER JOIN Insurance.HealthPlanContracts hpc ON hpc.InsuranceCarrierID = hp.InsuranceCarrierID AND hpc.InsuranceHealthPlanID = 
hp.InsuranceHealthPlanID
INNER JOIN Insurance.ContractRules cr ON cr.HealthPlanContractId = hpc.HealthPlanContractID
INNER JOIN rulesengine.BenefitRulesData br ON br.BenefitRuleDataId = cr.BenefitRuleDataId 
WHERE mm.NHMemberID = 'NH202107354322'


exec otc.LoginAuthentication
'demo',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":null,"SerialNumber":null,"InsuranceNumber":"flex0011","UserName":null,"LoginUserName":null,"LoginPassword":"Nations@123","ProgramCode":null,"CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":null,"GroupNo":null,"SubDomain":null,"BenefitSource":null}'
,0

select top 10 *From auth.serviceProvider order by 1 desc 

select top 10 *From [auth].[ServiceProviders] order by 1 desc 
select top 10 *From  [auth].[SSOConfigurations] order by 1 desc 

[   "EON",   "OTCNETWORK",   "ULTIMATE",   "BANNERHEALTH",   "BMCHP",   "CCA",   "GEISINGER",   "PRESBYTERIANHEALTH",   "VILLAGECARE",   "CCAI",   "CLEARSPRINGAGW",   "HEALTHFIRST",   "OPTIMAHEALTH",   "TROY",   "CONNECTICARE",   "FIDELISCARE",   "PROMINENCE",   "ALIGNMENT",   "ICARE",   "ZING",   "HFHP",   "IBX",   "MOLINA",   "CAREOREGONADVANTAGE",   "ALIGNMENTPARTNERS",   "AETNA",   "HEALTHX"  ]