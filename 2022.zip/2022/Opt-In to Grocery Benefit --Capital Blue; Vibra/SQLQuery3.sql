select top 10 * from otccatalog.WalletAttributeMaster order by 1 desc

--isActive = 1  walletId=56,insuranceHealthPlanId =2732,ModifyDate=getdate() ,

UPDATE otccatalog.WalletPlans SET walletId=56
where walletPlanId =168

select top 10 *From otccatalog.Wallets where walletId in (136,56) order by 1 desc

 select  *From  otccatalog.WalletPlans  where InsuranceCarrierId =277
select top 10 *From otccatalog.Wallets where walletCode like'%CB02FIS22%'
[{"indicator": true,"memberConsent": true}]
SELECT TOP  10 *from otc.userProfiles where subdomain like '%capital%' order by 1 desc
SELECT TOP 10 *FROM inu
SELECT TOP  20  *from  otccatalog.WalletAttributeMaster order by 1 desc
select top 10 *From otccatalog.WalletPlans  order by 1 desc
SELECT * FROM otccatalog.WalletPlans where InsuranceCarrierId =271 and walletId =121  and  InsuranceHealthPlanID =2537
60
 UPDATE otccatalog.WalletPlans
 SET walletStandardData ='[6]' 
 WHERE   walletPlanId = 184 --InsuranceHealthPlanID =2537 AND InsuranceCarrierID = 271 --267

 	INSERT INTO otccatalog.WalletPlans (InsuranceCarrierId,insuranceHealthPlanId,WalletId,IsActive,CreateUser,CreateDate,ModifyDate,ModifyUser,EffectiveFrom )
values(271,null ,60,1,'systemUser',getdate(),getdate(),'systemUser',GETDATE())   

delete from otccatalog.WalletPlans where  walletPlanId = 601 

SELECT TOP 20  *fROM master.memberInsurances  where  InsuranceCarrierId =271 and  InsuranceHealthPlanID =2537 order by 1 desc

select top 10 *From insurance.insuranceConfig where InsuranceCarrierId =302
{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"loginTemplate":"OTCNations2FA","ReplaceWallets":[],"AddWallets":[],"MapWallets":{"01":"AL01FIS22","02":"AL02FIS22","03":"AL03FIS22"},"tags":[],"actualLoginTemplate":"OTCInCommStandard2FA","healthPlanCode":["HI1"],"exclude2FAGroupIds":["AHC H6306-005"],"allowAgentAccess":true,"agentLoginType":"AGENT_USER","loginTemplate2022":"OTCNations2FA","isMemberMustRegister":false}

select top 10 *From benefitcard.changerequest where nhmemberId ='NH202108561034'