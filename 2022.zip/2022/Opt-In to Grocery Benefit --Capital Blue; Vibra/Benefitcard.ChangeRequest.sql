/****** Object:  Table [benefitcard].[changeRequest]    Script Date: 2021-12-03 20:21:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [benefitcard].[ChangeRequest](
	[RequestID] [bigint] IDENTITY(1,1) NOT NULL,
	[RequestDate] [datetime2](7) NULL,
	[RequestedUser] [nvarchar](150) NULL,
	[BenefitCardVendor] [varchar](100) NULL,
	[RequestType] [varchar](100) NULL,
	[InsuranceCarrierID] [bigint] NOT NULL,
	[InsuranceHealthPlanId] [bigint] NOT NULL,
	[NHMemberId] [nvarchar](40) NOT NULL,
	[RequestData] [nvarchar](max) NULL,
	[IsProcessed] [bit] NULL,
	[ProcessReferenceId] [bigint] NULL,
	[UserPromptIndicator] [bit] NULL,
	[IsActive] [bit] NOT NULL,
	[CreateDate] [datetime2](7) NULL,
	[CreateUser] [nvarchar](150) NULL,
	[ModifyDate] [datetime2](7) NULL,
	[ModifyUser] [nvarchar](150) NULL,
PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [benefitcard].[changeRequest] ADD  DEFAULT ((1)) FOR [IsActive]
GO
