--  SSBCI Vibra and Capital Blue


 DECLARE @carrierId BIGINT
 DECLARE @systemUser VARCHAR(100)='scripts';
 DECLARE @carrierName NVARCHAR(100)='Vibra Health Plan'
 DECLARE @groceryWalletCode NVARCHAR(100) ='FLEXGROCERY'
 DECLARE @benefitRuleDataId BIGINT
 -- benefitRuleData THIS IS FOR STAGE TESTING
 DECLARE @benefitRuleData NVARCHAR(MAX) ='{"BENCAT":"Amount","BENCATVALUE":10,"BENTYPE":"OTC","BENBEHV":"Reset","BENFREQMONTHS":12,"BENFREQTYPE":"CY","BENVALUESRC":"FIS","WALCODE":"FLEXGROCERY"}'
 
 SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
 select  *from insurance.insuranceConfig  WHERE insuranceCarrierID=@carrierId 

 	 select *from Insurance.ContractRules  where HealthPlanContractId in ( SELECT HealthPlanContractId FROM Insurance.HealthPlanContracts  
where insuranceHealthPlanID in (select insuranceHealthPlanID  from  insurance.insurancehealthplans where InsuranceCarrierId =@carrierId)) order by 1 desc







SELECT TOP 10 * from insurance.insuranceConfig   where insuranceCarrierID =267
SELECT TOP 10 * FROM master.memberInsuranceDetails ORDER BY 1 DESC

SELECT TOP 20 * FROM master.memberInsurances ORDER BY 1 DESC

UPDATE  master.memberInsurances SET SSBCIIndicator =1 ,modifydate =getdate()
where id =10762712  

0
SELECT TOP 20 * FROM otccatalog.WalletPlans where walletId =60  ORDER BY 1 DESC 
 
  SELECT TOP 20 * FROM otccatalog.WalletPlans  where InsuranceCarrierId =7 and InsuranceHealthPlanId =14
 [otccatalog].[WalletPlans]
  select top 20 *from insurance.insuranceConfig ORDER BY ModifyDate DESC
 
select top 10 *from insurance.InsuranceCarriers where  InsuranceCarrierID =267  --InsuranceCarrierName like'%Clear spring%' --277
select top 10 *from insurance.InsuranceCarriers where  InsuranceCarrierName like'%Healthfirst (New York)%' --277
select InsuranceHealthPlanId,configData  from insurance.InsuranceConfig where InsuranceHealthPlanId is not null and configType='FISCONFIGURATION'
 select top 20 *from insurance.insuranceConfig  where InsuranceCarrierID =267 order by modifydate desc
 select *From  insurance.insuranceConfig WHERE  InsuranceCarrierId =271
 DELETE FROM insurance.insuranceConfig  WHERE configid in (404,
533,
532,
531)
 select   *from  insurance.insurancehealthplans  WHERE InsuranceCarrierID =380   healthPlanNumber='H7844-001-000'-- HealthPlanName ='Molina Dual Options MI Health Link Medicare-Medicaid Plan'

 select top 20  *from otccatalog.WalletPlans where InsuranceCarrierID=267  order by 1  desc
 
 select top 20  *from otccatalog.Wallets  where walletId = 60 order by 1  desc
  select top 20  *from  master.memberInsuranceDetails_bk order by 1  desc [otc].[ReturnLoginAuthenticationResponse]
   select top 20  *from  [Master].[MemberInsurances]  order by 1  desc
   select top 10 *From master.memberInsuranceDetails_bk where MemberInsuranceID  IN (SELECT ID FROM  [Master].[MemberInsurances] WHERE InsuranceCarrierID =138)
 sp_helptext '[otc].[ReturnLoginAuthenticationResponse]'  
 sp_helptext '[otc].[AuthenticateOTCFlexStandardLogin]'

 --- sp_helptext '[otc].[ReturnLoginAuthenticationResponse_09Nov]' -- modified
 --- sp_helptext '[otc].[AuthenticateOTCNationsStandardLogin_Nov10]'  -- modified.
 -- [otc].[LoginAuthentication_Nov10]  replaced [otc].[AuthenticateOTCNationsStandardLogin to [otc].[AuthenticateOTCNationsStandardLogin_Nov10]
 sp_helptext '[otc].[ReturnLoginAuthenticationResponse_09Nov]'
   select top 10 *From  [benefitcard].[changeRequest] order by 1  desc

   DROP TABLE
   -- sp_helptext '[otc].[LoginAuthentication]'
 isChronicallyIll
0
MemberOptedForSSBCI
0IsProcessed
0

[{"requestId":31,"walletCode":"Grocery","IsProcessed":false,"UserPromptIndicator":false}]

SELECT TOP 10 *FROM [benefitcard].[changeRequest] order by 1 desc   

UPDATE [benefitcard].[changeRequest]  SET CreateDate = '2021-11-27 02:25:49.4754907'
where requestid =60

UPDATE [benefitcard].[changeRequest]  SET isProcessed =1
where requestid =60



UserPromptIndicator
1


[{"requestId":31,"walletCode":"Grocery","isProcessed":false,"userPromptIndicator":false,"createDate":"2021-11-19T09:53:36.7500439"}]
UPDATE  [benefitcard].[changeRequest] SET UserPromptIndicator=0
where requestId = 29

UPDATE   [benefitcard].[changeRequest] SET isProcessed=1
where requestId = 48
29
delete from  [benefitcard].[changeRequest]
where requestId in (58)

SELECT TOP 1 *FROM [benefitcard].[changeRequest] WHERE InsuranceHealthPlanID =14 AND InsuranceCarrierID =7 AND NHMemberId ='NH202107354322' AND IsActive =1 ORDER BY 1 DESC

exec [otc].[LoginAuthentication]  'vibra',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":null,"SerialNumber":null,"InsuranceNumber":"vibra1312","UserName":null,"LoginUserName":null,"LoginPassword":"Just!123","ProgramCode":null,"CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":null,"GroupNo":null,"SubDomain":null,"BenefitSource":null}'
,false
{"walletCode":"Grocery"}



sp_helptext '[otc].[AuthenticateOTCNationsStandardLogin]'
--DECLARE @domain VARCHAR(100) ='eon'         
--DECLARE @envelopJson VARCHAR(2000)   ='{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":null,"SerialNumber":null,"InsuranceNumber":"nareshnn","UserName":null,"LoginUserName":null,"LoginPassword":"Nations@123","ProgramCode":null,"CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":null,"GroupNo":null,"SubDomain":null,"BenefitSource":null}'       
 -- DECLARE @envelopJson VARCHAR(2000)   ='{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":null,"NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":"6102812711000421204","SerialNumber":"99000006372","InsuranceNumber":null,"UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":null,"CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":null,"GroupNo":null,"SubDomain":null,"BenefitSource":null}'
 
 SELECT TOP 1 *FROM otccatalog.WalletPlans  WHERE InsuranceHealthPlanID =14 AND InsuranceCarrierID =7  order by 1 desc
 SELECT TOP 10 *FROM otccatalog.WalletPlans WHERE InsuranceHealthPlanID =14 AND InsuranceCarrierID =7   order by 1 desc
 
 UPDATE otccatalog.WalletPlans
 SET walletStandardData ='[13]'
 WHERE InsuranceHealthPlanID =14 AND InsuranceCarrierID =7 

  -- Opt-In requests tables
  --==============================

  SELECT TOP 10 *FROM otccatalog.WalletPlans  WHERE InsuranceHealthPlanID =14 AND InsuranceCarrierID =7  order by 1 desc
 select  *from  otccatalog.WalletAttributeMaster order by 1 desc
 SELECT TOP 10 *FROM [benefitcard].[changeRequest] order by 1 desc   
 SELECT * FROM otccatalog.WalletPlans where  walletId =146

 select top 10* from insurance.insuranceCarriers  where insuranceCarrierName  like '%molina' 
  select top 30 * from otccatalog.WalletAttributeMaster order by 1 desc
 UPDATE otccatalog.WalletAttributeMaster SET Data = JSON_MODIFY(Data,'$.indicator[0]',1)  WHERE walletAttributeId =11

 DELETE FROM otccatalog.WalletAttributeMaster  WHERE walletAttributeId =12
 SELECT TOP 10 * FROM otccatalog.WalletAttributeMaster  order by 1 desc


  select top 10 * from otccatalog.walletOverrides order by 1 desc




 insert into otccatalog.WalletAttributeMaster (name,Data,description, createUser,Createdate,Modifyuser,modifydate,isactive)
 values('SSBCIWallet',JSON_QUERY('[{"indicator": true,"memberConsent": true}]'),'opt-in SSBCIWallet ','systemUser',getdate(),'systemUser',getdate(),1) 

 UPDATE otccatalog.WalletAttributeMaster SET Data ='{"indicator": true,"memberConsent": true}' where walletAttributeId=13

 SELECT * FROM   otccatalog.WalletAttributeMaster WHERE name ='SSBCIWallet'
 master.memberInsurances
 

 DECLARE @walletAttributeId BIGINT
  SELECT @walletAttributeId =  walletAttributeId FROM   otccatalog.WalletAttributeMaster WHERE name ='SSBCIWallet'
  DECLARE @walletStandardData VARCHAR(100)
  SET @walletStandardData ='['+CAST (@walletAttributeId AS VARCHAR(100))+']'
  SELECT @walletStandardData AS walletStandardData


    select * from master.memberInsurances where id =10894364 and InsuranceCarrierID =267 and   InsuranceHealthPlanID =2593
   --SELECT TOP 10 *fROM otccatalog.WalletPlans  WHERE  InsuranceCarrierID =267 and   InsuranceHealthPlanID =2593 

   select top 10 *From master.memberInsuranceDetails where insuranceNbr ='vibrannn' order by 1 desc

   UPDATE master.memberInsurances SET SSBCIIndicator =1
   where   id =10894364 and InsuranceCarrierID =267 and   InsuranceHealthPlanID =2593
   
0
    
  SELECT TOP 10 *fROM otccatalog.WalletPlans ORDER BY 1 DESC
   UPDATE otccatalog.WalletPlans
 SET walletStandardData ='[13]'
 WHERE InsuranceHealthPlanID =2593 AND InsuranceCarrierID =267 AND walletId=146



SELECT TOP 10 *FROM [benefitcard].[changeRequest] order by 1 desc   

delete from [benefitcard].[changeRequest] where RequestId in (60

)
select top 10 *From otc.userProfiles order by 1 desc

--===   271  Capital Blue Cross
--=====================================================================================

select top 20 *From  insurance.insuranceConfig where   InsuranceCarrierId = 380--380 
select top 20 *From insurance.insurancecarriers where   InsuranceCarrierId = 271
select top 20 *From  insurance.insuranceConfig where   InsuranceCarrierId =271 AND configType ='OTCLOGIN' order by 1 desc

UPDATE insurance.insuranceConfig SET isactive =0 where configId =1064

UPDATE insurance.insuranceConfig SET configData =
 '{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"allowAgentAccess":false,"benefitValueSource":"fis","loginTemplate":"OTCFlexStandard","ReplaceWallets":[],"AddWallets":[],"MapWallets":{"02":"MOLINAGROCERY"},"tags":[]}'
 WHERE  InsuranceCarrierId =271 AND configType ='OTCLOGIN'

 INSERT INTO  insurance.insuranceConfig

select top 20 *From  insurance.insuranceConfig where     InsuranceCarrierId =271 AND configType ='CARRIERCONFIG' order by 1 desc
UPDATE insurance.insuranceConfig SET configData =
 '{"programType":"Funded","benefitTypes":["HA","OTC"]}'
 WHERE  InsuranceCarrierId =271 AND configType ='CARRIERCONFIG'

  select  *from insurance.insurancehealthplans where InsuranceCarrierId =271 order by 1 desc 

   select  *from Insurance.HealthPlanContracts  where InsuranceCarrierId =271 order by 1 desc    ---4171

  UPDATE otccatalog.WalletPlans
 SET walletStandardData ='[13]'
 WHERE InsuranceHealthPlanID =14 AND InsuranceCarrierID =7 


 --======   Vibra Health Plan - 267 ============================================================================

select top 20 *From  insurance.insuranceConfig where   InsuranceCarrierId =267 

select top 20 *From  insurance.insuranceConfig where   InsuranceCarrierId =267 AND configType ='OTCLOGIN' order by 1 desc

UPDATE insurance.insuranceConfig SET configData =
 '{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"allowAgentAccess":false,"benefitValueSource":"fis","loginTemplate":"OTCFlexStandard","ReplaceWallets":[],"AddWallets":[],"MapWallets":{"02":"MOLINAGROCERY"},"tags":[]}'
 WHERE  InsuranceCarrierId =267 AND configType ='OTCLOGIN'

select top 20 *From  insurance.insuranceConfig where     InsuranceCarrierId =267 AND configType ='CARRIERCONFIG' order by 1 desc
UPDATE insurance.insuranceConfig SET configData =
 '{"programType":"Funded","benefitTypes":["HA","OTC"]}'
 WHERE  InsuranceCarrierId =267 AND configType ='CARRIERCONFIG'




 DECLARE @ConfigData nvarchar(max)='{"ClientID": "644963","SubProgID": "797605"}'

 INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive)
		VALUES
		('FISCONFIGURATION',@ConfigData,267,GETDATE(),'systemUser',GETDATE(),'systemUser',1)

		select *from Insurance.insuranceconfig where InsuranceCarrierId =267

		 select  *from insurance.insurancehealthplans where InsuranceCarrierId =267 order by 1 desc 
 --========================================================
  
  select  *from insurance.insurancehealthplans where InsuranceCarrierId =267 order by 1 desc 

   -- 2593 (InsuranceHealthPlandId)  --Vibra Health Plan Retirees Platinum Plus (PPO)

   select  *from Insurance.HealthPlanContracts  where InsuranceCarrierId =267 order by 1 desc   
   -- 1593 Vibra Health Plan - Vibra Health Plan Retirees Platinum Plus (PPO) - Contract


   SELECT  TOP 20 * FROM otccatalog.Wallets  where WalletCode ='FISGROCERY' order by 1 desc
--INSERT INTO otccatalog.Wallets  (walletName,DisplayOrder,ShowonWeb,WalletCode,WalletSource,DisplayWalletName,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate,ColorCode,EffectiveDate,BenefitSpendingType)
--VALUES('FLEXGROCERY',1,1,'FISGROCERY','FIS','FISGROCERY',1,'systemUser',getdate(),'systemUser',getdate(),'#08E8DE',getdate(),'GROCERY')

SELECT * FROM otccatalog.WalletPlans where InsuranceCarrierId =267   --4171

 UPDATE otccatalog.WalletPlans
 SET walletStandardData ='[13]'
 WHERE InsuranceHealthPlanID =2593 AND InsuranceCarrierID =267 AND walletId=146




INSERT INTO otccatalog.WalletPlans (InsuranceCarrierId,insuranceHealthPlanId,WalletId,IsActive,CreateUser,CreateDate,ModifyDate,ModifyUser,EffectiveFrom )
values(267,2593,146,1,'systemUser',getdate(),getdate(),'systemUser',GETDATE())     246



select top 10 *From  insurance.Insurancecarriers where InsuranceCarrierName ='Molina Healthcare'
select top 10 *From  insurance.Insurancecarriers where InsuranceCarrierId =267



SELECT * FROM otccatalog.Wallets WHERE WalletCode = 'EON Health Plan' 

SELECT * FROM  rulesengine.BenefitRulesData order by 1 desc
select top 10 * from Insurance.ContractRules order by 1 desc
 
order  by 1 desc

[benefitcard].[changeRequest])

UserPromptIndicator
NULL

select top 10*From otc.userProfiles where subDomain ='alignmentpartners'order by 1 desc
{"MemberId":"nareshnn","NHMemberId":"NH202107354322","FirstName":"naresh","LastName":"nn","DateOfBirth":"1980-02-01"}

sp_helptext '[otc].[GetWalletStandardData]' 

[otc].[GetWalletStandardData] 7,14

select top 10 *From insurance.insuranceConfig where nhMemberId ='NH202107380095'  InsuranceCarrierID =7 

select top 10   *from Insurance.HealthPlanContracts   

select top 10   *from Insurance.HealthPlanContracts   where insuranceHealthPlanID in (select insuranceHealthPlanID  from  insurance.insurancehealthplans where InsuranceCarrierId =267)
where InsuranceCarrierId =267 AND HealthPlanContractId in ()  order by 1 desc

select  *from Insurance.ContractRules  where HealthPlanContractId 
in (select healthPlanContractID from Insurance.HealthPlanContracts where InsuranceCarrierId =267  )   order by 1 desc



select top 10 *From insurance.insuranceConfig  where InsuranceCarrierId =267

{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"allowAgentAccess":false,"loginTemplate":"OTCFlexStandard","ReplaceWallets":[],"AddWallets":[],"MapWallets":{"01":"FLEXOTC","02":"FLEXGROCERY","03":"FLEXREWARDS"},"tags":[]}

	select top 30 *from rulesengine.BenefitRules order by 1 desc  --275
select top 30 *from rulesengine.BenefitRulesData   order by 1 desc  --275  262

select  *from Insurance.HealthPlanContracts 

select top 10 * from  otc.userProfiles where userName like '%vibra%' order by 1 desc

  DECLARE @configData NVARCHAR(MAX) 
		 SELECT @configData = ConfigData FROM   Insurance.insuranceconfig   WHERE InsuranceCarrierId =271 AND configType ='FISCONFIGURATION'
		 select @configData
		 SET @configData = JSON_MODIFY(@configData,'$.ClientID','8332911312') 
		 SET @configData = JSON_MODIFY(@configData,'$.SubProgID','23232') --ConfigData FROM   Insurance.insuranceconfig   WHERE InsuranceCarrierId =267 AND configType ='FISCONFIGURATION'
		 SELECT @configData




		 INSERT INTO rulesengine.BenefitRulesData (benefitRuleId,BenefitRuleData,CreateUser,CreateDate,ModifyUser,ModifyDate,isActive)
											VALUES(2,@benefitRuleData,@systemUser,getdate(),@systemUser,getdate(),1)

											select top 10 *From  rulesengine.BenefitRulesData order by 1 desc

select top 10 *from Insurance.ContractRules where BenefitRuleDataId = 294  order by 1 desc

SELECT HealthPlanContractId FROM Insurance.HealthPlanContracts where insuranceHealthPlanID in
(select insuranceHealthPlanID  from  insurance.insurancehealthplans where InsuranceCarrierId =267) 


SELECT hp.HealthPlanContractId, ihp.* FROM Insurance.HealthPlanContracts hp 
INNER JOIN insurance.insurancehealthplans ihp ON ihp.insuranceHealthPlanID =hp.insuranceHealthPlanID
WHERE  ihp.InsuranceCarrierId =267


select top 10 *from Insurance.ContractRules order by 1 desc
 INSERT INTO Insurance.ContractRules
(BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,ModifyUser,CreateDate,ModifyDate)
VALUES(294,4381,GETDATE(),'2099-12-31 00:00:00.000','systemUser','systemUser',getdate(),getdate()) 

DROP TABLE #healthPlnCntrctTbl
SELECT *INTO #healthPlnCntrctTbl 
FROM (
SELECT hp.HealthPlanContractId, ihp.* FROM Insurance.HealthPlanContracts hp 
INNER JOIN insurance.insurancehealthplans ihp ON ihp.insuranceHealthPlanID =hp.insuranceHealthPlanID
WHERE  ihp.InsuranceCarrierId =267

)AS F


SELECT *FROM  #healthPlnCntrctTbl
SELECT *FROM Insurance.ContractRules WHERE healthPlanContractID in (SELECT healthPlanContractID from  #healthPlnCntrctTbl) and BenefitRuleDataId =294
 INSERT INTO Insurance.ContractRules
(BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,ModifyUser,CreateDate,ModifyDate)
SELECT 
VALUES(@benefitRuleId,4381,GETDATE(),'2099-12-31 00:00:00.000','systemUser','systemUser',getdate(),getdate()) 


select  * from  rulesengine.BenefitRulesData ORDER BY 1 DESC
select  * from  insurance.insurancehealthplans where InsuranceCarrierId =267
		 select top 10 *from Insurance.ContractRules  where HealthPlanContractId in ( SELECT HealthPlanContractId FROM Insurance.HealthPlanContracts  
where insuranceHealthPlanID in (select insuranceHealthPlanID  from  insurance.insurancehealthplans where InsuranceCarrierId =267)) order by 1 desc


SELECT *FROM  Insurance.ContractRules where BenefitRuleDataId =275 order by 1 desc
--delete from  Insurance.ContractRules where BenefitRuleDataId =275

select  *From Insurance.HealthPlanContracts where   InsuranceCarrierId =267 order by 1 desc