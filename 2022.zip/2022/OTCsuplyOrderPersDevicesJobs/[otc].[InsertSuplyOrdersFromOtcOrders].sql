/****** Object:  StoredProcedure [otc].[InsertPersSuplyOrdersFromOtcOrders]    Script Date: 08-03-2021 19:22:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO
                  
                    
                    
/* =============================================                    
  Author: Naresh Naspoori                           
  Updated Date: 01-NOV-2021                    
  Description: inserts orders to SupplOrders schema tables (Pers devices orders) from otc PERS orders                 
  =============================================                    
   exec [otc].[InsertPersSuplyOrdersFromOtcOrders] 200783800       
*/                
                
         
CREATE PROC [otc].[InsertPersSuplyOrdersFromOtcOrders]         
 @OrderId BIGINT       
AS                    
BEGIN                    
 BEGIN TRY                    
  BEGIN TRAN             
          
  --DECLARE @OrderId BIGINT =200784106        
        
  DECLARE @OrderData NVARCHAR(MAX)         
  DECLARE @ItemData NVARCHAR(MAX)        
  DECLARE @systemUser VARCHAR(40)='systemUser'        
        
  DECLARE @OrderAmountData  NVARCHAR(MAX) =(SELECT OrderAmountData FROM [ORDERS].[ORDERS] WHERE orderId =@OrderId)        
  SET @OrderData =(SELECT JSON_QUERY(ShippingData,'$.additionalShippingInfo.userInfo') FROM [ORDERS].[ORDERS] WHERE orderId =@OrderId)        
  SET @OrderData= JSON_MODIFY(@OrderData,'$.emergencyContactsDetails',  (SELECT JSON_QUERY(ShippingData,'$.additionalShippingInfo.emegencyContactsDetails') FROM [ORDERS].[ORDERS] WHERE orderId =@OrderId ))        
      
  -- memberData     
  DECLARE @memberData NVARCHAR(MAX) = (SELECT JSON_MODIFY(oo.MemberData,'$.insCarrierName',iic.insuranceCarrierName) FROM [ORDERS].[ORDERS] oo     
                                             INNER JOIN  insurance.insurancecarriers iic ON iic.InsuranceCarrierId =CAST(JSON_VALUE(oo.MemberData,'$.clientCarrierId')AS BIGINT)    
                                             WHERE oo.orderId=@orderId)    
  SET @memberData = (SELECT JSON_MODIFY(@memberData,'$.insPlanName',iip.healthPlanName) FROM [ORDERS].[ORDERS] oo     
                                             INNER JOIN  insurance.insurancehealthplans iip ON iip.InsuranceHealthPlanId =CAST(JSON_VALUE(oo.MemberData,'$.clientPlanId')AS BIGINT)    
                                             WHERE oo.orderId=@orderId)     
    
  DECLARE @suplyOrderAmountData NVARCHAR(MAX) ='{}'  
  SET @suplyOrderAmountData =(select JSON_MODIFY(@suplyOrderAmountData,'$.memberResponsibility',JSON_VALUE(orderAmountData,'$.outOfPocket')) FROM [ORDERS].[ORDERS] WHERE orderId =@orderId)  
  SET @suplyOrderAmountData =(select JSON_MODIFY(@suplyOrderAmountData,'$.productPrice',JSON_VALUE(orderAmountData,'$.price')) FROM [ORDERS].[ORDERS] WHERE orderId =@orderId)  
     
   -- inserts supply Orders        
IF NOT EXISTS (SELECT *FROM [SupplOrders].[Orders] WHERE RefOrderId =@OrderId AND IsActive = 1 )
BEGIN
  INSERT INTO [SupplOrders].[Orders]                     
   (        
    OrderDate        
   ,NHMemberId        
   ,InsuranceCarrierID        
   ,InsuranceHealthPlanID        
   ,ShippingAddress        
   ,Status        
   ,OrderType        
   ,Amount        
   ,CreateDate        
   ,CreateUser        
   ,ModifyUser        
   ,ModifyDate        
   ,IsActive        
   ,MemberData        
   ,OrderAmountData        
   ,OrderData        
   ,OrderSource        
   ,RefOrderId        
   )                    
  SELECT               
    GETDATE() AS OrderDate,            
    NHMemberId                    
   ,CAST(JSON_VALUE(MemberData,'$.clientCarrierId')AS BIGINT)AS InsuranceCarrierID                     
   ,CAST(JSON_VALUE(MemberData,'$.clientPlanId')AS BIGINT)AS InsuranceHealthPlanID                    
   ,JSON_MODIFY(ShippingData,'$.additionalShippingInfo',NULL) As ShippingAddress                  
   ,'DOC_Pending' AS Status                 
   ,'PERS' AS OrderType              
   ,(CAST(JSON_VALUE(OrderAmountData,'$.amountCovered')AS DECIMAL(9,2))+CAST(JSON_VALUE(OrderAmountData,'$.outOfPocket') AS DECIMAL(9,2))) AS Amount                   
   ,GETDATE() AS CreateDate        
   ,@systemUser AS CreateUser        
   ,@systemUser AS ModifyUser        
   ,GETDATE() AS ModifyDate        
   ,1 AS isActive        
   ,@memberData AS MemberData       
   ,@suplyOrderAmountData AS OrderAmountData   
   ,@OrderData AS OrderData        
   ,Source AS OrderSource        
   ,OrderId AS RefOrderId        
  FROM [ORDERS].[ORDERS] WHERE orderId =@OrderId        
        
     --- Supply orderitems inserts        
 INSERT INTO [SupplOrders].[OrderItems] (        
  OrderId        
 ,ItemCode        
 ,ItemType        
 ,Price        
 ,Quantity        
 ,CreateUser        
 ,CreateDate        
 ,ModifyUser        
 ,ModifyDate        
 ,IsActive        
 ,ItemData)        
         
 SELECT         
   (SELECT orderId FROM  [SupplOrders].[Orders] WHERE refOrderId =@OrderId ) AS OrderId        
  ,im.itemCode        
  ,im.itemType        
  ,oi.amount AS Price        
  ,oi.Quantity        
  ,@systemUser AS CreateUser        
  ,GETDATE() AS CreateDate        
  ,@systemUser AS ModifyUser        
  ,GETDATE()AS ModifyDate        
  ,1 AS isActive        
  ,('{"itemName":"'+ im.itemDisplayName +'"}')as  ItemData        
   FROM [ORDERS].[ORDERITEMS] oi INNER JOIN [ORDERS].[ORDERS] oo ON oo.orderId=oi.orderId         
  INNER JOIN [SupplOrders].[ItemMaster] im ON  JSON_VALUE(oi.ItemData,'$.nationsId')  = JSON_VALUE(im.ItemAdditionalData,'$.nationsId')        
  WHERE  oo.orderId =@OrderId AND JSON_VALUE(oo.OrderAmountData,'$.warehouseCode')='ADT'          
  AND JSON_VALUE(oo.OrderAmountData,'$.isProcessedAsSupply') IS  NULL         
  AND oo.OrderStatusCode='INI' AND oo.IsActive =1  AND oi.IsActive=1 AND  im.IsActive=1        
  order by oo.orderId asc        
        
 -- INSERTS [SupplOrders].[ordershistory]   
 INSERT INTO [SupplOrders].[ordershistory]   
 (OrderId  
 ,OrderDate  
 ,NHMemberId  
 ,InsuranceCarrierID  
 ,InsuranceHealthPlanID  
 ,ShippingAddress  
 ,Status  
 ,OrderType  
 ,Amount  
 ,CreateUser  
 ,CreateDate  
 ,ModifyUser  
 ,ModifyDate  
 ,IsActive  
 ,MemberData  
 ,OrderAmountData  
 ,OrderData  
 ,Action)  
   
 SELECT   
  OrderId   
 ,GETDATE()  
 ,NHMemberId  
 ,InsuranceCarrierID  
 ,InsuranceHealthPlanID  
 ,ShippingAddress  
 ,Status  
 ,OrderType  
    ,Amount   
 ,@systemUser AS CreateUser  
 ,GETDATE() AS CreateDate  
 ,@systemUser AS ModifyUser  
 ,GETDATE() AS ModifyDate  
 ,1  
 ,MemberData  
 ,OrderAmountData  
    ,OrderData  
 ,'Updated on Status'  
 FROM [SupplOrders].[Orders] WHERE refOrderId = @OrderId   
  
  
 -- update suply [DocumentTransaction]'s orderid  if documenet is exists        
 IF(ISNULL(JSON_VALUE(@OrderAmountData,'$.documentId'),0)!=0)        
   BEGIN        
 UPDATE  [SupplOrders].[DocumentTransaction]        
    SET orderId = (SELECT orderId FROM  [SupplOrders].[Orders]  WHERE RefOrderId = @OrderId)        
 ,modifyDate =GETDATE(), modifyUser = @systemUser        
    WHERE DocumentId = CAST (JSON_VALUE(@OrderAmountData,'$.documentId') AS BIGINT) AND  IsActive=1        
   END        
          
  -- FINAL UPDATE ORDER.ORDERS         
  UPDATE [ORDERS].[ORDERS] SET orderAmountData =JSON_MODIFY(orderAmountData,'$.isProcessedAsSupply',CAST(1 as bit))        
   ,orderStatusCode ='ACK',modifyDate =GETDATE(), modifyUser=@systemUser        
   WHERE orderId =@OrderId AND IsActive=1        
       
END

	   
  COMMIT          
  END TRY                    
                    
 BEGIN CATCH                    
  DECLARE @ErrorMessage NVARCHAR(4000);                    
  DECLARE @Severity INT;                    
  DECLARE @ErrorState INT;                    
                    
  SELECT @ErrorMessage = ERROR_MESSAGE()                    
   ,@Severity = ERROR_SEVERITY()                    
   ,@ErrorState = ERROR_STATE()                    
                    
  RAISERROR (                    
    @ErrorMessage                    
    ,@Severity                    
    ,@ErrorState                    
    )                    
                    
  PRINT (@ErrorMessage)                    
  PRINT (@Severity)                    
  PRINT (@ErrorState)                    
                    
  ROLLBACK                    
 END CATCH                    
END