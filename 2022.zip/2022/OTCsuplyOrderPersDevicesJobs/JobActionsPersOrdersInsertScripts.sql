--Inserting  Actions and Action code to process OTC PERS ORDERS inserts to SUPLY Orders 
BEGIN TRY 
	BEGIN TRAN 
	-- INSERT ACTIONS
INSERT INTO  [jobs].[Actions] 
(ActionName,ActionCode,IsActive,CreateDate,CreateUser,ModifyDate,ModifyUser)
 VALUES('GET OTC pers orders process to suplyOrders','SpmOrders',1, getdate(),'System', Getdate(),'System')

SELECT 'Inserted INTO [jobs].[Actions]' AS RESULT

SELECT TOP 1 * FROM jobs.Actions ORDER BY ActionId DESC

-- INSERT PageActionProcessQueue FOR Continuous
INSERT INTO [jobs].[PageActionProcessQueue]
(ActionCode,ProcessStatus,IsActive,CreateDate,CreateUser,ModifyDate,ModifyUser,IsContinuous)
VALUES ('SpmOrders',0,1,GETDATE(),'System',GETDATE(),'System',1)

SELECT TOP 1  * FROM [jobs].[PageActionProcessQueue]   ORDER BY PageActionProcessQueueId DESC
COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH