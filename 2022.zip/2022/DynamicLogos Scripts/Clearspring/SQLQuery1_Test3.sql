select  TOP 40  *from  insurance.insurancehealthplans  WHERE InsuranceCarrierID =274   ORDER BY 1 DESC


2554
2555
2561
2558
2560
2559

 -- H5454_003 Clear Spring Health Essential Plus HMO Illinois -oh-mmp-logo
 --  H5454_004 Clear Spring Health Essential Plus HMO Illinois -passport-logo
 -- H5454_001 Clear Spring Health Essential HMO Illinois-  mi-mmp-logo
select top 10 *from insurance.InsuranceCarriers where InsuranceCarrierName like'%clear spring%' --277
 select  *from insurance.insuranceConfig  where InsuranceCarrierID =274 order by 1 desc

 delete from insurance.insuranceConfig where configid in (420,424,425)
 --passport-logo
 --oh-mmp-logo
 -- mi-mmp-logo
 --passport-logo
--  sc-mmp-logo
--swh-logo 
--tx-mmp-logo

  -- H6379_001 Clear Spring Health Essential HMO Colorado oh-mmp-logo  2563
  -- H8293_001 Clear Spring Health Essential HMO Virginia passport-logo 2562
  --H5454_001 Clear Spring Health Essential HMO Illinois mi-mmp-logo 2561
  -- H5454_002 Clear Spring Health Essential HMO Illinois sc-mmp-logo 2560
 select top 10 *from  otccatalog.walletplans order by 1 desc
 select top 10 *from Insurance.ContractRules  order by 1 desc
 select * from Insurance.HealthPlanContracts where InsuranceCarrierID=380 order by 1 desc

 SELECT    *FROM rulesengine.benefitrulesdata WHERE JSON_VALUE(BenefitRuleData,'$.WALCODE')='MOLINAGROCERY' AND IsActive =1

 SELECT TOP 10 * FROM  otccatalog.walletplans where InsuranceCarrierId =380
  SELECT TOP 10 * FROM  otccatalog.wallets where 
  WalletName like '%flex%'
select top 10 * from Insurance.ContractRules where HealthPlanContractId in ( select HealthPlanContractId from Insurance.HealthPlanContracts where InsuranceCarrierID=380 )


{"isRegisterable":true,"isManaged":true,"isLoginRestricted":false,"allowAgentAccess":false,"benefitValueSource":"fis","loginTemplate":"OTCFlexStandard","ReplaceWallets":[],"AddWallets":[],"MapWallets":{"01":"MOLINAGROCERY"},"tags":[]}

select top 200 *From insurance.insurancehealthplans order by 1 desc
delete from  insurance.insurancehealthplans where InsuranceHealthPlanID IN(4149,
4148)

DELETE FROM  insurance.insuranceConfig  where InsuranceHealthPlanID IN(4149,
4148)


BenefitRuleDataId
265
DECLARE @healtPlanName NVARCHAR(MAX) =
DECLARE @healthPlanNumber NVARCHAR(MAX)=

DECLARE @systemUser VARCHAR(100)='scripts';
IF NOT EXISTS (select   *from  insurance.insurancehealthplans  WHERE HealthPlanName =@healthPlanName)
   BEGIN 
         INSERT INTO insurance.insurancehealthplans (HealthPlanName,HealthPlanNumber,InsuranceCarrierID,IsActive,CreateUser,CreateDate,ModifyUser,ModifyDate)
		 VALUES
		 (@healthPlanName,@healthPlanNumber,@carrierId,1,@systemUser,GETDATE(),@systemUser,GETDATE())
		
		SELECT @insuranceHealthPlanId = insuranceHealthPlanId FROM insurance.insurancehealthplans  WHERE healthPlanName =@healthPlanName
		 PRINT CONCAT('insuranceHealthPlanId:',ISNULL(@insuranceHealthPlanId,0))
   END
ELSE 
  BEGIN
        SELECT @insuranceHealthPlanId = insuranceHealthPlanId FROM insurance.insurancehealthplans  WHERE healthPlanName =@healthPlanName
  END

  IsDiscountProgram



  DECLARE @itemAttrData VARCHAR(100) = '[1,2,3,12]'
PRINT @itemAttrData

SELECT br.*,value
from Insurance.ContractRules br      
INNER JOIN OPENJSON(JSON_QUERY(@itemAttrData, '$')) ia ON  1 = 1 and CAST(value AS BIGINT) = br.ContractRuleId  



  DECLARE @itemAttrData VARCHAR(100) = '[27,26,25]'
  DECLARE @walletConfig NVARCHAR(MAX)
PRINT @itemAttrData

 set @walletConfig = (select br.Name,br.data --,value
from otccatalog.ItemAttributeMaster br      
INNER JOIN OPENJSON(JSON_QUERY(@itemAttrData, '$')) ia ON  1 = 1 and CAST(value AS BIGINT) = br.ItemAttributeId 

FOR JSON AUTO )

SELECT  @walletConfig

27
select top 10 *from otccatalog.walletsstandarddata
 select top 10 *from otccatalog.WalletPlans order by 1 desc
  select top 10 *from otccatalog.ItemAttributeMaster order by 1 desc

-- Molina Dual Options MI Health Link Medicare-Medicaid Plan  380(carrierId)  4144 (insuranceHealthPlanId) -- mi-mmp-logo
-- Molina Dual Options MyCare Ohio (Medicare-Medicaid Plan)  380(carrierId) 4145(insuranceHealthPlanId) -- oh-mmp-logo

walletConfig:[{"SSBCIWallets":[{"wallet": "FREESCALE","indicator": true,"memberConsent": false}],{"tags":[{"wallet": "FREESCALE","indicator": true,"memberConsent": false}],{}]
--{"SSBCIWallets":[{"wallet": "FREESCALE","indicator": true,"memberConsent": false}]}

name, value