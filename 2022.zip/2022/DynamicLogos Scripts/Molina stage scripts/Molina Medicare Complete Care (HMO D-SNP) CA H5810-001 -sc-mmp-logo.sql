BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
--------------------------------------STEP:1- Create Carrier and configure OTCAPP AND for plan level logo MOLINA required configurations-------------------------------------------------------------------------------------------------

DECLARE @carrierName NVARCHAR(100)='Molina Healthcare'
DECLARE @carrierId BIGINT
DECLARE @otcAppConfig NVARCHAR(MAX) 

DECLARE @planCode NVARCHAR(MAX) ='sc-mmp-logo' 
DECLARE @OTCAPP VARCHAR(50) ='OTCAPP'
DECLARE @healthPlanName NVARCHAR(MAX)='Molina Medicare Complete Care (HMO D-SNP) CA H5810-001'
DECLARE @insuranceHealthPlanId BIGINT 
DECLARE @planCodeInserted NVARCHAR(MAX)

DECLARE @systemUser VARCHAR(50)='script'


SELECT @insuranceHealthPlanId = insuranceHealthPlanId FROM insurance.insurancehealthplans  WHERE healthPlanName =@healthPlanName AND IsActive=1
PRINT CONCAT('insuranceHealthPlanId:',ISNULL(@insuranceHealthPlanId,0));
SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName  AND IsActive =1
PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));

SELECT @otcAppConfig =ConfigData FROM Insurance.insuranceconfig WHERE InsuranceCarrierID=@carrierid AND ConfigType=@OTCAPP AND InsuranceHealthPlanId IS NULL AND IsActive =1
--PRINT CONCAT('otcAppConfig:',@otcAppConfig)

SET @otcAppConfig =JSON_MODIFY(@otcAppConfig,'$.planCode',@planCode)
PRINT CONCAT('updated otcAppConfig:',@otcAppConfig)



IF(ISNULL(@carrierId,0)>0)
 
---INSERTING CONFIGURATIONS('OTCAPP',planCode in ConfigData ) 
IF NOT EXISTS(select * from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid and ConfigType=@OTCAPP and InsuranceHealthPlanId =@insuranceHealthPlanId)
	BEGIN
		INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive,InsuranceHealthPlanId)
		VALUES
		(@OTCAPP,@otcAppConfig,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1,@insuranceHealthPlanId)
	END

ELSE
	BEGIN
		UPDATE Insurance.insuranceconfig
		SET ConfigData=IIF(ISNULL(ConfigData,'')='', @otcAppConfig, JSON_MODIFY(ConfigData,'$.planCode',@planCode)), 
		ModifyDate=GETDATE(), ModifyUser=@systemUser
		WHERE InsuranceCarrierID=@carrierid and ConfigType=@OTCAPP and InsuranceHealthPlanId = @insuranceHealthPlanId AND IsActive =1
	END

	SELECT  @planCodeInserted =  JSON_VALUE(ConfigData,'$.planCode') from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid AND ConfigType=@OTCAPP and InsuranceHealthPlanId = @insuranceHealthPlanId
IF(@planCodeInserted IS NOT NULL)
BEGIN
PRINT  CONCAT('succefully executed. PlanCode:',@planCodeInserted)
END
COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH

