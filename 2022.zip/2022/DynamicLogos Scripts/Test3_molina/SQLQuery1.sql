select top 10 *from insurance.InsuranceCarriers where InsuranceCarrierName like'%Molina Healthcare%' --277

select top 10 *from insurance.InsuranceConfig where InsuranceCarrierID = 380

 select top 10 *from Insurance.ContractRules  order by 1 desc
 select  TOP 10   *from  insurance.insurancehealthplans  -- WHERE InsuranceHealthPlanId =   1347 
  ORDER BY 1 DESC


  --Molina Dual Options MI Health Link Medicare-Medicaid Plan  4124-- done
--  Molina Dual Options (Medicare-Medicaid Plan) 1347
--  Molina Dual Options MyCare Ohio (Medicare-Medicaid Plan) 4125 
--Molina Dual Options STAR+PLUS Medicare-Medicaid Plan H8197-002-001  4126
--Molina Dual Options STAR+PLUS Medicare-Medicaid Plan H8197-002-002  4127
--Passport Advantage (HMO D-SNP) 4128
--Passport Medicare Choice Care (HMO)  4129