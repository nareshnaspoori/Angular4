BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'
--------------------------------------STEP:1- Create Carrier and configure OTCAPP AND for plan level logo MOLINA required configurations-------------------------------------------------------------------------------------------------

DECLARE @carrierName NVARCHAR(100)='Molina Healthcare'
DECLARE @carrierId BIGINT
DECLARE @carrierConfig NVARCHAR(MAX)='{"subdomain":"molina2","benefitValueSource":"fis","isManaged":true,"carrierCode":"molina2"}'

DECLARE @otcAppConfig NVARCHAR(MAX) ='{"canSubscribe":false,"isHealthProfileDisabled":false,"alwaysViewCatalog":false,"disablePromotions":false,"expressOrderEnabled":true,"Preferences":{"OrderUpdates" :{"sendEmail": true, "sendSMS": false}},"planCode":"sc-mmp-logo"}'
DECLARE @planCode NVARCHAR(MAX) ='sc-mmp-logo' 
DECLARE @OTCAPP VARCHAR(50) ='OTCAPP'
DECLARE @insuranceHealthPlanId BIGINT 
DECLARE @healthPlanContractId  BIGINT
DECLARE @healthPlanName NVARCHAR(MAX)='Molina Dual Options (Medicare-Medicaid Plan)'
DECLARE @healthPlanNumber NVARCHAR(MAX) ='H2533-001-000'
DECLARE @EffectivetToDate NVARCHAR(MAX) ='2099-12-31 00:00:00.000'
DECLARE @planCodeInserted NVARCHAR(MAX)
DECLARE @carrierCode  VARCHAR(50) ='molina2'
DECLARE @systemUser VARCHAR(100)='scripts';
DECLARE @walletCode VARCHAR(100) ='MOLINAGROCERY'
DECLARE @benefitRuleDataId BIGINT 


SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName 
PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));

IF(ISNULL(@carrierId,0)>0)
 BEGIN
------Update Config {"subdomain":"molina","carrierCode":"molina"}
 UPDATE Insurance.InsuranceCarriers
 SET CarrierConfig = IIF(ISNULL(CarrierConfig,'') ='',@carrierConfig, JSON_MODIFY(JSON_MODIFY(CarrierConfig,'$.subdomain',@carrierCode),'$.carrierCode',@carrierCode)),ModifyDate=GETDATE(),ModifyUser=@systemUser
 WHERE InsuranceCarrierID=@carrierId AND IsActive=1
 END
ELSE
 BEGIN
 --INSERTING CARRIER
 INSERT INTO insurance.insurancecarriers (CreateDate,CreateUser,InsuranceCarrierName,IsActive,IsContracted,IsDiscountProgram,MemberDataFileProvided,ModifyDate,ModifyUser,IsAutoSendPaymentReceipt,CarrierConfig,IsNHDiscount,AllowAdditionalServices)
 VALUES (getdate(),@systemUser,@carrierName,1,1,0,0,getdate(),@systemUser,0,@carrierConfig,0,0)

 --SELECT INSERTED CARRIERID
 SELECT @carrierId=insurancecarrierId FROM insurance.insurancecarriers  WHERE InsuranceCarrierName=@carrierName AND IsActive=1
 PRINT CONCAT('InsuranceCarrierId:',ISNULL(@carrierId,0));
END


-- inserts healthPlanName if not exists 

IF NOT EXISTS (select   *from  insurance.insurancehealthplans  WHERE HealthPlanName =@healthPlanName and IsActive=1)
   BEGIN 
         INSERT INTO insurance.insurancehealthplans (HealthPlanName,HealthPlanNumber,InsuranceCarrierID,IsActive,IsDiscountProgram,CreateUser,CreateDate,ModifyUser,ModifyDate)
		 VALUES
		 (@healthPlanName,@healthPlanNumber,@carrierId,1,0,@systemUser,GETDATE(),@systemUser,GETDATE())
		
		SELECT @insuranceHealthPlanId = insuranceHealthPlanId FROM insurance.insurancehealthplans  WHERE healthPlanName =@healthPlanName AND IsActive=1
		 PRINT CONCAT('insuranceHealthPlanId:',ISNULL(@insuranceHealthPlanId,0))
   END
ELSE 
  BEGIN
           UPDATE  insurance.insurancehealthplans SET healthPlanNumber =@healthPlanNumber,ModifyDate=GETDATE(),ModifyUser=@systemUser
           WHERE healthPlanName =@healthPlanName AND IsActive=1
        SELECT @insuranceHealthPlanId = insuranceHealthPlanId FROM insurance.insurancehealthplans  WHERE healthPlanName =@healthPlanName AND IsActive=1
		PRINT CONCAT('insuranceHealthPlanId:',ISNULL(@insuranceHealthPlanId,0))
  END

 
  
  --- inserts HealthPlanContracts

IF NOT EXISTS(SELECT *FROM Insurance.HealthPlanContracts WHERE InsuranceHealthPlanID = @insuranceHealthPlanId AND IsActive=1 )
   BEGIN
         INSERT INTO Insurance.HealthPlanContracts (ContractName,Description,EffectiveFromDate,EffectiveToDate,InsuranceCarrierID,InsuranceHealthPlanID,IsActive,ModifyDate,ModifyUser,CreateDate,CreateUser)
		 VALUES(@healthPlanName,@healthPlanName,GETDATE(),@EffectivetToDate,@carrierId,@insuranceHealthPlanId,1,GETDATE(),@systemUser,GETDATE(),@systemUser)
		 SELECT @healthPlanContractId =HealthPlanContractId  FROM  Insurance.HealthPlanContracts WHERE InsuranceHealthPlanID = @insuranceHealthPlanId
		 PRINT CONCAT('healthPlanContractId:',ISNULL(@healthPlanContractId,0))
   END
ELSE 
    BEGIN
	    SELECT @healthPlanContractId =HealthPlanContractId  FROM  Insurance.HealthPlanContracts WHERE InsuranceHealthPlanID = @insuranceHealthPlanId AND  IsActive=1
		PRINT CONCAT('healthPlanContractId:',ISNULL(@healthPlanContractId,0))
    END


	 SELECT @benefitRuleDataId = BenefitRuleDataId FROM rulesengine.benefitrulesdata WHERE JSON_VALUE(BenefitRuleData,'$.WALCODE')=@walletCode AND IsActive =1

	  --- inserts Insurance.ContractRules

IF NOT EXISTS (SELECT *FROM Insurance.ContractRules WHERE BenefitRuleDataId=BenefitRuleDataId AND HealthPlanContractId =@healthPlanContractId AND IsActive =1 )
  BEGIN
       INSERT INTO  Insurance.ContractRules (BenefitRuleDataId,HealthPlanContractId,EffectiveFrom,EffectiveTo,CreateUser,CreateDate,ModifyUser,ModifyDate,IsActive)
	   VALUES(@benefitRuleDataId,@healthPlanContractId,GETDATE(),@EffectivetToDate,@systemUser,GETDATE(),@systemUser,GETDATE(),1)
  END

---INSERTING CONFIGURATIONS('OTCAPP',planCode in ConfigData ) 
IF NOT EXISTS(select * from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid and ConfigType=@OTCAPP and InsuranceHealthPlanId =@insuranceHealthPlanId and IsActive=1)
	BEGIN
		INSERT INTO Insurance.insuranceconfig (ConfigType,ConfigData,InsuranceCarrierID,CreateDate,CreateUser,ModifyDate,ModifyUser,IsActive,InsuranceHealthPlanId)
		VALUES
		(@OTCAPP,@otcAppConfig,@carrierid,GETDATE(),@systemUser,GETDATE(),@systemUser,1,@insuranceHealthPlanId)
	END

ELSE
	BEGIN
		UPDATE Insurance.insuranceconfig
		SET ConfigData=IIF(ISNULL(ConfigData,'')='', @otcAppConfig, JSON_MODIFY(ConfigData,'$.planCode',@planCode)), 
		ModifyDate=GETDATE(), ModifyUser=@systemUser
		WHERE InsuranceCarrierID=@carrierid AND ConfigType=@OTCAPP AND InsuranceHealthPlanId = @insuranceHealthPlanId AND IsActive=1
	END

	SELECT  @planCodeInserted =  JSON_VALUE(ConfigData,'$.planCode') from Insurance.insuranceconfig where InsuranceCarrierID=@carrierid AND ConfigType=@OTCAPP and InsuranceHealthPlanId = @insuranceHealthPlanId AND IsActive=1
IF(@planCodeInserted IS NOT NULL)
BEGIN
PRINT  CONCAT('succefully executed. PlanCode:',@planCodeInserted)
END
COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH

