
 select top 10 *from  member.membercards where nhmemberId ='NH202210333779'

 select  top 1 memberId from   master.members where nhmemberId in ('NH202210333779'
)


select top 10 *From  eligibility
 select top 10 *From [otc].[MemberEligibility]  where FirstName='Valerie' and LastName='Ibarra' 
 
 select top 10* from  master.MemberInsurances where memberId= ( select  top 1 memberId from   master.members where nhmemberId in ('NH202005608359'
))
 --memberId =500000040538    --NHMemberId = 'NH202210333779'   1984-01-26

 select *from  Insurance.InsuranceHealthPlans where InsuranceCarrierID = 380 and HealthPlanName ='Molina Dual Options STAR+PLUS Medicare-Medicaid Plan TX H8197-002'

 
  select top 10 *From otc.userProfiles where nhmemberId ='NH202002311478'
 select top 10 *From otc.userProfiles where nhmemberId ='NH202108561034'

select top 10 * from benefitcard.changeRequest where nhmemberId ='NH202108561034' order by 1 desc

UPDATE benefitcard.changeRequest SET isactive =0 ,isProcessed =0
where nhmemberId ='NH202108561034'

EXEC [Master].[AttachProxyToMember] 'NH202002297295','YWW801226557','4256976289104'