select top 10 *From otc.carrierAgents where InsuranceCarrierId=271 order by 1 desc

select top 10 * from auth.userProfiles where UserProfileId = 17797 order by 1 desc

select top 10 *From agent.UserProfiles order by 1 desc --flex

 update auth.userProfiles set passwordSalt ='$2a$10$drju6TCKcNsTu1G4WsDp4u' ,
passwordHash ='$2a$10$drju6TCKcNsTu1G4WsDp4uhCJp2q2kqiGpOA3fvzqQhqxefbWdzLe'
where UserProfileId =17797

select top 10 *From otccatalog.wallets where DisplayWalletName like '%debit%'


SELECT * from  insurance.InsuranceCarriers where JSON_VALUE(CarrierConfig,'$.subdomain') like '%hap%'