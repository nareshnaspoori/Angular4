	select top 10 *from  otc.userProfiles where nhmemberId in (
	'NH202107690470'
	)  
	
	--  where nhmemberId ='NH202002291187'
	select top 10 *From master.members where nhmemberId ='NH202002291187'

select top 20 *from  otc.userProfiles order by 1 desc

 select top 

 UPDATE OTC.userProfiles set passwordSalt ='$2a$10$drju6TCKcNsTu1G4WsDp4u' , 
 passwordHash ='$2a$10$drju6TCKcNsTu1G4WsDp4uhCJp2q2kqiGpOA3fvzqQhqxefbWdzLe'
 where UseProfileId =''

 select top 10 *from  member.membercards where nhmemberId ='NH202002291187'

 

 select top 10 *from  otccatalog.WalletAttributeMaster order by 1 desc 




 select top 10 *from master.members where nhmemberId ='NH202208561252' order by 1 desc
 select top 20 *From master.memberinsurances where memberId = (select  top 1 memberId from   master.members where nhmemberId ='NH202208561252')   order by 1 desc
 select top 20 *From master.memberinsurances order by 1 desc

 master.members   EligibilityIndData ={"ssbciflag": "true" }


 UPDATE master.memberinsurances SET EligibilityIndData='{"ssbciflag": "true","isnationscare": null,"retirementdate":null,"headofhouseholdid":null}'
 WHERE memberId =8561252
 

 select top 10 *from [benefitcard].[ChangeRequest] order by 1 desc

 UPDATE  [benefitcard].[ChangeRequest]  SET isProcessed =0
 where requestId =78


 EXEC [Master].[AttachProxyToMember] 'NH202002314888','YWK801041697','4354181840239'

 select top 10 *from master.members where nhmemberId ='NH202208561252' order by 1 desc
 select top 20 *From master.memberinsurances where memberId = (select  top 1 memberId from   master.members where nhmemberId ='NH202002314888')   order by 1 desc

 select * from member.MemberCards where NHMemberID = 'NH202107467216'
 proxyId ===4933002804990   2698  302    ---2787560413786

 NH202107467216

 select *from flex.fiswalletMapping where carrierId=302 order by 1 desc



