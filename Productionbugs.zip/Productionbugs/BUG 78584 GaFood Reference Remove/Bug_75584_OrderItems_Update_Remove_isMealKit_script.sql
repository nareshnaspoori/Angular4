
-- BUG 78584 Remove references to GA Foods from Order Details page of Pantry Boxes
-- Update script for isMealKit remove from ItemData Json pantryboxes items no need isMealKit.

BEGIN TRY 
	BEGIN TRAN 
	PRINT 'Execution started..'
BEGIN
    UPDATE orders.orderItems SET ItemData =JSON_MODIFY(ItemData,'$.isMealKit',NULL),ModifyDate=GETDATE()
    WHERE orderId IN (
	SELECT distinct orderId FROM orders.orderItems d
					CROSS APPLY OPENJSON(d.ItemData) j
					WHERE j.[key] = 'isMealKit' AND ISJSON(d.ItemData) > 0 AND isActive =1 and createDate >='2022-01-01' )
END

COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH

