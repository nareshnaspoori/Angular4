[18:10] Naresh Naspoori
select top 10 *From otc.userProfiles where nhmemberId ='NH202002311478'

select top 10* from master.MemberInsurances where memberId= ( select top 1 memberId from master.members where nhmemberId in ('NH202002299444'
))

EligibilityIndData
NULL

select top 10* from master.MemberInsurances  where EligibilityIndData is not null order by 1  desc
{"ssbciflag": "true","isnationscare": null,"retirementdate":null,"headofhouseholdid":null}
select top 10* from master.MemberInsurances where memberId= ( select top 1 memberId from master.members where nhmemberId in ('NH202002311478'
))


select top 10* from master.MemberInsurances where memberId= ( select top 1 memberId from master.members where nhmemberId in ('NH202002418301'
))


SELECT mi.*,mm.NhMemberId FROM master.members as mm
INNER JOIN master.memberinsurances as mi on mi.memberid=mm.memberid
INNER JOIN master.memberinsurancedetails as mid on mid.memberinsuranceid=mi.ID
where mm.nhmemberId IN ('NH202002418301','NH202002296033')


SELECT mi.EligibilityIndData,mm.NhMemberId FROM master.members as mm
INNER JOIN master.memberinsurances as mi on mi.memberid=mm.memberid
INNER JOIN master.memberinsurancedetails as mid on mid.memberinsuranceid=mi.ID
where mm.nhmemberId IN ('NH202107467216','NH202002316907','NH202002307047' ,'NH202002818883','NH202002617201','NH202002294206')



SELECT mi.EligibilityIndData,mm.NhMemberId FROM master.members as mm
INNER JOIN master.memberinsurances as mi on mi.memberid=mm.memberid
INNER JOIN master.memberinsurancedetails as mid on mid.memberinsuranceid=mi.ID
where mm.nhmemberId IN ('NH202002308121' )

select top 10* from master.MemberInsurances where memberId= ( select top 1 memberId from master.members where nhmemberId in ('NH202002308121'
))

 select * from member.MemberCards where NHMemberID = 'NH202002303197'


--NH202002418301 ,NH202002303197 able to see grocerry wallet with benefits

NH202002296033 ,NH202107506827, NH202002313981,NH202107506709,NH202002303935 -- ssbciflag not configured

[otc].[GetWalletStandardData]  271 ,2537


--NH202002303935 -- ssbciflag not configured and grocery benefits getting 0 from fis api.
[{"indicator": true,"memberConsent": true,"additionalWallet":true}]
[{"indicator": "true","memberConsent": "true","additionalWallet":"true"}]

EligibilityIndData
NULL
NH202002818883
NH202002307047
SELECT mi.*,mm.NhMemberId FROM master.members as mm
INNER JOIN master.memberinsurances as mi on mi.memberid=mm.memberid
INNER JOIN master.memberinsurancedetails as mid on mid.memberinsuranceid=mi.ID
where mm.nhmemberId IN ('NH202002303935')



'NH202002307047' ,'NH202002818883','NH202002294206'  ,'NH2020026172010'
SELECT mi.* FROM master.members as mm
INNER JOIN master.memberinsurances as mi on mi.memberid=mm.memberid
INNER JOIN master.memberinsurancedetails as mid on mid.memberinsuranceid=mi.ID
where mm.nhmemberId ='NH202002316907'  --mid.insuranceNbr='yww870018688'=



SELECT mi.* FROM master.members as mm
INNER JOIN master.memberinsurances as mi on mi.memberid=mm.memberid
INNER JOIN master.memberinsurancedetails as mid on mid.memberinsuranceid=mi.ID
where mid.insuranceNbr='YWW801226557'

select top 10 *From otccatalog.Wallets where WalletId=121
select  *From otccatalog.walletPlans where insuranceCarrierId =271 order by  1 desc
 select top 20 *from  otccatalog.WalletAttributeMaster order by 1 desc 

select top 10 *From insurance.insuranceHealthPlans where healthPlanName ='Alignment Health Plan CA H3815-013'

select top 10 *From member.membercards where InsuranceHealthplanId = 2537 and InsuranceCarrierId =271 and nhMemberId ='NH202002308121'
and

select top 10 *from   fis.


[otc].[LoginAuthentication] 'alignment',
'{"Key":0,"MemberFirstName":null,"MemberLastName":null,"MemberDOB":"10-03-1953","NHMemberId":null,"CarrierId":0,"PlanId":0,"CardNumber":null,"SerialNumber":null,"InsuranceNumber":"00000137105","UserName":null,"LoginUserName":null,"LoginPassword":null,"ProgramCode":null,"CVV":null,"ExpirationMonth":null,"ExpirationYear":null,"IpAddress":"0.0.0.0","HealthPlanCode":null,"GroupNo":null,"SubDomain":null,"BenefitSource":null}'
,false

 select * from member.MemberCards where NHMemberID = 'NH202107467216'
 otc.eligibility





4988802346457
 select top 10 *from [flex].[FISWalletMapping] where carrierId =302 and healthplanId =2698 order by 1 desc

 select top 10 *From benefitcard.ChangeRequest   where nhmemberId in ('NH202002308121')  --CB02FIS22

 select NHlinkId ,inscarrierid,inshealthplanid, Benefitcardnumber,Benefittype, BenefitSource,NBwalletcode from [otcfunds].[CardBenefitLoad]
where NHLinkID
= '801108705'