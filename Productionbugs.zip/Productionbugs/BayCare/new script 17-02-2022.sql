BEGIN TRY 
	BEGIN TRAN 
	PRINT 'Execution started..'
	
BEGIN

		DECLARE @walletCode VARCHAR(200) = 'BY01NB22'
		
		
		DROP TABLE IF EXISTS #finalResult
		
		SELECT * 
		INTO #finalResult 
		FROM
		(
			SELECT DISTINCT 
			mi.EligibilityIndData
			, m.NHMemberID
			, mi.InsuranceCarrierID
			, i.InsuranceHealthPlanID
			, (
				CASE
				WHEN i.HealthPlanNumber = 'H2235-001' 
					THEN -25
				WHEN HealthPlanNumber = 'H2235-003' 
					THEN -50 
				ELSE 0 
				END
			  ) AS amount
			 , @walletCode AS walletCode
			 , 'NATIONS' AS SOURCE
			 ,JSON_VALUE(BenefitRuleData,'$.BENFREQMONTHS')AS benFreqMonths
			FROM master.Members m 
			INNER JOIN master.MemberInsurances mi ON mi.MemberID = m.MemberID 
			INNER JOIN Insurance.InsuranceHealthPlans i ON i.InsuranceHealthPlanID = mi.InsuranceHealthPlanID
						AND i.HealthPlanNumber in ('H2235-003','H2235-001')
			INNER JOIN Insurance.HealthPlanContracts hpc ON hpc.InsuranceCarrierID = mi.InsuranceCarrierID
						AND hpc.InsuranceHealthPlanID = mi.InsuranceHealthPlanID
			INNER JOIN Insurance.ContractRules cr ON cr.HealthPlanContractId = hpc.HealthPlanContractID
			INNER JOIN rulesengine.BenefitRulesData br ON br.BenefitRuleDataId = cr.BenefitRuleDataId AND JSON_VALUE(br.BenefitRuleData,'$.WALCODE') = @walletCode
			INNER JOIN orders.orders oo ON m.NHMemberID =oo.NHMemberID 
			WHERE 1 = 1
			AND ISJSON(mi.EligibilityIndData)=1 
			AND JSON_VALUE(mi.EligibilityIndData, '$.ssbciflag') = CAST(1 AS BIT)
			AND hpc.EffectiveToDate > GETDATE()
			AND m.IsActive=1
			AND mi.IsActive=1 
			AND i.IsActive =1 
			AND hpc.IsActive=1 
			AND cr.IsActive=1 
			AND br.IsActive =1 
			AND oo.isactive=1
		    --AND oo.amount < 0
		    AND DATEDIFF(MONTH, oo.createdate, GETDATE()) <= CAST(JSON_VALUE(BenefitRuleData,'$.BENFREQMONTHS')AS INT)  
		) AS m
		
		
		SELECT nhMemberId,insuranceCarrierId,InsuranceHealthPlanID,amount,walletCode,
		null AS conditionFlag, 
		CONCAT('EXEC [Orders].[ApplyCashVoucher] ', '''',nhMemberId,''',',insuranceCarrierId,'',',',InsuranceHealthPlanID,',',amount,'',',''',walletCode,'''', ',''',null,'''') as execScript
		FROM #finalResult WHERE amount >0
		   
END

	COMMIT TRAN

END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH
