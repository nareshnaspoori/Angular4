BEGIN TRY 
	--BEGIN TRAN 
	PRINT 'Execution started..'
	
BEGIN

DECLARE @source VARCHAR(200) ='nations'
DECLARE @healthPlanNumber1  VARCHAR(200) ='H2235-003'
DECLARE @walletCode VARCHAR(200) 

SELECT @walletCode = wl.walletCode  fROM otccatalog.Wallets wl 
INNER JOIN otccatalog.WalletPlans wlp ON wl.WalletId =wlp.WalletId
inner join Insurance.InsuranceHealthPlans ii ON ii.InsuranceHealthPlanID =wlp.InsuranceHealthPlanID
where  ii.HealthPlanNumber =@healthPlanNumber1 AND wl.IsActive =1 and wl.WalletName ='BayCare'
 and wlp.IsActive=1 and ii.IsActive=1 and wl.WalletSource =@source
SELECT  @walletCode as walletCode



--DROP TABLE IF EXISTS #finalResult

DROP TABLE IF EXISTS #finalResult

SELECT *INTO #finalResult 
FROM (
select distinct  mi.EligibilityIndData,m.NHMemberID ,mi.InsuranceCarrierID,i.InsuranceHealthPlanID,-50 as amount,@walletCode as walletCode,'NATIONS' AS SOURCE
from master.Members m 
inner join master.MemberInsurances mi on mi.MemberID=m.MemberID 
inner join Insurance.InsuranceHealthPlans i on i.InsuranceHealthPlanID=mi.InsuranceHealthPlanID and i.HealthPlanNumber in (@healthPlanNumber1)
INNER JOIN Insurance.HealthPlanContracts hpc ON hpc.InsuranceCarrierID = mi.InsuranceCarrierID AND hpc.InsuranceHealthPlanID = mi.InsuranceHealthPlanID
INNER JOIN Insurance.ContractRules cr ON cr.HealthPlanContractId = hpc.HealthPlanContractID
INNER JOIN rulesengine.BenefitRulesData br ON br.BenefitRuleDataId = cr.BenefitRuleDataId   AND JSON_VALUE(br.BenefitRuleData,'$.WALCODE') = @walletCode
CROSS APPLY OPENJSON(mi.EligibilityIndData) j
WHERE ISJSON(mi.EligibilityIndData)=1 and j.[key] = 'ssbciflag'  and 
m.IsActive=1 and  mi.IsActive=1 AND i.IsActive =1 AND hpc.IsActive=1 AND cr.IsActive=1 
AND br.IsActive =1 
AND JSON_VALUE(mi.EligibilityIndData,'$.ssbciflag')='true'
)as m


SELECT top 10  nhMemberId,insuranceCarrierId,InsuranceHealthPlanID,amount,walletCode,
null as conditionFlag, 
CONCAT('EXEC [Orders].[ApplyCashVoucher] ', '''',nhMemberId,''',',insuranceCarrierId,'',',',InsuranceHealthPlanID,',',amount,'',',''',walletCode,'''', ',''',null,'''') as execScript
FROM #finalResult 
   
END

END TRY
BEGIN CATCH
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH
