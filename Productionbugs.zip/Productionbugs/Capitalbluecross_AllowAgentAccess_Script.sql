 BEGIN TRY 
	BEGIN TRAN 
PRINT 'Execution started..'

 
 DECLARE @subdomain NVARCHAR(100)='capitalbluecross2'
 DECLARE @carrierId BIGINT
 DECLARE @systemUser VARCHAR(100)='mnanduri';


SELECT @carrierId= InsuranceCarrierId from  insurance.InsuranceCarriers where JSON_VALUE(CarrierConfig,'$.subdomain') = @subdomain
SELECT * FROM Insurance.InsuranceConfig where InsuranceCarrierID =@CarrierId and ConfigType='OTCLOGIN' and IsActive =1
IF  EXISTS (SELECT * FROM Insurance.InsuranceConfig where InsuranceCarrierID =@CarrierId and ConfigType='OTCLOGIN' and IsActive =1)
BEGIN
UPDATE Insurance.InsuranceConfig SET ConfigData= JSON_MODIFY(configData,'$.allowAgentAccess', CAST(1 AS BIT)), modifydate=Getdate(),modifyUser =@systemUser
WHERE InsuranceCarrierID=@CarrierId AND ConfigType='OTCLOGIN' and IsActive =1
END

 	COMMIT TRAN
		END TRY
BEGIN CATCH
ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH


