
 select top 10 *from  member.membercards where nhmemberId ='NH202002291187'

 select top 10 *From otc.userProfiles where nhmemberId ='NH202002309952'

 select top 10 *from  otccatalog.WalletAttributeMaster order by 1 desc 

 select top 20 *From master.memberinsurances where memberId = (select  top 1 memberId from   master.members where nhmemberId in ('NH202002301492'))   order by 1 desc

 select top 20 *From master.memberinsurances where memberId = (select  top 1 memberId from   master.members where nhmemberId in ('NH202208561335'
))   order by 1 desc

 select top 10 *from  otccatalog.WalletAttributeMaster order by 1 desc 
 {"ssbciflag": "true","isnationscare": null,"retirementdate":null,"headofhouseholdid":null}

 select top 10 *from member.MemberCards  where CardReferenceNumber='4256976289104'
 UPDATE   member.MemberCards SET isactive =0
 where nhmemberId = 'NH202208561327'    --'NH202108561034'


 delete from  member.MemberCards where MemberCardID in ( 574763,
574808)
 --NH202208561327
 select *From master.memberinsurances WHERE memberId =8561335
 UPDATE master.memberinsurances SET EligibilityIndData='{"ssbciflag": "true","isnationscare": null,"retirementdate":null,"headofhouseholdid":null}'
 WHERE memberId =8561335
 select top 30 *from otccatalog.wallets order by 1 desc
 select top 10 *from  otcCatalog.walletPlans where InsuranceCarrierId=271 order by 1 desc

  select top 10 *from [benefitcard].[ChangeRequest] order by 1 desc

  select *from  otcCatalog.walletPlans where InsuranceCarrierId=271 order by 1 desc

  select  *from otccatalog.wallets where WalletId in (95,121) order by 1 desc


 select *from  Insurance.InsuranceHealthPlans where  HealthPlanName ='H3923_017 BlueJourney Prime PPO'
  select *from  Insurance.InsuranceHealthPlans where  HealthPlanName ='Alignment Health Plan CA H3815-031'
  select *from  Insurance.InsuranceHealthPlans where  HealthPlanName ='Bright Advantage Classic Care (HMO) H7853-001-000'

  [Master].[AttachProxyToMember]'NH202208561335',1234567895,'4256976289104'

  sp_helptext '[Master].[AttachProxyToMember]'

  "01":"CB01NB22","02":"CB02FIS22"

  "01":"CB01NB22","02":"CB02FIS22"

   select top 10 *From Insurance.InsuranceConfig where insuranceCarrierId =271 and ConfigType='OTCLOGIN'
   select top 10 *From insurance.insuranceConfg where insuranceCarrierId =271

   select top 10 *from otc.UserProfiles where nhmemberId='NH202208561335'

   UPDATE otc.UserProfiles SET ISACTIVE =0 WHERE nhmemberId IN('NH202208561327','NH202108561034')

   SELECT *fROM otc.UserProfiles WHERE nhmemberId IN('NH202208561327','NH202108561034')
    'NH202208561327'    --'NH202108561034'

