DECLARE @subDomain VARCHAR(200) ='viva'
DECLARE @healthPlanNumber1  VARCHAR(200) ='H0154-012'
DECLARE @healthPlanNumber2  VARCHAR(200) ='H0154-019'
DECLARE @walletCode VARCHAR(200) 
DECLARE @source VARCHAR(200) ='nations'
DECLARE @benfitType VARCHAR(200) ='GROCERY'
SELECT @walletCode = WalletCode from otccatalog.wallets  where walletName ='Viva Grocery 2022' and isActive =1

--Pull all members of VIVA Carrier and Belongs to two healthPlans 
--Subtract the member who has GROCERRY ORDERS 
--SELECT @walletCode
DROP TABLE IF EXISTS #cteBenefitsFromOrders
;WITH cteRowNumber AS (
    SELECT NHMemberId, JSON_VALUE(oo.memberData,'$.insCarrierId')AS insurancecarrierid,
       JSON_VALUE(oo.MemberData,'$.insPlanId')AS healthPlanId,       jsonData.walletCode, --jsonData.benefitUsed,createDate
       (0-jsonData.amountRemaining)as amountRemaining, jsonData.benefitType,jsonData.source
           ,ROW_NUMBER() OVER (PARTITION BY nhmemberId ORDER BY createDate DESC) AS RowNum
        FROM Orders.Orders
              oo CROSS APPLY OPENJSON (oo.orderAmountData,'$.benefitTransactions')WITH (   
                       source  VARCHAR(200) '$.source',
                       walletCode VARCHAR(200) '$.catalogName',
                       benefitType VARCHAR(1000) '$.benefitType',
                       benefitUsed DECIMAL(7,2)  '$.amountCovered',
                       amountRemaining DECIMAL(7,2) '$.amountRemaining'
) AS jsonData
                WHERE JSON_VALUE(MemberData,'$.subdomain')=@subDomain  
                 and Status='active' 
                 and OrderStatusCode <> 'CAN'
                 and IsActive=1 
                and OrderType <> 'HA'
                 and jsonData.source=@source
                 AND benefitType =@benfitType
                 AND  jsonData.walletCode=@walletCode
                 AND jsonData.amountRemaining != 0.00
                 and JSON_VALUE(oo.MemberData,'$.insPlanId') IN (SELECT InsuranceHealthPlanID  FROM insurance.InsuranceHealthPlans
                 WHERE healthPlanNumber IN (@healthPlanNumber1,@healthPlanNumber2) AND IsActive =1)

)
SELECT * INTO #cteBenefitsFromOrders
FROM cteRowNumber
    WHERE RowNum = 1


DROP TABLE IF EXISTS #finalResult

SELECT *INTO #finalResult 
FROM (
select * from #cteBenefitsFromOrders-- where amountRemaining < -1
--EXEC [Orders].[ApplyCashVoucher] 'NH202107413611', 394, 4126, -25, 'VG101', ' '
--1,169
union all
select distinct m.NHMemberID, mi.InsuranceCarrierID,i.InsuranceHealthPlanID,'VG101',-25,'GROCERY','NATIONS',1 from master.Members m 
inner join master.MemberInsurances mi on mi.MemberID=m.MemberID and mi.IsActive=1
inner join Insurance.InsuranceHealthPlans i on i.InsuranceHealthPlanID=mi.InsuranceHealthPlanID and i.HealthPlanNumber in ('H0154-012','H0154-019')
INNER JOIN Insurance.HealthPlanContracts hpc ON hpc.InsuranceCarrierID = mi.InsuranceCarrierID AND hpc.InsuranceHealthPlanID = mi.InsuranceHealthPlanID
INNER JOIN Insurance.ContractRules cr ON cr.HealthPlanContractId = hpc.HealthPlanContractID
INNER JOIN rulesengine.BenefitRulesData br ON br.BenefitRuleDataId = cr.BenefitRuleDataId  AND  JSON_VALUE(br.BenefitRuleData,'$.WALCODE') ='VG101'
where m.IsActive=1 
and m.NHMemberID not in (select distinct NHMemberID from #cteBenefitsFromOrders)
)AS M 



SELECT top 10  nhMemberId,insuranceCarrierId,healthPlanId,amountRemaining,walletCode,
null as conditionFlag, 
CONCAT('EXEC [Orders].[ApplyCashVoucher] ', '''',nhMemberId,''',',insuranceCarrierId,'',',',healthPlanId,',',amountRemaining,'',',''',walletCode,'''', ',''',null,'''') as execScript
FROM #finalResult 

