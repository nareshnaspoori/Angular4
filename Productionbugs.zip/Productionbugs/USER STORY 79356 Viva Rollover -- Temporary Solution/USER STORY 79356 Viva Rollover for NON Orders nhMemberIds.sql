 --  USER STORY 79356 Viva Rollover -- Temporary Solution 
--   benefits carry forward to nhmemberIds for viva who don't have orders in orders.orders.
--   GET NON ORDERS nhmemberIds for carry forward benefits.
BEGIN TRY 
	--BEGIN TRAN 
	PRINT 'Execution started..'
	
BEGIN

DECLARE @subDomain varchar(200) ='viva'

DROP TABLE IF EXISTS #cteBenefitsFromOrders

;WITH cteRowNumber AS (
    SELECT NHMemberId, JSON_VALUE(oo.memberData,'$.insCarrierId')AS insurancecarrierid,
	JSON_VALUE(oo.MemberData,'$.insPlanId')AS healthPlanId,	jsonData.walletCode, --jsonData.benefitUsed,createDate
  	(0-jsonData.amountRemaining)as amountRemaining, jsonData.benefitType,jsonData.source
           ,ROW_NUMBER() OVER (PARTITION BY nhmemberId ORDER BY createDate DESC) AS RowNum
        FROM Orders.Orders
		oo CROSS APPLY OPENJSON (oo.orderAmountData,'$.benefitTransactions')WITH (   
			  source  varchar(200) '$.source',
			  walletCode varchar(200) '$.catalogName',
			  benefitType varchar(1000) '$.benefitType',
			  benefitUsed DECIMAL(7,2)  '$.amountCovered',
			  amountRemaining DECIMAL(7,2) '$.amountRemaining'
 ) as jsonData
		  WHERE JSON_VALUE(MemberData,'$.subdomain')=@subDomain  
		   and Status='active' 
		   and jsonData.source='nations' 
		   AND benefitType ='GROCERY'
		   and JSON_VALUE(oo.MemberData,'$.insPlanId') IN (select InsuranceHealthPlanID  from insurance.InsuranceHealthPlans
		   WHERE healthPlanNumber IN ('H0154-012','H0154-019') AND IsActive =1)
)
SELECT * 
INTO #cteBenefitsFromOrders
from cteRowNumber
    where RowNum = 1

	 
 DROP TABLE IF EXISTS #getNonOrdersBenefisTempTbl

 SELECT *INTO #getNonOrdersBenefisTempTbl
 FROM (
 SELECT DISTINCT mm.NHMemberID, ic.insuranceCarrierID, hp.InsuranceHealthPlanID as healthPlanId,JSON_VALUE(br.BenefitRuleData,'$.WALCODE') AS walletCode, 
 (0-JSON_VALUE(br.BenefitRuleData,'$.BENCATVALUE')) AS amountRemaining, 
 JSON_VALUE(br.BenefitRuleData,'$.BENTYPE') AS benefitType,
 JSON_VALUE(br.BenefitRuleData,'$.BENVALUESRC') AS  source, 
 1 as RowNum
--JSON_VALUE(br.BenefitRuleData,'$.BENFREQMONTHS') AS [Frequency Months], 
FROM master.Members mm
INNER JOIN master.MemberInsurances mi ON mm.MemberID = mi.MemberID
INNER JOIN Insurance.InsuranceHealthPlans hp ON hp.InsuranceHealthPlanID = mi.InsuranceHealthPlanID 
INNER JOIN Insurance.InsuranceCarriers ic ON ic.InsuranceCarrierID = mi.InsuranceCarrierID
INNER JOIN Insurance.HealthPlanContracts hpc ON hpc.InsuranceCarrierID = hp.InsuranceCarrierID AND hpc.InsuranceHealthPlanID = hp.InsuranceHealthPlanID
INNER JOIN Insurance.ContractRules cr ON cr.HealthPlanContractId = hpc.HealthPlanContractID
INNER JOIN rulesengine.BenefitRulesData br ON br.BenefitRuleDataId = cr.BenefitRuleDataId
--INNER JOIN #cteBenefitsFromOrders rbt ON mm.NHMemberID != rbt.NHMemberId 
WHERE  mm.IsActive=1 AND mi.IsActive=1 AND hp.IsActive =1 
AND ic.IsActive =1 AND hpc.IsActive =1 AND cr.IsActive=1 AND br.IsActive = 1
AND JSON_VALUE(br.BenefitRuleData,'$.BENVALUESRC') = 'nations' 
--AND   JSON_VALUE(br.BenefitRuleData,'$.BENTYPE')='GROCERY'
AND JSON_VALUE(br.BenefitRuleData,'$.WALCODE') ='VG101'
AND hp.healthPlanNumber  IN ('H0154-012','H0154-019') 
AND mm.NHMemberID NOT IN (SELECT NHMemberID FROM #cteBenefitsFromOrders)
) AS K 


DROP TABLE IF EXISTS #finalResult

SELECT *INTO #finalResult 
FROM (
SELECT  *FROM  #cteBenefitsFromOrders  
UNION  
SELECT * FROM #getNonOrdersBenefisTempTbl 
)AS M 

SELECT * FROM #finalResult 


END
--COMMIT TRAN
		END TRY
BEGIN CATCH
--ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH
