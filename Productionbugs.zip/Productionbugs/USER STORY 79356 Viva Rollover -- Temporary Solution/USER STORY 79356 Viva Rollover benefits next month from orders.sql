--  USER STORY 79356 Viva Rollover -- Temporary Solution 
--  benefits carry forward to nhmemberIds for viva who don't have orders in orders.orders.
--  GET NON ORDERS nhmemberIds for carry forward benefits.
--  GROCERY wallet, nations managed planNumbers are  H0154-012,H0154-019 healthPlanIds 4132 4126

BEGIN TRY 
	--BEGIN TRAN 
	PRINT 'Execution started..'
	
BEGIN

DECLARE @subDomain VARCHAR(200) ='viva'
DECLARE @healthPlanNumber1  VARCHAR(200) ='H0154-012'
DECLARE @healthPlanNumber2  VARCHAR(200) ='H0154-019'
DECLARE @walletCode VARCHAR(200) 
DECLARE @source VARCHAR(200) ='nations'
DECLARE @benfitType VARCHAR(200) ='GROCERY'
SELECT @walletCode = WalletCode from otccatalog.wallets  where walletName ='Viva Grocery 2022' and isActive =1
--SELECT @walletCode
DROP TABLE IF EXISTS #cteBenefitsFromOrders

;WITH cteRowNumber AS (
    SELECT NHMemberId, JSON_VALUE(oo.memberData,'$.insCarrierId')AS insurancecarrierid,
	JSON_VALUE(oo.MemberData,'$.insPlanId')AS healthPlanId,	jsonData.walletCode, --jsonData.benefitUsed,createDate
  	(0-jsonData.amountRemaining)as amountRemaining, jsonData.benefitType,jsonData.source
           ,ROW_NUMBER() OVER (PARTITION BY nhmemberId ORDER BY createDate DESC) AS RowNum
        FROM Orders.Orders
		oo CROSS APPLY OPENJSON (oo.orderAmountData,'$.benefitTransactions')WITH (   
			  source  VARCHAR(200) '$.source',
			  walletCode VARCHAR(200) '$.catalogName',
			  benefitType VARCHAR(1000) '$.benefitType',
			  benefitUsed DECIMAL(7,2)  '$.amountCovered',
			  amountRemaining DECIMAL(7,2) '$.amountRemaining'
 ) AS jsonData
		  WHERE JSON_VALUE(MemberData,'$.subdomain')=@subDomain  
		   and Status='active' 
		   and jsonData.source=@source
		   AND benefitType =@benfitType
		   AND  jsonData.walletCode=@walletCode
		   AND jsonData.amountRemaining != 0.00
		   and JSON_VALUE(oo.MemberData,'$.insPlanId') IN (SELECT InsuranceHealthPlanID  FROM insurance.InsuranceHealthPlans
		   WHERE healthPlanNumber IN (@healthPlanNumber1,@healthPlanNumber2) AND IsActive =1)
)
SELECT * INTO #cteBenefitsFromOrders
FROM cteRowNumber
    WHERE RowNum = 1

	-- get nhmemberids and benefits details who  don't have orders in order.orders table.
	 
 DROP TABLE IF EXISTS #getNonOrdersBenefisTempTbl

 SELECT *INTO #getNonOrdersBenefisTempTbl
 FROM (
 SELECT DISTINCT mm.NHMemberID, ic.insuranceCarrierID, hp.InsuranceHealthPlanID AS healthPlanId,JSON_VALUE(br.BenefitRuleData,'$.WALCODE') AS walletCode, 
 CAST((0-JSON_VALUE(br.BenefitRuleData,'$.BENCATVALUE')) AS DECIMAL(7,2) ) AS amountRemaining, 
 JSON_VALUE(br.BenefitRuleData,'$.BENTYPE') AS benefitType,
 JSON_VALUE(br.BenefitRuleData,'$.BENVALUESRC') AS  source, 
 1 as RowNum
--JSON_VALUE(br.BenefitRuleData,'$.BENFREQMONTHS') AS [Frequency Months], 
FROM master.Members mm
INNER JOIN master.MemberInsurances mi ON mm.MemberID = mi.MemberID
inner join master.MemberInsuranceDetails MID on MID.MemberInsuranceID = MI.ID
INNER JOIN Insurance.InsuranceHealthPlans hp ON hp.InsuranceHealthPlanID = mi.InsuranceHealthPlanID 
INNER JOIN Insurance.InsuranceCarriers ic ON ic.InsuranceCarrierID = mi.InsuranceCarrierID
INNER JOIN Insurance.HealthPlanContracts hpc ON hpc.InsuranceCarrierID = hp.InsuranceCarrierID AND hpc.InsuranceHealthPlanID = hp.InsuranceHealthPlanID
INNER JOIN Insurance.ContractRules cr ON cr.HealthPlanContractId = hpc.HealthPlanContractID
INNER JOIN rulesengine.BenefitRulesData br ON br.BenefitRuleDataId = cr.BenefitRuleDataId  --AND  JSON_VALUE(br.BenefitRuleData,'$.WALCODE') =@walletCode

WHERE  mm.IsActive=1 AND mi.IsActive=1 AND MID.IsActive=1 AND hp.IsActive =1 
AND ic.IsActive =1 AND hpc.IsActive =1 AND cr.IsActive=1 AND br.IsActive = 1
 AND mi.insuranceenddate > GETDATE()
AND JSON_VALUE(br.BenefitRuleData,'$.BENVALUESRC') = @source 
--AND   JSON_VALUE(br.BenefitRuleData,'$.BENTYPE')='GROCERY'
AND JSON_VALUE(br.BenefitRuleData,'$.WALCODE') =@walletCode
AND hp.healthPlanNumber  IN (@healthPlanNumber1,@healthPlanNumber2) 
AND mm.NHMemberID NOT IN (SELECT NHMemberID FROM #cteBenefitsFromOrders)
) AS K 


select top 10 *From orders.orders where orderStatusCode like'%can%'
DROP TABLE IF EXISTS #finalResult

SELECT *INTO #finalResult 
FROM (
SELECT  *FROM  #cteBenefitsFromOrders  
UNION  
SELECT * FROM #getNonOrdersBenefisTempTbl
)AS M 

-- final  result
-- SELECT *FROM #finalResult WHERE NhmemberId='NH202107397443' walletCode !='VG101'
   SELECT nhMemberId,insuranceCarrierId,healthPlanId,amountRemaining,walletCode, null as conditionFlag  FROM #finalResult 
   
   
END
--COMMIT TRAN
		END TRY
BEGIN CATCH
--ROLLBACK TRAN
SELECT ERROR_MESSAGE() AS ERROR 
END CATCH
